<?php
include("secure/head.php");

session_start();
include("secure/load_config.php");

if ($config->{"done"}){
    if ($config->{"allow_account_creation"} or $_SESSION["role"] == "admin"){
        if (isset($_SESSION["username"]) and $_SESSION["role"] != "admin"){
            header("Location: panel.php");
            http_response_code(302);
            die();
        }
    } else {
        http_response_code(403);
        header("Location: index.php");
        die();
    }
} else {
    http_response_code(302);
    header("Location: init.php");
    die();
}
?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central">
                <h1 class="title"><?php translate("CREATE_ACCOUNT") ?></h1>
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("USERNAME") ?> :</h4>
                </div>
                <input type="text" name="username" class="input input_central">
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("PASSWORD") ?> :</h4>
                </div>
                <input type="password" name="password" class="input input_central">
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("EMAIL") ?> (<?php strtolower(translate("OPTIONAL", lower: TRUE)) ?>) :</h4>
                </div>
                <span style="color:red; font-family: monospace;"><?php translate("PASSWORD_WARNING") ?></span>
                <input type="text" name="email" placeholder="<?php translate("CAN_EMPTY") ?>" class="input input_central">
                <button class="button" onclick="signup()"><?php translate("CREATE_ACCOUNT") ?></button>
                <a href="index.php" class="back_link">< <?php translate("BACK") ?></a>
            </div>
        </body>
        <script src="script/crypto-js/sha512.min.js"></script>
        <script src="script/adapt.js"></script>
        <script src="script/signup.js"></script>
    </html>