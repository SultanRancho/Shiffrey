<?php
// Require config.json file
$database_servername = $config->{"database"}->{"host"};
$database_username = $config->{"database"}->{"user"};
$database_password = $config->{"database"}->{"password"};
$database_name = $config->{"database"}->{"name"};

if ($database_name){
    $conn = new mysqli($database_servername, $database_username, $database_password, $database_name);  
} else {
    $conn = new mysqli($database_servername, $database_username, $database_password);  
}
?>