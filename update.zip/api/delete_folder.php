<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        if (isset($_POST["id"])){
            $id = basename(mysqli_real_escape_string($conn, $_POST["id"]));

            $sql = "SELECT *  FROM `folders` WHERE `id` = '".$id."'";
            $result = $conn->query($sql);

            if ($result and $result->num_rows == 1){
                while($row = $result->fetch_assoc()){
                    $owner = $row["owner"];
                    $old_folder = [$row["parent_folder"], $row["id"]];
                }

                if ($owner == $_SESSION["unsecure_username"]){
                    $sql = "SELECT `storage_size` FROM `user` WHERE `username` = '".$_SESSION["username"]."'";
                    $result = $conn->query($sql);

                    foreach ($result as $row){
                        $storage_size = $row["storage_size"];
                    }

                    $sql = "SELECT `id`, `parent_folder` FROM `folders` WHERE `owner` = '".$_SESSION["username"]."'";
                    $folders = $conn->query($sql);

                    $folders_list = array();

                    if ($folders and $folders->num_rows > 0){
                        while($row = $folders->fetch_assoc()){
                            array_push($folders_list, [$row["parent_folder"], $row["id"]]);
                        }
                    }

                    $seeking_folds = array($old_folder);
                    $deleted_result = array($id);

                    while (TRUE){
                        $next_seeking_fold = array();

                        foreach ($folders_list as $dir){
                            for ($i = 0; $i < sizeof($seeking_folds); $i++){
                                if ($dir[0] == $seeking_folds[$i][1]){
                                    array_push($next_seeking_fold, $dir);
                                    array_push($deleted_result, $dir[1]);
                                }
                            }
                        }

                        if ($next_seeking_fold){
                            $seeking_folds = $next_seeking_fold;
                        } else {
                            break;
                        }
                    }

                    $pre_sql_fold = "DELETE FROM `folders` WHERE ";
                    $pre_sql_file_get = "SELECT `id`, `size` FROM `content` WHERE ";
                    $pre_sql_file = "DELETE FROM `content` WHERE ";

                    $suf_sql_file = "";
                    $suf_sql_fold = "";

                    $file_to_delete = array();

                    $files_size = 0;

                    for ($i = 0; $i < sizeof($deleted_result); $i++){
                        if ($suf_sql_file != ""){
                            $suf_sql_file .= " OR";
                            $suf_sql_fold .= " OR";
                        }

                        $suf_sql_file .= " `folder` = '".$deleted_result[$i]."'";
                        $suf_sql_fold .= " `id` = '".$deleted_result[$i]."'";

                        if ($i % 3 == 2){
                            $res = $conn->query($pre_sql_file_get.$suf_sql_file);

                            if ($res and $res->num_rows > 0){
                                while($row = $res->fetch_assoc()){
                                    array_push($file_to_delete, $row["id"]);
                                    $files_size += intval($row["size"]);
                                }
                            }

                            $conn->query($pre_sql_file.$suf_sql_file);
                            $conn->query($pre_sql_fold.$suf_sql_fold);
                            
                            $suf_sql_file = "";
                            $suf_sql_fold = "";
                        }
                    }

                    if ($pre_sql_file.$suf_sql_file != ""){
                        $res = $conn->query($pre_sql_file_get.$suf_sql_file);

                        if ($res and $res->num_rows > 0){
                            while($row = $res->fetch_assoc()){
                                array_push($file_to_delete, $row["id"]);
                                $files_size += intval($row["size"]);
                            }
                        }

                        $conn->query($pre_sql_file.$suf_sql_file);
                    }

                    if ($pre_sql_fold.$suf_sql_fold != ""){
                        $conn->query($pre_sql_fold.$suf_sql_fold);
                    }

                    foreach ($file_to_delete as $td){
                        $file_path = "../IMPORTANT/content/".$td;
                        @unlink($file_path);
                    }

                    http_response_code(200);
                    echo '{"success" : true, "message": "Folder successfully deleted"}';

                    $storage_size = 0;
                        
                    $sql = "UPDATE `user` SET `storage_size` = `storage_size` - ".$files_size." WHERE `username` = '".$_SESSION["username"]."'";
                    $result = $conn->query($sql);  
                } else {
                    http_response_code(403);
                    die('{"success": false, "message": "You are not connected !"}');
                }
            } else {
                http_response_code(400);
                die('{"success" : false, "message": "Folder not found"}');
            }
        } else {
            http_response_code(400);
            die('{"success" : false, "message": "Bad Request"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>