<?php
$path = basename($_SERVER['REQUEST_URI']);

if ($path != ".htaccess"){
    if (file_exists($path.".php")){
        require($path.".php");
    } else {
        http_response_code(404);
        echo '{"success": false, "message": "This API endpoint does not exist"}';
    }
}
?>