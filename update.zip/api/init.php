<?php
    include("../secure/head.php");

    header("Content-Type: application/json");

    if (!($_SERVER['REQUEST_METHOD'] === "POST")){
        die('{"success": false, "message": "Bad request method."}');
    }
    
    // load the config file
    $config_path = "../IMPORTANT/config.json";
    $config = json_decode(file_get_contents($config_path, "r"));

    if (!($config->{"done"})){
        if (isset($_POST["dbhost"]) and isset($_POST["dbuser"]) and isset($_POST["dbpassword"]) and isset($_POST["adminpassword"]) and isset($_POST["public_name"])){
            // parameters
            $database_servername = $_POST["dbhost"];
            $database_username = $_POST["dbuser"];
            $database_password = $_POST["dbpassword"];

            $show_email = $_POST["show_email"];
            
            $public_name = $_POST["public_name"];

            $admin_password = password_hash($_POST["adminpassword"], PASSWORD_DEFAULT , ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]); 
            $config->{"database"}->{"host"} = $database_servername;
            $config->{"database"}->{"user"} = $database_username;
            $config->{"database"}->{"password"} = $database_password;
            $config->{"admin"}->{"password"} = $admin_password;
            $config->{"public_name"} = $public_name;
            
            if ($show_email == "true"){
                $config->{"admin"}->{"show_email"} = TRUE;
            } else {
                $config->{"admin"}->{"show_email"} = FALSE;
            }

            if (isset($_POST["email"])){
                $config->{"admin"}->{"email"} = $_POST["email"];
            } else {
                $config->{"admin"}->{"email"} = "";
            }

            $config->{"allow_account_creation"} = false;

            $conn = new mysqli($database_servername, $database_username, $database_password);  
           
            if ($conn->connect_error) {die("Connection failed: " . $conn->connect_error);} 

            // create the database if she don't exist
            if (isset($_POST["dbname"])){
                $dbname = mysqli_real_escape_string($conn, $_POST["dbname"]);
                
                try {
                     // delete the database if she always exist
                    $sql = "DROP DATABASE ".$dbname;
                    $conn->query($sql);
                } catch(Exception $e) {
                    
                }
                
                $sql = "CREATE DATABASE ".$dbname;

                if (!($conn->query($sql) === TRUE)){
                    die('{"success": false, "message": "Error while creating the database"}');
                }
            } else {
                $dbname = false;
            }
            $config->{"database"}->{"name"} = $dbname;
            
            $conn->close();

            // Connect to the database
            if ($dbname){
                $conn = new mysqli($database_servername, $database_username, $database_password, $dbname);
            } else {
                $conn = new mysqli($database_servername, $database_username, $database_password);
            }

            if (!$conn){
                die('{"success": false, "message": "Error connecting to database"}');
            } else {
                if ($dbname){
                    $dbname = "`".$dbname."`.";
                } else {
                    $dbname = "";
                }

                $sql = "CREATE TABLE ".$dbname."`user` (`username` TEXT NOT NULL, `password` TEXT NOT NULL, `email` TEXT NOT NULL, `storage_size` BIGINT(100), `blocked` TEXT NOT NULL)";
                $result = $conn->query($sql);

                if (!$result){
                    die('{"success": false, "message": "Something wrong happend during creation of the \'user\' table"}');
                }

                $sql = "CREATE TABLE ".$dbname."`content` (`metadata` TEXT NOT NULL, `size` BIGINT(100), `id` TEXT NOT NULL, `owner` TEXT NOT NULL, `associated_key` TEXT NOT NULL, `folder` TEXT NOT NULL, `creation_time` BIGINT(100))";
                $result = $conn->query($sql);

                if (!$result){
                    die('{"success": false, "message": "Something wrong happend during creation of the \'content\' table"}');
                }
                
                $sql = "CREATE TABLE ".$dbname."`sessions` (`role` TEXT NOT NULL, `token` TEXT NOT NULL, `creation` BIGINT(100), `username` TEXT NOT NULL)";
                $result = $conn->query($sql);

                if (!$result){
                    die('{"success": false, "message": "Something wrong happend during creation of the \'sessions\' table"}');
                }

                $sql = "CREATE TABLE ".$dbname."`link` (`id` TEXT NOT NULL, `key` TEXT NOT NULL, `file` TEXT NOT NULL, `name` TEXT NOT NULL, `blocked` TEXT NOT NULL, `owner` TEXT NOT NULL)";
                $result = $conn->query($sql);

                if (!$result){
                    die('{"success": false, "message": "Something wrong happend during creation of the \'link\' table"}');
                }

                $sql = "CREATE TABLE ".$dbname."`folders` (`id` TEXT NOT NULL,`parent_folder` TEXT NOT NULL, `metadata` TEXT NOT NULL, `owner` TEXT NOT NULL, `creation_time` BIGINT(100))";
                $result = $conn->query($sql);

                if (!$result){
                    die('{"success": false, "message": "Something wrong happend during creation of the \'link\' table"}');
                }
                
                // Connect the admin
                session_start();
                $admintoken = bin2hex(random_bytes(50));
                $_SESSION["admintoken"] = $admintoken;
                $_SESSION["role"] = "admin";
                $sql = "INSERT INTO `sessions`(`role`, `token`, `creation`, `username`) VALUES ('admin', '".$admintoken."', '".time()."', '')";
                $result = $conn->query($sql);
                                
                $conn->close();

                $config->{"max_file_size"} = 2000000;
                $config->{"max_user_storage_size"} = 100000000;

                // finalise the settings
                $config->{"done"} = true;
                file_put_contents($config_path, json_encode($config, JSON_PRETTY_PRINT));

                ini_set("file_uploads", "On");

                http_response_code(200);
                echo '{"success": true, "message": " Init successfully done !"}';
            }

        } else {
            http_response_code(400);
            die('{"success" : false, "message": "Bad Request"}');
        }
    } else {
        http_response_code(400);
        die('{"success" : false, "message": "Always done"}');
    }

?>