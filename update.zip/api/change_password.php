<?php
include("../secure/head.php");

header("Content-Type: application/json");

session_start();

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    die('{"success": false, "message": "Bad request method."}');
}

// load the config file
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    if (isset($_POST["token"])){
        $content = file_get_contents("../IMPORTANT/password_recovery_token.tk");
        $content = json_decode($content);

        if ($content->{"token"} == $_POST["token"]){
            if ($content->{"creation_time"} + 300 > time()){
                if (isset($_POST["new_password"]) or file_exists("../IMPORTANT/password_recovery_token.tk")){
                    $config->{"admin"}->{"password"} = password_hash($_POST["new_password"], PASSWORD_DEFAULT, ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]);
                    file_put_contents($config_path, json_encode($config, JSON_PRETTY_PRINT));
                    unlink("../IMPORTANT/password_recovery_token.tk");

                    echo '{"success": true, "message": "Password successfully changed !"}'; 
                } else {
                    http_response_code(400);
                    die('{"success": true, "message": "This token is valid."}');   
                }
            } else {
                unlink("../IMPORTANT/password_recovery_token.tk");

                http_response_code(400);
                die('{"success": false, "message": "This token has expired"}'); 
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "Invalid token"}');    
        }
    } else {
        http_response_code(400);
        die('{"success": false, "message": "Argument \'token\' required."}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>