<?php
include("secure/head.php");

session_start();
include("secure/load_config.php");


if ($config->{"done"}){
    // Connect to the db
    include("secure/sql_connection.php");
    // Verify if the session is always activ
    include("secure/check_connection.php");

    if (!(isset($_SESSION["username"]) and isset($_SESSION["token"]))){
        http_response_code(403);
        header("Location: error/noconnected.php");
        die();
    }
} else {
    http_response_code(302);
    header("Location: init.php");
    die();
}

?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="stylesheet" href="style/panel.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body class="normal">
            <div class="central_max">
                <div style="text-align: left; width: 80%; margin: 0 auto;">
                    <a href="panel.php"><button class="setting_button">< <?php translate("BACK") ?></button></a>
                </div>
                <span class="just_text"><?php translate("SETTINGS") ?></span>
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("CHANGE_PASSWORD") ?> :</h4>
                    <input type="password" id="new_password" placeholder="<?php translate("NEW_PASSWORD_PLACEHOLDER") ?>" class="input input_admin">
                    <br>
                    <button class="setting_button" onclick="new_keys()"><?php translate("CHANGE_MY_PASSWORD") ?></button>
                    <div style="height: 50px"></div>
                    <h4 class="medium_title"><?php translate("DELETE_ACTIVE_SESSIONS") ?> :</h4>
                    <div style="height: 15px"></div>
                    <button class="setting_button" onclick="delete_other_sessions()"><?php translate("DELETE_ACTIVE_SESSIONS") ?></button>
                    <div style="height: 55px"></div>
                    <h4 class="medium_title"><?php translate("DELETE_ACCOUNT") ?>:</h4>
                    <div style="height: 15px"></div>
                    <button class="setting_button" onclick="delete_account()"><?php translate("DELETE") ?></button>
                </div>
                <div style="height: 30px"></div>
            </div>
        </body>
        <script>
            var wait_translation = "<?php translate("WAIT", "string") ?>";
            var close_translation = "<?php translate("DONT_CLOSE_WINDOW", "string") ?>";
            var change_password_translation = "<?php translate("CHANGE_MY_PASSWORD", "string") ?>";
            var destroy_account_translation = "<?php translate("DESTROY_ACCOUNT", "string") ?>";
            var password_specified_translation = "<?php translate("PASSWORD_SPECIFIED", "string") ?>";
            var account_deleted_translation = "<?php translate("SUCCESS_DELETE_ACCOUNT", "string") ?>";
            var sessions_deleted_translation = "<?php translate("SUCCESS_DELETE_ACTIVE_SESSIONS", "string") ?>";
            var success_password_translation = "<?php translate("SUCCESS_PASSWORD_CHANGE", "string") ?>";
        </script>
        <script src="script/crypto-js/crypto-js.js"></script>
        <script src="script/devtools.js"></script>
        <script src="script/crypto-js/sha512.min.js"></script>
        <script src="script/user_settings.js"></script>
    </html>