async function signup(){
    request = new FormData();

    username = document.getElementsByName("username")[0].value;
    password = document.getElementsByName("password")[0].value;
    email = document.getElementsByName("email")[0].value;
    var password_hashed = sha512(sha512(password));

    request.append("username", username);
    request.append("email", email);
    request.append("password", password_hashed);

    req = await fetch("api/signup.php", {
        "body": request,
        "method": "POST",
    });

    cont_json = await req.json();
 
    if (cont_json["success"]){
        document.location = "index.php";
    } else {
        alert(cont_json["message"]);
    }
}