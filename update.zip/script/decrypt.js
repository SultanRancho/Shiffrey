var keySize = 256;
var ivSize = 128;
var iterations = 100;

function get_data(array){
  chunk_list = [];

  iter = Math.ceil(array.length / 1080);

  for (i = 0; i < iter; i++){
    chk = array.splice(0, 1080);

    key = false;
    iv = false;
    salt = false;

    key = toHexString(chk.splice(0, 32));
    iv = toHexString(chk.splice(0, 16));
    salt = toHexString(chk.splice(0, 8));

    chunk_list.push([key, iv, salt, chk])
  }

  return chunk_list
}

function decrypt_data(ct, key, iv, salt){
  data_to_decrypt = CryptoJS.lib.CipherParams.create({
    ciphertext: CryptoJS.enc.Hex.parse(ct), 
    iv: CryptoJS.enc.Hex.parse(iv), 
    salt: CryptoJS.enc.Hex.parse(salt), 
    key: CryptoJS.enc.Hex.parse(key)})
    
  decrypted_data = hexToBytes(CryptoJS.AES.decrypt(data_to_decrypt, pass).toString(CryptoJS.enc.Hex));

  return decrypted_data
}
