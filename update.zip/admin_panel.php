<?php
include("secure/head.php");
session_start();
include("secure/load_config.php");

if ($config->{"done"}){
    if (isset($_SESSION["admintoken"]) and $_SESSION["role"] == "admin"){
        // Connect to the db
        include("secure/sql_connection.php");
        // Verify if the session is always activ
        include("secure/check_connection.php");

        $access_option = "";

        if (!$config->{"allow_account_creation"})
            {
                $access_option = "selected";
            }

        if ($config->{"max_file_size"} > 1000000000){
                $options_file = '<option value="o" selected>o</option>
                            <option value="ko">Ko</option>
                            <option value="mo">Mo</option>
                            <option value="go" selected>Go</option>';
                $max_file_size = $config->{"max_file_size"} / 1000000000;
        } else if ($config->{"max_file_size"} > 1000000){
            $options_file = '<option value="o" selected>o</option>
                        <option value="ko">Ko</option>
                        <option value="mo" selected>Mo</option>
                        <option value="go">Go</option>';
            $max_file_size = $config->{"max_file_size"} / 1000000;
        } else if ($config->{"max_file_size"} > 1000){
            $options_file = '<option value="o" selected>o</option>
                        <option value="ko" selected>Ko</option>
                        <option value="mo">Mo</option>
                        <option value="go">Go</option>';
            $max_file_size = $config->{"max_file_size"} / 1000;        
        } else {
            $options_file = '
                        <option value="o" selected>o</option>
                        <option value="ko">Ko</option>
                        <option value="mo">Mo</option>
                        <option value="go">Go</option>';
            $max_file_size = $config->{"max_file_size"};        
        }
        
        if ($config->{"max_user_storage_size"} >= 1000000000){
            $options_user = '<option value="o" selected>o</option>
                        <option value="ko">Ko</option>
                        <option value="mo">Mo</option>
                        <option value="go" selected>Go</option>';
            $max_user_storage = $config->{"max_user_storage_size"} / 1000000000;
        } else if ($config->{"max_user_storage_size"} >= 1000000){
            $options_user = '<option value="o" selected>o</option>
                        <option value="ko">Ko</option>
                        <option value="mo" selected>Mo</option>
                        <option value="go">Go</option>';
            $max_user_storage = $config->{"max_user_storage_size"} / 1000000;        
        } else if ($config->{"max_user_storage_size"} >= 1000){
            $options_user = '<option value="o" selected>o</option>
                    <option value="ko" selected>Ko</option>
                        <option value="mo">Mo</option>
                        <option value="go">Go</option>';
            $max_user_storage = $config->{"max_user_storage_size"} / 1000;        
        } else {
            $options_user = '<option value="o" selected>o</option>
                        <option value="ko">Ko</option>
                        <option value="mo">Mo</option>
                        <option value="go">Go</option>';
            $max_user_storage = $config->{"max_user_storage_size"};    
        }

        $conn->close();
    } else {
        http_response_code(403);
        header("Location: error/noconnected.php");
        die();
    }
} else {
    http_response_code(500);
    header("Location: init.php");
    die();
}

?>

<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body class="normal">:
            <div class="central_max">
                <div style="text-align: right; width: 90%; margin: 0 auto;">
                    <a href="index.php"><button class="setting_button">< <?php translate("BACK_HOME") ?></button></a>
                    <button onclick="logout()" class="setting_button"><?php translate("LOGOUT") ?></button>
                </div>
                <br>
                <span class="just_text"><?php translate("ADMIN_PANEL") ?></span>
                <br>
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("ACCOUNT_CREATION") ?> :</h4>
                    <select id="creation-select" class="option">
                        <option value="true"><?php translate("EVERYBODY_CREATE_ACCOUNT") ?></option>
                        <option value="false" <?php echo $access_option; ?>><?php translate("ME_CREATE_ACCOUNT") ?></option>
                    </select>
                    <a href="user_list.php"><button class="setting_button"><?php translate("SEE_ACCOUNT_LIST") ?></button></a>
                    <a href="signup.php"><button class="setting_button"><?php translate("CREATE_ACCOUNT") ?></button></a>
                    <div style="height: 30px"></div>
                    <h4 class="medium_title"><?php translate("CHANGE_PASSWORD") ?> :</h4>
                    <input type="password" id="password" placeholder="<?php translate("NEW_PASSWORD_PLACEHOLDER") ?>" class="input input_admin">
                    <h4 class="medium_title"><?php translate("CHANGE_EMAIL") ?> :</h4>
                    <input type="text" id="email" placeholder="<?php translate("NEW_EMAIL_PLACEHOLDER") ?>" class="input input_admin" value="<?php echo htmlspecialchars($config->{"admin"}->{"email"}) ?>">                
                    <div>
                        <input type="checkbox" id="show_email" name="show_email" <?php if (isset($config->{"admin"}->{"show_email"}) and $config->{"admin"}->{"show_email"}){echo "checked";}  ?>>
                        <label for="show_email" class="medium_title"><?php translate("SHOW_EMAIL") ?></label>
                    </div>
                    <div style="height: 30px"></div>
                    <h4 class="medium_title"><?php translate("CHANGE_PUBLIC_NAME") ?>:</h4>
                    <input type="text" id="public_name" placeholder="<?php translate("CHANGE_PUBLIC_NAME_PLACEHOLDER") ?>" class="input input_admin" value="<?php echo htmlspecialchars($config->{"public_name"}) ?>">
                    <div style="height: 30px"></div>
                    <h4 class="medium_title"><?php translate("MAXIMUM_FILE_SIZE") ?> :</h4>
                    <input type="number" id="file-size" placeholder="<?php translate("MAXIMUM_FILE_SIZE") ?>" class="input input_number" value="<?php echo htmlspecialchars($max_file_size) ?>">
                    <select id="file-unit" class="option">
                        '<?php echo $options_file; ?>'
                    </select>
                    <h4 class="medium_title"><?php translate("MAXIMUM_USER_STORAGE") ?> :</h4>
                    <input type="number" id="user-size" placeholder="<?php translate("MAXIMUM_USER_STORAGE") ?>" class="input input_number" value="<?php echo htmlspecialchars($max_user_storage) ?>">
                    <select id="user-unit" class="option">
                        '<?php echo $options_user; ?>'
                    </select>
                    <div style="height: 20px"></div>
                    <button onclick="delete_all_sessions()" class="setting_button"><?php translate("DELETE_ACTIVE_ADMIN_SESSIONS") ?></button>
                    <div style="text-align:right;margin: 15px;">
                        <a href="https://github.com/SultanRancho/Shiffrey" style="color:rgb(132, 157, 159)" class="info"><?php translate("VERSION") ?>: <?php echo htmlspecialchars(file_get_contents("version.txt")) ?></a>
                    </div>
                </div>
                <button class="button" onclick="save_settings()"><?php translate("SAVE_SETTINGS") ?></button>
            </div>
        </body>
        <!-- Translation -->
        <script>
            var settings_saved = "<?php translate("SUCCESS_SAVE_SETTINGS", "string") ?>";
            var sessions_deleted = "<?php translate("SUCCESS_DELETE_ACTIVE_ADMIN_SESSIONS", "string") ?>";
        </script>
        <script src="script/devtools.js"></script>
        <script src="script/admin.js"></script>
    </html>