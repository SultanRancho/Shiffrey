<?php
include("secure/head.php");

session_start();
include("secure/load_config.php");


if ($config->{"done"}){
    // Connect to the db
    include("secure/sql_connection.php");
    // Verify if the session is always activ
    include("secure/check_connection.php");
    
    if (!(isset($_SESSION["admintoken"]) and $_SESSION["role"] == "admin")){
        header("Location: error/noconnected.php");
        die();
    }
} else {
    header("Location: init.php");
    die();
}
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Shiffrey</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style/main.css">
        <link rel="stylesheet" href="style/widget.css">
        <link rel="icon" type="images/png" href="images/favicon.png">
    </head>
    <body class="normal">
        <div class="central_max">
            <button style="width:80%" onclick="window.location = 'admin_panel.php'" class="setting_button">&lt; <?php translate("BACK") ?></button>
            <br>
            <span class="just_text"><?php translate("LIST_USERS") ?></span>
            <div style="padding:5px; text-align: left; width:80%; margin: 0 auto;">
                <button class="fix_button" onclick="prec_page()"><  <?php translate("PREVIOUS") ?></button>
                <input type="number" onkeypress="enterpress(event)" class="input" style="width: 5%;" id="page_index" value="1" min="1"></input>
                <button class="fix_button" onclick="next_page()"><?php translate("NEXT") ?> ></button>
            </div>
            <div class="data">
            </div>
        </div>
    </body>
    <script>
        var username_trans = "<?php translate("USERNAME", "string") ?>";
        var email_trans = "<?php translate("EMAIL") ?>"
        var list_user_trans = "<?php translate("LIST_USERS") ?>";
        var used_storage_trans = "<?php translate("USED_STORAGE") ?>";
        var no_username_trans = "<?php translate("NO_USERNAME") ?>";
        var no_email_trans = "<?php translate("NO_EMAIL") ?>"
        var no_used_storage_trans = "<?php translate("NO_USED_STORAGE") ?>"
        var user_deleted_storage_trans = "<?php translate("USER_DELETED", "string") ?>"
        var user_blocked_storage_trans = "<?php translate("USER_BLOCKED", "string") ?>"
        var user_unblocked_storage_trans = "<?php translate("USER_UNBLOCKED", "string") ?>";
        var delete_trans = "<?php translate("DELETE") ?>";
        var block_trans = "<?php translate("BLOCK") ?>";
        var unblock_trans = "<?php translate("UNBLOCK") ?>";

    </script>
    <script src="script/crypto-js/crypto-js.js"></script>
    <script src="script/devtools.js"></script>
    <script src="script/user_list.js"></script>
</html>