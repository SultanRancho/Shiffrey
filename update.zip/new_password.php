<?php
include("secure/head.php");

session_start();
include("secure/load_config.php");


if (!$config->{"done"})
    {
        http_response_code(302);
        header("Location: init.php");
        die();
    }

if (!$config->{"admin"}->{"email"}){
    http_response_code(302);
    header("Location: admin.php");
    die();
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Shiffrey</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style/main.css">
        <link rel="stylesheet" href="style/widget.css">
        <link rel="icon" type="images/png" href="images/favicon.png">
    </head>
    <body onresize="adapt_display()">
        <div class="central">
            <span class="just_text" id="message"><?php translate("WAIT") ?> ...</span>
            <br>
            <a href="forgot_password.php"><button class="button" style="margin: 5px;">< <?php translate("BACK_PASSWORD_RECOVERY") ?></button></a>
        </div>
    </body>
    <script src="script/adapt.js"></script>
    <script>
        async function send_email(){
            req = await fetch("api/send_recovery_email.php", {"method": "POST"})
            cont = await req.json()

            if (cont["success"]){
                document.getElementById("message").innerText = "<?php translate("SUCCESSFULLY_MAIL", "string") ?>"
            } else {
                document.getElementById("message").innerText = cont["message"];
            }
        }

        send_email();
    </script>
</html>