<?php
include("secure/head.php");
session_start();
include("secure/load_config.php");

if (!$config->{"done"})
    {
        http_response_code(302);
        header("Location: init.php");
        die();
    }
?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central" style="padding: 15px">
                <h1 class="title"><?php translate("CHANGE_PASSWORD") ?>:</h1> 
                <div style="height:20px;"></div>
                <button class="button" onclick="change_password()"><?php translate("CHANGE_PASSWORD") ?></button>
            </div>
        </body>
        <script>
            async function change_password(){
                req = await fetch("api/change_admin_password.php", {"method": "POST"});
                cont_json = await req.json();

                trad_instruct = "<?php translate("PASSWORD_CHANGE_INSTRUCTION", "string") ?>"

                if (cont_json["success"]){
                    if (cont_json["message"] == "Token successfully generated. No email adresse defined."){
                        alert(trad_instruct);
                        document.location = "new_admin_password.php"
                    } else {
                        alert(email_sent);
                    }
                } else {
                    alert(cont_json["message"])

                    if (cont_json["message"] == "A request has already been sent. Please wait 10 minutes before sending another."){
                        document.location = "new_admin_password.php"
                    }
                }
            }

            var email_sent = "<?php translate("RECEIVE_EMAIL_PASSWORD") ?>";
        </script>
        <script src="script/adapt.js"></script>
    </html>