<?php
include("secure/head.php");

session_start();

include("secure/load_config.php");


if ($config->{"done"}){
    // Connect to the db
    include("secure/sql_connection.php");
    // Verify if the session is always activ
    include("secure/check_connection.php");

    if (!(isset($_SESSION["username"]) and isset($_SESSION["unsecure_username"])  and isset($_SESSION["token"]))){
        http_response_code(403);
        header("Location: error/noconnected.php");
    }
} else {
    http_response_code(302);
    header("Location: init.php");
}
?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/panel.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body class="normal" onresize='adapt_on_resize()'>
            <div class="central_max">
                <div id="button_header">
                    <div style="text-align: left;flex: 1;">
                        <a href="settings.php"><button class="button head_button" style="margin-bottom: 5px;"><?php translate("SETTINGS") ?></button></a>
                        <a href="admin.php"><button class="button head_button"><?php translate("LOGIN_ADMIN") ?></button></a>
                    </div>
                    <div style="text-align: right;flex: 1;">
                        <button class="button head_button" onclick="logout()"><?php translate("LOGOUT") ?></button>
                    </div>
                </div>
                <br>
                <span class="just_text"><?php translate("WELCOME") ?>, <?php echo htmlspecialchars($_SESSION["unsecure_username"]) ?> !</span>
                <br>
                <a href="upload.php"><button class="button large_button"><?php translate("UPLOAD") ?></button></a>
                <br>
                <span class="info"></span>
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("MY_FILES") ?> :</h4>
                </div>
                <div style="padding:5px; text-align: left; width:80%; margin: 0 auto;">
                    <button class="fix_button" id="create_folder" onclick="create_folder()"><?php translate("CREATE_FOLDER") ?></button>
                    <button class="fix_button" style="visibility: hidden" onclick="paste()" id="paste"><?php translate("PASTE") ?></button>
                    <button class="fix_button" style="visibility: hidden" onclick="delete_the_files()" id="dtf"><?php translate("DELETE") ?></button>
                    <button class="fix_button" style="visibility: hidden" onclick="copy_the_files()" id="ctf"><?php translate("COPY") ?></button>
                    <button class="fix_button" style="visibility: hidden" onclick="cut_the_files()" id="cutf"><?php translate("CUT") ?></button>
                </div>
                <div style="display: flex;width: 80%;margin: 10px auto;" id="sub_path">
                    <div class="div_path" id="path" style="margin-right: 5px;font-size: x-large;color: rgb(85, 241, 252); font-family: monospace;"></div>
                    <button class="fix_button" id="back_fold" onclick="back_fold()" style="width: 20%; height: fit-content;"><?php translate("BACK") ?></button>
                </div>
                <div class="data">
                </div>
            </div>
        </body>
        <script src="script/crypto-js/crypto-js.js"></script>
        <script src="script/decrypt.js"></script>
        <script src="script/devtools.js"></script>
        <script>
            var rename_translation = "<?php translate("RENAME", "string") ?>";
            var uncypher_translation = "<?php translate("UNCYPHER", "string") ?>";
            var delete_translation = "<?php translate("DELETE", "string") ?>";
            var download_translation = "<?php translate("DOWNLOAD", "string") ?>";
            var share_translation = "<?php translate("SHARE", "string") ?>";
            var ask_delete_file_translation = "<?php translate("ASK_DELETE_FILE", "string") ?>";
            var ask_delete_files_translation = "<?php translate("ASK_DELETE_FILES", "string") ?>";
            var ask_delete_folder_translation = "<?php translate("ASK_DELETE_FOLDER", "string") ?>";
            var wait_translation = "<?php translate("WAIT", "string") ?>";
            var loading_translation = "<?php translate("LOADING", "string") ?>";
            var filename_translation = "<?php translate("NEW_FILE_NAME", "string") ?>";
            var folder_name_translation = "<?php translate("FOLDER_NAME", "string") ?>";
            var disconnected_translation = "<?php translate("SUCCESSFULLY_DISCONNECTED", "string") ?>";
            var empty_translation = "<?php translate("EMPTY_STORAGE", "string") ?>";
            var open_translation = "<?php translate("OPEN", "string") ?>";
        </script>
        <script src="script/panel.js"></script>
        <script>async function get_max(){
            await get_settings(); 
            upload = document.getElementsByClassName("info")[0];
            upload.innerText = upload.innerText+convertUnit(getCookie("ACTUAL_USER_STORAGE"), true)+"/"+convertUnit(getCookie("MAX_USER_STORAGE_SIZE"));}

            get_max();
            adapt_on_resize()
        </script>
    </html>