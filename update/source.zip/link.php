<?php
include("secure/head.php");

session_start();
// load the config file
include("secure/load_config.php");


if ($config->{"done"}){
    if (!isset($_GET["id"])){
        http_response_code(400);
        header("Location: index.php");
        die();
    }
} else {
    header("Location: init.php");
    die();
}
?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central">
                <h1 class="title"><?php translate("DOWNLOAD_FILE") ?>:</h1>
                <span id="flname" class="just_text"></span>
                <br>
                <div id="preview"></div>
                <br>
                <a id="download">
                    <button class="button" onclick="uncypher()"><?php translate("WAIT") ?>... (<?php translate("DOWNLOADING") ?>)</button>
                
                    <div>
                            <input type="checkbox" checked="true" onclick='document.cookie = "PREVIEW_CHECKED=" +  this.checked + ";SameSite=Strict"' name="preview" id="preview_check">
                            <label for="preview" class="just_text" style="font-size: large;"><?php translate("PREVIEW") ?></label>
                    </div> 
		        </a>
                <?php if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
                    echo '<a href="panel.php" class="back_link">< ';
                    translate("BACK");
                    echo '</a>';
                }
                ?>
            </div>
        </body>
        <script>
            var link = "<?php if (strlen($_GET["id"]) == 20){echo htmlspecialchars($_GET["id"]);}?>";
            var uncypher_the_file = "<?php translate("UNCYPHER_FILE", "string") ?>";
            var wait_translation = "<?php translate("WAIT", "string") ?>";
            var downloading_trans = "<?php translate("DOWNLOADING", "string") ?>";
            var download_trans = "<?php translate("DOWNLOAD", "string") ?>"
        </script>
        <script src="script/link.js"></script>
        <script src="script/crypto-js/crypto-js.js"></script>
        <script src="script/devtools.js"></script>
        <script src="script/adapt.js"></script>
    </html>
