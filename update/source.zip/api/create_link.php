<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        $username = $_SESSION["username"];
        
        if (isset($_POST["file_id"]) and isset($_POST["key"]) and isset($_POST["name"])){
            $fileid = mysqli_real_escape_string($conn, $_POST["file_id"]);
            $key = mysqli_real_escape_string($conn, $_POST["key"]);
            $name = mysqli_real_escape_string($conn, $_POST["name"]);

            while (TRUE){
                $token = mysqli_real_escape_string($conn, bin2hex(random_bytes(10)));

                $sql = "SELECT `id` FROM `link` WHERE `id` = '".$token."'";;

                $result = $conn->query($sql);

                if (!($result and $result->num_rows > 0)){
                    break;
                }
            }
            
            $sql = "SELECT `file` FROM `link` WHERE `file` = '".$fileid."'";;
            $result = $conn->query($sql);

            if (!($result and $result->num_rows > 0)){
                $sql = "INSERT INTO `link`(`id`, `key`, `file`, `blocked`, `name`, `owner`) VALUES ('".$token."','".$key."','".$fileid."','false', '".$name."', '".$username."')";
                $result = $conn->query($sql);

    
                if ($result){
                    echo '{"success": true, "message": "Link successfully created."}';
                } else {
                    http_response_code(500);
                    die('{"success": false, "message": "An error has occurred with the database."}');
                }
            } else {
                http_response_code(400);
                die('{"success": false, "message": "A link always exist for this file."}');
            }
        } else {
            $not_specified = "";

            if (!isset($_POST["file_id"])){
                $not_specified .= "file_id";
            }

            if (!isset($_POST["name"])){
                if ($not_specified){
                    $not_specified .= ",";
                }
                $not_specified .= "name";
            }

            if (!isset($_POST["key"])){
                if ($not_specified){
                    $not_specified .= ",";
                }
                $not_specified .= "key";
            }
            http_response_code(400);
            die('{"success": false, "message": "Bad request :'.$not_specified.' are not specified"}');
        }

    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>