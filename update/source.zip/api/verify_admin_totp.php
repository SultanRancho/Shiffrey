<?php
include("../secure/head.php");

header("Content-Type: application/json");

// load the config file
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if (!($_SERVER['REQUEST_METHOD'] === "POST") and !($_SERVER['REQUEST_METHOD'] === "GET")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();

if ($config->{"done"}){
    if (isset($_SESSION["role"]) and $_SESSION["role"] == "admin"){
        if (isset($config->{"totp"}) and $config->{"totp"}){
            if (isset($_POST["totp"])){
                include("../lib/Base32.php");

                $totp = $config->{"totp"};

                $time = floor(time() / $totp->{"delay"});
                $time = hex2bin(str_pad(dechex($time), 16, "0", STR_PAD_LEFT));

                $secret = base_32_decode($totp->{"secret"});

                $hash = hash_hmac($totp->{"algorithm"}, $time, $secret);

                $intValue = intval(substr($hash, -1), 16);
                $dyn_trunc = intval(substr($hash, $intValue * 2, 8), 16);
                if ($dyn_trunc > 2147483647) {
                    $dyn_trunc -= 2147483648;
                }

                $totp_token = str_pad(strval($dyn_trunc % (10 ** $totp->{"codesize"})), $totp->{"codesize"},"0", STR_PAD_LEFT);


                if ($totp_token != $_POST["totp"]){
                    http_response_code(403);
                    die('{"success": false, "message": "Bad TOTP token", "code" : "BAD_TOTP"}');    
                } else {
                    echo '{"success": true, "message": "The code is good", "code" : "GOOD_TOTP"}';
                }
            } else {
                http_response_code(400);
                die('{"success": false, "message": "Bad request"}');
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "TOTP is not set"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You aren\'t admin"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}

?>