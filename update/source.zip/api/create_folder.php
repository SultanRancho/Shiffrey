<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        if (isset($_POST["metadata"])){
            $parent_folder = -1;

            if (isset($_POST["parent_folder"])){
                $parent_folder = mysqli_real_escape_string($conn, $_POST["parent_folder"]);

                $sql = "SELECT `id` FROM `folders` WHERE `id` = '".$parent_folder."'";
                $result = $conn->query($sql);

                if (!($result and $result->num_rows > 0)){
                    $parent_folder = -1;
                }
            }
            
            $name = mysqli_real_escape_string($conn, $_POST["metadata"]);

            while (TRUE){
                $fold_id =  mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));

                $sql = "SELECT `id` FROM `folders` WHERE `id` = '".$fold_id."'";
                $result = $conn->query($sql);    

                if ($result)
                    {
                        break;
                    }
            }

            $sql = "INSERT INTO `folders`(`parent_folder`, `metadata`, `owner`, `id`, `creation_time`) VALUES ('".$parent_folder."','".$name."', '".$_SESSION["username"]."', '".$fold_id."', ".time().")";

            $result = $conn->query($sql);

            if ($result){
                http_response_code(200);
                die('{"success" : true, "message": "Folder successfully created !"}');
            } else {
                http_response_code(400);
                die('{"success" : false, "message": "Error"}');
            }
        } else {
            http_response_code(400);
            die('{"success" : false, "message": "Bad Request"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>