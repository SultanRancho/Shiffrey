<?php
    include("../secure/head.php");

    header("Content-Type: application/json");

    session_start();

    if (!($_SERVER['REQUEST_METHOD'] === "GET")){
        http_response_code(405);
        die('{"success": false, "message": "Bad request method."}');
    }

    // load the config file
    $config_path = "../IMPORTANT/config.json";
    $config = json_decode(file_get_contents($config_path, "r"));

    if ($config->{"done"}){
        // Connect to the db
        include("../secure/sql_connection.php");
        // Verify if the session is always activ
        include("../secure/check_connection.php");

        $settings = array("allow_account_creation" => $config->{"allow_account_creation"}, 
                            "max_file_size" => $config->{"max_file_size"},
                            "max_user_storage_size" => $config->{"max_user_storage_size"},
                            "public_name" => $config->{"public_name"});

        if ($config->{"admin"}->{"show_email"}){
            $settings["admin_email"] = $config->{"admin"}->{"email"};
        }

        if (isset($_SESSION["token"]) and isset($_SESSION["username"])){
            $sql = "SELECT `storage_size` FROM `user` WHERE `username` = '".$_SESSION["username"]."'";
            $result = $conn->query($sql);

            foreach ($result as $row){
                $storage_size = $row["storage_size"];
            }

            $settings["actual_storage_size"] = intval($storage_size);
        }

        echo json_encode(array("success" => TRUE, "data" => $settings), JSON_PRETTY_PRINT);
    } else {
        http_response_code(400);
        die('{"success": false, "message": "Init isn\'t done"}');
    }
?>