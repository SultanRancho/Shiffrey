<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "GET")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        $username = $_SESSION["username"];

        $sql = "SELECT `metadata`, `parent_folder`, `id`, `creation_time` FROM `folders` WHERE `owner` = '".$username."'";

        if (isset($_GET["parent_folder"])){
            $par_folder = mysqli_real_escape_string($conn, $_GET["parent_folder"]);

            if ($_GET["parent_folder"] != "-1"){
                $sql_par = "SELECT `id` FROM `folders` WHERE `owner` = '".$username."' AND `id` = '".$par_folder."'";

                $result = $conn->query($sql_par);
    
                if (!$result or $result->num_rows == 0){
                    die('{"success": false, "message": "Folder not found", "code": "FOLDER_NOT_FOUND"}');
                }
            }

            $add_sql = " AND `parent_folder` = '".$par_folder."'";
        } else {
            $add_sql = "";
        }
        
        if (isset($_GET["start"]) and isset($_GET["length"])){
            $start = mysqli_real_escape_string($conn, $_GET["start"]);
            $length = mysqli_real_escape_string($conn, $_GET["length"]);

            if (is_numeric($start) and is_numeric($length)){
                $sql .= " LIMIT ".$start.",".$length;
            } else {
                die('{"success": false, "message": "\'start\' and \'length\' GET argument must be a number"}');
            }   
        } else {
            if (!isset($_GET["start"]) and isset($_GET["length"])){
                die('{"success": false, "message": "\'start\' GET argument must be defined"}');
            }

            if (!isset($_GET["length"]) and isset($_GET["start"])){
                die('{"success": false, "message": "\'length\' GET argument must be defined"}');
            }
        }

        $result = $conn->query($sql.$add_sql);

        $list = array();

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                        array_push($list, array("metadata" => $row["metadata"], "parent_folder" => $row["parent_folder"], "id" => $row["id"], "creation_time" => $row["creation_time"]));
                }
        }

        $sql = "SELECT COUNT(*) AS `count` FROM `folders` WHERE `owner` = '".$username."'";
        $result = $conn->query($sql.$add_sql);

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                echo json_encode(array("success" => TRUE, "data" => $list, "length" => intval($row["count"])), JSON_PRETTY_PRINT);
            }
        } else {
            die('{"success": false, "message": "An error happend with the database !"}');   
        }

    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>