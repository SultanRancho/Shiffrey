<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        if (isset($_POST["id"]) and isset($_POST["parent_folder"])){
            $id = mysqli_real_escape_string($conn, $_POST["id"]);

            // Verify if the folder exist
            $new_parent_folder = mysqli_real_escape_string($conn, $_POST["parent_folder"]);

            if ($new_parent_folder != -1){
                $sql = "SELECT `id` FROM `folders` WHERE `id` = '".$new_parent_folder."'";
                $result = $conn->query($sql);
                if (!($result and $result->num_rows > 0)){
                    die('{"success" : false, "message": "This folder does not exist"}');
                }
            }
            
            $sql = "SELECT * FROM `content` WHERE `id` = '".$id."'";

            $result = $conn->query($sql);

            if ($result and $result->num_rows > 0 and 2 > $result->num_rows){
                while($row = $result->fetch_assoc()){
                    $owner = $row["owner"];
                    $fsize = $row["size"];
                    $old_id = $row["id"];
                    $metadata = $row["metadata"];
                    $associated_key = $row["associated_key"];
                }

                if ($owner == $_SESSION["unsecure_username"]){
                    $actual_storage_used = NULL;
                    $sql = "SELECT `storage_size` FROM `user` WHERE `username` = '".$owner."'";
                    $result = $conn->query($sql);
        
                    foreach ($result as $row){
                        $actual_storage_used = intval($row["storage_size"]);
                        if ($actual_storage_used == NULL){
                            $actual_storage_used = 0;
                        }
                    }

                    if ($actual_storage_used + filesize("../IMPORTANT/content/".$old_id) <= $config->{"max_user_storage_size"}){
                        $fileid = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));

                        while (TRUE){
                            if (!file_exists("../IMPORTANT/content/".$fileid)){
                                break;
                                break;
                            } else {
                                $fileid = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));
                            }
                        }

                        copy("../IMPORTANT/content/".$old_id, "../IMPORTANT/content/".$fileid);

                        $sql = "INSERT INTO `content`(`metadata`, `size`, `id`, `owner`, `associated_key`, `folder`, `creation_time`) VALUES ('".$metadata."','".$fsize."','".$fileid."','".$owner."','".$associated_key."','".$new_parent_folder."', ".time().")";
                        $conn->query($sql);

                        http_response_code(200);
                        echo '{"success" : true, "message": "File successfully copied"}';

                        $sql = "UPDATE `user` SET `storage_size` = `storage_size` + ".filesize("../IMPORTANT/content/".$old_id)." WHERE `username` = '".$_SESSION["username"]."'";
                        $result = $conn->query($sql);  

                    } else {
                        http_response_code(403);
                        die('{"success": false, "message": "You don\'t have enough storage space !"}');
                    }
                } else {
                    http_response_code(403);
                    die('{"success": false, "message": "You are not connected !"}');
                }
            } else {
                http_response_code(400);
                die('{"success" : false, "message": "File not found"}');
            }
        } else {
            http_response_code(400);
            die('{"success" : false, "message": "Bad Request"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>