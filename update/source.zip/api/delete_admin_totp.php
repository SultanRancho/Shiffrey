<?php
include("../secure/head.php");

header("Content-Type: application/json");

// load the config file
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if (!($_SERVER['REQUEST_METHOD'] === "POST") and !($_SERVER['REQUEST_METHOD'] === "GET")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();

if ($config->{"done"}){
    if (isset($_SESSION["role"]) and $_SESSION["role"] == "admin"){
        $config->{"totp"} = false;
        file_put_contents($config_path, json_encode($config, JSON_PRETTY_PRINT));

        http_response_code(200);
        echo '{"success": true, "message": "TOTP successfully deactivate !"}';
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You aren\'t admin"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}

?>