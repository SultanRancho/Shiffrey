<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    if ($config->{"allow_account_creation"} or $_SESSION["role"] == "admin"){
        if (isset($_POST["username"]) and isset($_POST["password"])){
            if (!empty($_POST["username"]) and !empty($_POST["password"])){
                if (strlen($_POST["username"]) < 500 and strlen($_POST["password"]) < 500){
                        // Connect to the db
                        include("../secure/sql_connection.php");
                        
                        $username = mysqli_real_escape_string($conn, $_POST["username"]);
                        $password = password_hash($_POST["password"], PASSWORD_DEFAULT, ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]);
                        
                        if (isset($_POST["email"])){
                            if (strlen($_POST["email"]) > 500){
                                http_response_code(400);
                                die('{"success": false, "message": "email value is too long."}');
                            }

                            $email = mysqli_real_escape_string($conn, $_POST["email"]);
                        } else {
                            $email = "";
                        }

                        $sql = "SELECT `username`, `password`, `email` FROM `user` WHERE `username` = '".$username."'";
                        $result = $conn->query($sql);

                        $success = false;

                        if (!$result){
                            $success = true;
                        } else {
                            if ($result->num_rows == 0){
                                $success = true;
                            }
                        }

                        if ($success){
                            $sql = "INSERT INTO `user`(`username`, `password`, `email`, `storage_size`, `blocked`) VALUES ('".$username."','".$password."','".$email."', 0, 'false')";
                            $result = $conn->query($sql);

                            echo '{"success": true, "message": "Account successfully created"}';
                        } else {
                            http_response_code(403);
                            die('{"success": false, "message": "This account always exists"}');
                        }

                        $conn->close();
                } else {
                    http_response_code(400);
                    die('{"success": false, "message": "Some value are too long."}');
                }
            } else {
                http_response_code(400);
                die('{"success": false, "message": "Some value are empty while they must not."}');
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "Bad Request"}');
        }
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>