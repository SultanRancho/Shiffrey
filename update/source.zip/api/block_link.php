<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        $username = $_SESSION["username"];
        if (isset($_POST["file_id"])){ 
            $fileid = mysqli_real_escape_string($conn, $_POST["file_id"]);

            $sql = "UPDATE `link` SET `blocked`='true' WHERE `file` = '".$fileid."'";
            $result = $conn->query($sql);
            $conn->close();

            if ($result){
                echo '{"success": true, "message": "Link successfully blocked"}';
            } else {
                http_response_code(500);
                die('{"success": false, "message": "An error has occurred with the database."}');
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "file_id is not specified !"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>