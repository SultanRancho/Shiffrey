<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        if (isset($_POST["id"])){
            $id = basename(mysqli_real_escape_string($conn, $_POST["id"]));

            $sql = "SELECT `owner`, `size`  FROM `content` WHERE `id` = '".$id."'";
            $result = $conn->query($sql);

            if ($result and $result->num_rows == 1){
                while($row = $result->fetch_assoc()){
                    $owner = $row["owner"];
                    $size = $row["size"];
                }

                if ($owner == $_SESSION["unsecure_username"]){
                    @unlink("../IMPORTANT/content/".$id);

                    $sql = "SELECT `storage_size` FROM `user` WHERE `username` = '".$_SESSION["username"]."'";
                    $result = $conn->query($sql);

                    foreach ($result as $row){
                        $storage_size = $row["storage_size"];
                    }

                    $sql = "DELETE FROM `content` WHERE `id` = '".$id."'";
                    $conn->query($sql);

                    $sql = "DELETE FROM `link` WHERE `owner` = '".$_SESSION["username"]."' AND `file` = '".$id."'";
                    $conn->query($sql);

                    $sql = "UPDATE `user` SET `storage_size` = '".($storage_size - $size)."' WHERE `username` = '".$_SESSION["username"]."'";
                    $conn->query($sql);

                    http_response_code(200);
                    die('{"success": true, "message": "File successfully deleted !"}');
                } else {
                    http_response_code(403);
                    die('{"success": false, "message": "You are not connected !"}');
                }
            } else {
                http_response_code(400);
                die('{"success" : false, "message": "File not found"}');
            }
        } else {
            http_response_code(400);
            die('{"success" : false, "message": "Bad Request"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>