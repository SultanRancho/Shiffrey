<?php
    if (!($_SERVER['REQUEST_METHOD'] === "POST")){
        http_response_code(405);
        die('{"success": false, "message": "Bad request method."}');
    }

    include("../secure/head.php");

    header("Content-Type: application/json");

    session_start();

    // load the config file
    $config_path = "../IMPORTANT/config.json";
    $config = json_decode(file_get_contents($config_path, "r"));

    try {
        // Connect to the db
        include("../secure/sql_connection.php");
        // Verify if the session is always activ
        include("../secure/check_connection.php");
    
        if (isset($_SESSION["username"]) and isset($_SESSION["token"])){      
            $sql = "SELECT `totp` FROM `user` WHERE `username` = '".$_SESSION["username"]."'";
            $result = $conn->query($sql);
            
            if ($result and $result->num_rows == 1){
                while($row = $result->fetch_assoc()){

                    if (isset($row["totp"]) and !empty($row["totp"])){
                        if (isset($_POST["totp"])){
                            include("../lib/Base32.php");

                            $totp = json_decode($row["totp"]);
        
                            $time = floor(time() / $totp->{"delay"});
                            $time = hex2bin(str_pad(dechex($time), 16, "0", STR_PAD_LEFT));

                            $secret = base_32_decode($totp->{"secret"});

                            $hash = hash_hmac($totp->{"algorithm"}, $time, $secret);

                            $intValue = intval(substr($hash, -1), 16);
                            $dyn_trunc = intval(substr($hash, $intValue * 2, 8), 16);
                            if ($dyn_trunc > 2147483647) {
                                $dyn_trunc -= 2147483648;
                            }

                            $totp_token = str_pad(strval($dyn_trunc % (10 ** $totp->{"codesize"})), $totp->{"codesize"},"0", STR_PAD_LEFT);

                            if ($totp_token != $_POST["totp"]){
                                http_response_code(403);
                                die('{"success": false, "message": "Bad TOTP token", "code" : "BAD_TOTP"}');    
                            } else {
                                echo '{"success": true, "message": "The code is good", "code" : "GOOD_TOTP"}';
                            }
                        } else {
                            http_response_code(400);
                            die('{"success": false, "message": "Bad request"}');
                        }
                    } else {
                        http_response_code(400);
                        die('{"success": false, "message": "TOTP is not set"}');
                    }
                }
            } else {
                http_response_code(500);
                die('{"success": false, "message": "An error happend with the database"}');
            }
        } else {
            $conn->close();
            http_response_code(403);
            die('{"success": false, "message": "You are not connected"}');
        }
    } catch (Error $e){
        http_response_code(500);
        die(json_encode(array("success" => false, "message" => "An error happend: ".$e)));
    }

?>