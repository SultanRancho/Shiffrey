<?php
    if (!($_SERVER['REQUEST_METHOD'] === "POST")){
        http_response_code(405);
        die('{"success": false, "message": "Bad request method."}');
    }

    include("../secure/head.php");

    header("Content-Type: application/json");

    session_start();

    // load the config file
    $config_path = "../IMPORTANT/config.json";
    $config = json_decode(file_get_contents($config_path, "r"));

    try {
        $token_path = "../IMPORTANT/change_admin_password.tk";

        if (file_exists($token_path)) {
            $token_text = file_get_contents($token_path);
            $token = json_decode($token_text);
            
            if ($token->{"creation_time"} + 600 >= time()) {
                http_response_code(400);
                die('{"success": false, "message": "A request has already been sent. Please wait 10 minutes before sending another."}');
            }
        }

        $new_token = array(
            "token" => bin2hex(random_bytes(15)),
            "creation_time" => time()
        );

        $new_token_text = json_encode($new_token, JSON_PRETTY_PRINT);

        file_put_contents($token_path, $new_token_text);

        if (isset($config->{"admin"}->{"email"}) and !empty($config->{"admin"}->{"email"})){
            // if an email is defined
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
        
            $mail = "Click on this link to change your password : <a href='".htmlspecialchars($config->{"public_name"}."/new_admin_password.php?token=".$new_token->{"token"})."'>Change my password</a>";

            mail($config->{"admin"}->{"email"}, "Shiffrey : Password recovery", $mail, $headers);

            echo '{"success": true, "message": "Token successfully generated. An email had been sent."}';
        } else {
            echo '{"success": true, "message": "Token successfully generated. No email adresse defined."}';
        }
    } catch (Error $e){
        http_response_code(500);
        die(json_encode(array("success" => false, "message" => "An error happend: ".$e)));
    }
?>