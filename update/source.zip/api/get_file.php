<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "GET")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    // If a GET argument 'id' is defined
    if (isset($_GET["id"])){
        $allow_access = FALSE;

        // Id of the file
        $sql_id = mysqli_real_escape_string($conn, $_GET["id"]);
        $path_id = basename($_GET["id"]);

        // Get the inforamtions about the file in the database
        $sql = "SELECT `owner`, `metadata` FROM `content` WHERE id = '".$sql_id."'";
        $result = $conn->query($sql);

        // If something is returned
        if ($result and $result->num_rows > 0){
            // Retrieve informations about the file
            while($row = $result->fetch_assoc()){
                // Owner
                $owner = $row["owner"];
            }

            // Verify the owner
            if (isset($_SESSION["username"]) and isset($_SESSION["unsecure_username"]) and $owner == $_SESSION["unsecure_username"]){
                $allow_access = TRUE;
            } else {
                // If a GET argument 'link_id' is defined
                if (isset($_GET["link_id"])){
                    $sql = "SELECT `blocked`, `id` FROM `link` WHERE `file` = '".$sql_id."'";
                    $result = $conn->query($sql);

                    if ($result and $result->num_rows > 0){
                        while($row = $result->fetch_assoc()){
                            if ($row["id"] == $_GET["link_id"] and $row["blocked"] == "false"){
                                $allow_access = TRUE;
                                break;
                            } else {
                                http_response_code(403);
                                die('{"success": false, "message": "You can\'t access to this file !"}');
                            }
                        }
                    } else {
                        http_response_code(400);
                        die('{"success": false, "message": "This file do not have a link associated with it !"}');
                    }
                }
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "This file do not exist !"}');
        }

        if ($allow_access){
            header('Content-Disposition: attachment; filename="shiffrey-file"');
            
            if (isset($_GET["start"]) and is_numeric($_GET["start"]) 
            and isset($_GET["length"]) and is_numeric($_GET["length"])
            and intval($_GET["start"]) >= 0 and intval($_GET["length"]) >= 0
            and filesize("../IMPORTANT/content/".$path_id) >= intval($_GET["start"]) + intval($_GET["length"])){
                header("Content-Type: application/octet-stream");
                $chunk = fopen("../IMPORTANT/content/".$path_id, "r");
                fseek($chunk, intval($_GET["start"]));
                echo fread($chunk, intval($_GET["length"]));
                fclose($chunk);
            } else {
                if (isset($_GET["length"]) or isset($_GET["start"])){
                    http_response_code(400);
                    die('{"success": false, "message": "Bad request argument"}');
                } else {
                    header("Content-Type: application/octet-stream");
                    echo file_get_contents("../IMPORTANT/content/".$path_id);
                }
            }
        } else {
            http_response_code(403);
            die('{"success": false, "message": "You can\'t access this file"}');
        }
    } else {
        http_response_code(400);
        die('{"success": false, "message": "id GET argument not specified"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>