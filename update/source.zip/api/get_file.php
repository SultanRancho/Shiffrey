<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "GET")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_GET["id"])){
        $allow_access = FALSE;

        $id = basename(mysqli_real_escape_string($conn, $_GET["id"]));
        $sql = "SELECT `owner`, `metadata` FROM `content` WHERE id = '".$id."'";
        
        $result = $conn->query($sql);

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $owner = $row["owner"];
                $filename = basename($row["metadata"]);
            }

            if (isset($_SESSION["username"]) and $owner == $_SESSION["unsecure_username"]){
                $allow_access = TRUE;
            } else {
                if (isset($_GET["link_id"])){
                    $sql = "SELECT `blocked`, `id` FROM `link` WHERE `file` = '".$id."'";
                    $result = $conn->query($sql);

                    if ($result and $result->num_rows > 0){
                        while($row = $result->fetch_assoc()){
                            if ($row["id"] == $_GET["link_id"] and $row["blocked"] == "false"){
                                $allow_access = TRUE;
                                break;
                            } else {
                                http_response_code(403);
                                die('{"success": false, "message": "You can\'t access to this file !"}');
                            }
                        }
                    }
                }
            }
        }

        if ($allow_access){
            header('Content-Disposition: attachment; filename="'.$filename.'"');
            
            if (isset($_GET["start"]) and is_numeric($_GET["start"]) 
            and isset($_GET["length"]) and is_numeric($_GET["length"])
            and intval($_GET["start"]) >= 0 and intval($_GET["length"]) >= 0
            and filesize("../IMPORTANT/content/".$id) >= intval($_GET["start"]) + intval($_GET["length"])){
                $chunk = fopen("../IMPORTANT/content/".$id, "r");
                fseek($chunk, intval($_GET["start"]));
                echo fread($chunk, intval($_GET["length"]));
                fclose($chunk);
            } else {
                if (isset($_GET["length"]) or isset($_GET["start"])){
                    http_response_code(400);
                    die('{"success": false, "message": "Bad request argument"}');
                } else {
                    echo file_get_contents("../IMPORTANT/content/".$id);
                }
            }
        } else {
            http_response_code(404);
            die('{"success": false, "message": "This file do not exist !"}');
        }
    } else {
        http_response_code(400);
        die('{"success": false, "message": "id GET argument not specified"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>