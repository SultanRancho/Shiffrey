<?php
include("../secure/head.php");

header("Content-Type: application/json");

session_start();

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    die('{"success": false, "message": "Bad request method."}');
}

// load the config file
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"} or $config->{"admin"}->{"email"}){
    if (file_exists("../IMPORTANT/password_recovery_token.tk")){
        $content = json_decode(file_get_contents("../IMPORTANT/password_recovery_token.tk"));

        if ($content->{"creation_time"} + 300 > time()){
            die('{"success": false, "message": "5 minutes must elapse between two requests."}');
        }
    }

    function customErrorHandler($errno, $errstr) {    
        die('{"success": false, "message": "An error occured."}');
    }
    
    // Set the custom error handler function
    set_error_handler("customErrorHandler");

    $tokenstr = bin2hex(random_bytes(50));
    $token = array("token" => $tokenstr, "creation_time" => time());
    
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
    $mail = "Click on this link to change your password : <a href='".htmlspecialchars($config->{"public_name"}."/change_password.php?token=".$tokenstr)."'>Change my password</a>";

    mail($config->{"admin"}->{"email"}, "Password recovery", $mail, $headers);

    file_put_contents("../IMPORTANT/password_recovery_token.tk", json_encode($token));
    
    echo '{"success": true, "message": "Mail successfully sent !"}';

    restore_error_handler();
} else {
    if ($config->{"done"}){
        http_response_code(400);
        die('{"success": false, "message": "No admin email entered"}');
    } else {
        http_response_code(400);
        die('{"success": false, "message": "Init isn\'t done"}');
    }
   
}
?>