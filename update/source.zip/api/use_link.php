<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "GET")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_GET["link_id"])){
        $linkid = mysqli_real_escape_string($conn, $_GET["link_id"]);

        $sql = "SELECT `id`, `key`, `blocked`, `file`, `name` FROM `link` WHERE `id` = '".$linkid."'";
        $result = $conn->query($sql);

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                if ($row["blocked"] == 'false'){
                    $blocked = FALSE;
                } else {
                    $blocked = TRUE;
                }

                $id = $row["id"];
                $key = $row["key"];
                $file = $row["file"];

                $sql = "SELECT `metadata`, `size` FROM `content` WHERE `id` = '".$row["file"]."'";
                $result = $conn->query($sql);

                if ($result and $result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                        $metadata = $row["metadata"];
                        $size = $row["size"];
                        break;
                    }

                        
                    if (!$blocked){
                        echo json_encode(array("success" => TRUE, "data" =>  array("id" => $id, "key" => $key, "file" => $file, "metadata" => $metadata, "file_size" => intval($size))), JSON_PRETTY_PRINT);
                    } else {
                        http_response_code(403);
                        echo '{"success": false, "message": "This link is blocked"}';
                    }
                } else {
                    http_response_code(500);
                    echo '{"success": false, "message": "An internal servor error happend, plesae contact your admin."}';
                }

                break;
            }
        } else {
            http_response_code(404);
            echo '{"success": false, "message": "This link do not exist"}';
        }
    } else {
        http_response_code(400);
        die('{"success": false, "message": "link_id is not specified !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}