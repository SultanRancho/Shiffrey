<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        if (isset($_POST["id"]) and isset($_POST["parent_folder"])){
            $id = mysqli_real_escape_string($conn, $_POST["id"]);

            // Get the actual storage
            $actual_storage_used = NULL;
            $sql = "SELECT `storage_size` FROM `user` WHERE `username` = '".$_SESSION["username"]."'";
            $result = $conn->query($sql);
            foreach ($result as $row){
                $actual_storage_used = intval($row["storage_size"]);
                if ($actual_storage_used == NULL){
                    $actual_storage_used = 0;
                }
            }

            // Verify if the new folder exist
            $new_parent_folder = mysqli_real_escape_string($conn, $_POST["parent_folder"]);
            if ($new_parent_folder != -1){
                $sql = "SELECT `id` FROM `folders` WHERE `id` = '".$new_parent_folder."'";
                $result = $conn->query($sql);

                if (!($result and $result->num_rows > 0)){
                    die('{"success" : false, "message": "The target folder does not exist"}');
                }
            }

            // Verify if the folder exist
            $sql = "SELECT * FROM `folders` WHERE `id` = '".$id."'";
            $result = $conn->query($sql);
            if (!($result and $result->num_rows > 0)){
                die('{"success" : false, "message": "The folder does not exist"}');
            } else {
                if ($result and $result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                        $old_folder = [$row["id"], $row["parent_folder"], $row["metadata"], $row["owner"]];
                    }
                }
            }
            
            // Get the folders list
            $sql = "SELECT * FROM `folders` WHERE `owner` = '".$_SESSION["username"]."'";
            $folders = $conn->query($sql);

            $folders_list = array();

            if ($folders and $folders->num_rows > 0){
                while($row = $folders->fetch_assoc()){
                    array_push($folders_list, [$row["id"], $row["parent_folder"], $row["metadata"], $row["owner"]]);
                }
            }

            // Get the files list
            $sql = "SELECT * FROM `content` WHERE `owner` = '".$_SESSION["username"]."'";
            $files = $conn->query($sql);

            $files_list = array();

            if ($files and $folders->num_rows > 0){
                while($row = $files->fetch_assoc()){
                    array_push($files_list, [$row["metadata"], $row["size"], $row["id"], $row["owner"], $row["associated_key"], $row["folder"]]);
                }
            }

            $correspondance = [
                $new_parent_folder => $new_parent_folder
            ];

            // Get a list of the folders
            $seeking_folds = array($old_folder);
            $result_fold = array();

            while (TRUE){
                $next_seeking_fold = array();

                foreach ($folders_list as $dir){
                    for ($i = 0; $i < sizeof($seeking_folds); $i++){
                        if ($dir[1] == $seeking_folds[$i][0]){
                            array_push($next_seeking_fold, $dir);
                        }
                    }
                }


                if ($next_seeking_fold){
                    $seeking_folds = $next_seeking_fold;
                    
                    foreach ($seeking_folds as $append){
                        array_push($result_fold, $append);
                    }

                    foreach ($next_seeking_fold as $f){
                        while (TRUE){
                            $new_name = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));

                            $find = FALSE;

                            foreach ($folders_list as $li){
                                if ($new_name == $li){
                                    $find = TRUE;
                                }
                            }

                            if (!$find){
                                $correspondance[$f[0]] = $new_name;
                                break;
                            }
                        }
                    }
                } else {
                    break;
                }
            }

            while (TRUE){
                $new_name = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));

                $find = FALSE;

                foreach ($folders_list as $li){
                    if ($new_name == $li){
                        $find = TRUE;
                    }
                }

                if (!$find){
                    $correspondance[$old_folder[0]] = $new_name;
                    break;
                }
            }

            $seeking_folds = $result_fold;

            // Add the original folder if necessary
            if (!in_array($old_folder, $seeking_folds)){
                array_push($seeking_folds, $old_folder);

                while (TRUE){
                    $new_name = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));
    
                    $find = FALSE;
    
                    foreach ($folders_list as $li){
                        if ($new_name == $li){
                            $find = TRUE;
                        }
                    }
    
                    if (!$find){
                        $correspondance[$old_folder[1]] = $new_parent_folder;
                        break;
                    }
                }
            }

            // Get a list of the files
            $seeking_files = array();
            $fold_size = 0;

            foreach ($seeking_folds as $dir){
                foreach ($files_list as $fl){
                    if ($fl[5] == $dir[0]){
                        array_push($seeking_files, $fl);
                        $fold_size += intval($fl[1]);
                    }
                }
            }

            if ($fold_size + $actual_storage_used <= $config->{"max_user_storage_size"}){

                foreach ($seeking_folds as $fol){
                    $sql = "INSERT INTO `folders`(`id`, `parent_folder`, `metadata`, `owner`) VALUES ('".$correspondance[$fol[0]]."','".$correspondance[$fol[1]]."','".$fol[2]."','".$fol[3]."')";
                    $result = $conn->query($sql);
                }

                $files_size = 0;

                foreach ($seeking_files as $fl){
                    $fileid = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));

                    while (TRUE){
                        if (!file_exists("../IMPORTANT/content/".$fileid)){
                            break;
                            break;
                        } else {
                            $fileid = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));
                        }
                    }

                    $metadata = $fl[0];
                    $fsize = $fl[1];
                    $owner = $fl[3];
                    $associated_key = $fl[4];
                    $folder = $fl[5];

                    $files_size += intval($fsize);
                    
                    $sql = "INSERT INTO `content`(`metadata`, `size`, `id`, `owner`, `associated_key`, `folder`, `creation_time`) VALUES ('".$metadata."','".$fsize."','".$fileid."','".$owner."','".$associated_key."','".$correspondance[$folder]."', ".time().")";
                    $result = $conn->query($sql);

                    copy("../IMPORTANT/content/".$fl[2], "../IMPORTANT/content/".$fileid);
                }   

                http_response_code(200);
                echo '{"success" : true, "message": "Folder successfully copied"}';

                $sql = "UPDATE `user` SET `storage_size` = `storage_size` + ".$files_size." WHERE `username` = '".$_SESSION["username"]."'";
                $result = $conn->query($sql);  
            } else {
                die('{"success" : false, "message": "You don\'t have enough storage space !"}');
            }
        } else {
            http_response_code(400);
            die('{"success" : false, "message": "Bad Request"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>