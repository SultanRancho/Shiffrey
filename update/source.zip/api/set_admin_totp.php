<?php
include("../secure/head.php");

header("Content-Type: application/json");

// load the config file
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();

if ($config->{"done"}){
    if (isset($_SESSION["role"]) and $_SESSION["role"] == "admin"){
        if (isset($_POST["algorithm"]) and isset($_POST["code_size"]) and isset($_POST["secret_size"]) and isset($_POST["delay"])
        and is_numeric($_POST["code_size"]) and is_numeric($_POST["secret_size"]) and is_numeric($_POST["delay"])){
            $code_size = intval($_POST["code_size"]);
            $secret_size = intval($_POST["secret_size"]);
            $delay = intval($_POST["delay"]);
            $algorithm = $_POST["algorithm"];

            if (($code_size == 6 or $code_size == 8) 
                and ($secret_size >= 20 and $secret_size <= 512)
                and ($delay >= 5 and $secret_size <= 300)
                and ($algorithm == "sha1" or $algorithm == "sha256" or $algorithm == "sha512")){

                include("../lib/Base32.php");
                $secret = base_32_encode(openssl_random_pseudo_bytes($secret_size));

                $recovery_code = array();

                for ($a = 0; $a < 32; $a++){
                    $new_rec_code = bin2hex(openssl_random_pseudo_bytes(5))."-".bin2hex(openssl_random_pseudo_bytes(5));
                    array_push($recovery_code, $new_rec_code);
                }

                $totp_array = array(
                    "codesize" => $code_size,
                    "secret_size" => $secret_size,
                    "algorithm" => $algorithm,
                    "secret" => $secret,
                    "delay" => $delay,
                    "recovery_code" => $recovery_code
                );

                $config->{"totp"} = $totp_array;

                file_put_contents($config_path, json_encode($config, JSON_PRETTY_PRINT));

                echo json_encode($totp_array);
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "Bad request"}');
        }
    } else {
        $conn->close();
        http_response_code(403);
        die('{"success": false, "message": "You aren\'t admin"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}

?>