<?php
// Get the target name (without the arguments)
$path = $_SERVER['REQUEST_URI'];
if (str_contains($path, "?")){
    $path = substr($path, 0, strpos($path, "?"));
}
// Sanitize
$path = basename($path);

if ($path != ".htaccess"){
    $complete_path = $path.".php";
    if (file_exists($complete_path) && in_array($complete_path, scandir("."))){
            require($path.".php");
    } else {
        http_response_code(404);
        header("Content-Type: application/json");
        echo '{"success": false, "message": "This API endpoint does not exist"}';
    }
}
?>
