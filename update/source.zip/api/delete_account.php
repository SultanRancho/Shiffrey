<?php
include("../secure/head.php");

header("Content-Type: application/json");
session_start();

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        $sql = "SELECT `id` FROM `content` WHERE `owner` = '".$_SESSION["username"]."'";
        $result = $conn->query($sql);

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){  
                $path = "../IMPORTANT/content/".basename($row["id"]);
                @unlink($path);
            }
        }

        $sql = "DELETE FROM `content` WHERE `owner` = '".$_SESSION["username"]."'";
        $result = $conn->query($sql);

        $sql = "DELETE FROM `user` WHERE `username` = '".$_SESSION["username"]."'";
        $result = $conn->query($sql);

        $sql = "DELETE FROM `folders` WHERE `owner` = '".$_SESSION["username"]."'";
        $result = $conn->query($sql);

        $sql = "DELETE FROM `sessions` WHERE `username` = '".$_SESSION["username"]."' AND `role` = 'other'";
        $result = $conn->query($sql);

        unset($_SESSION["username"]);
        unset($_SESSION["unsecure_username"]);
        $_SESSION["token"] = "";

        $conn->close();

        echo '{"success": true, "message": "Account successfully deleted !"}';
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>