<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");
    
    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        if (isset($_POST["new_keys"]) and !empty($_POST["new_keys"])){
                try {
                    $new_keys = json_decode($_POST["new_keys"]);

                    if (count($new_keys) == 0){
                        die('{"success" : false, "message": "The value of new_keys musn\'t be empty."}');
                    }

                    if (!is_array($new_keys)){
                        die('{"success" : false, "message": "The value of new_keys is not a valid array."}');
                    }

                    $arg_size = count($new_keys);

                    for ($i = 0; $i < $arg_size; $i++){
                        if (!is_array($new_keys[$i])){
                            die('{"success" : false, "message": "A value of new_keys is not an array."}');
                        } else {
                            if (count($new_keys[$i]) != 2){
                                die('{"success" : false, "message": "The datas sent are invalid."}');
                            } else {
                                if (!is_string($new_keys[$i][0]) or !is_string($new_keys[$i][1])){
                                    die('{"success" : false, "message": "The datas sent are invalid."}');
                                }
                            }
                        }
                    }
         
                    for ($a = 0; $a < $arg_size; $a++){
                        $associated_key = mysqli_real_escape_string($conn, $new_keys[$a][1]);
                        $ident = mysqli_real_escape_string($conn, $new_keys[$a][0]);

                        $sql = "UPDATE `content` SET `associated_key`='".$associated_key."' WHERE `id` = '".$ident."' AND `owner` = '".$_SESSION["username"]."'";
                        
                        if (!$conn->query($sql)){
                            die('{"success" : false, "message": "An error happend with the database for new_keys."}');   
                        }
                    }
                   
                } catch (Exception $e) {
                    die('{"success" : false, "message": "An error with the new_keys content happend."}');
                }
        }

        if ((isset($_POST["new_link_keys"]) and !empty($_POST["new_link_keys"]))){
            try {
                $new_keys = json_decode($_POST["new_link_keys"]);

                if (count($new_keys) == 0){
                    die('{"success" : false, "message": "The value of new_link_keys musn\'t be empty."}');
                }

                if (!is_array($new_keys)){
                    die('{"success" : false, "message": "The value of new_link_keys is not a valid array."}');
                }

                $arg_size = count($new_keys);

                for ($i = 0; $i < $arg_size; $i++){
                    if (!is_array($new_keys[$i])){
                        die('{"success" : false, "message": "A value of new_link_keys is not an array."}');
                    } else {
                        if (count($new_keys[$i]) != 2){
                            die('{"success" : false, "message": "The datas sent are invalid."}');
                        } else {
                            if (!is_string($new_keys[$i][0]) or !is_string($new_keys[$i][1])){
                                die('{"success" : false, "message": "The datas sent are invalid."}');
                            }
                        }
                    }
                }

                for ($a = 0; $a < $arg_size; $a++){
                    $name = mysqli_real_escape_string($conn, $new_keys[$a][1]);
                    $ident = mysqli_real_escape_string($conn, $new_keys[$a][0]);

                    $sql = "UPDATE `link` SET `name`='".$name."'  WHERE `id` = '".$ident."' AND `owner` = '".$_SESSION["username"]."'";
                    if (!$conn->query($sql)){
                        die('{"success" : false, "message": "An error happend with the database for new_link_keys."}');   
                    }
                }

            } catch (Exception $e) {
                die('{"success" : false, "message": "An error with the new_keys content happend."}');
            }
        }

        if ((isset($_POST["new_folders"]) and !empty($_POST["new_folders"]))){
            try {
                $new_keys = json_decode($_POST["new_folders"]);

                if (count($new_keys) == 0){
                    die('{"success" : false, "message": "The value of new_folders musn\'t be empty."}');
                }

                if (!is_array($new_keys)){
                    die('{"success" : false, "message": "The value of new_folders is not a valid array."}');
                }

                $arg_size = count($new_keys);

                for ($i = 0; $i < $arg_size; $i++){
                    if (!is_array($new_keys[$i])){
                        die('{"success" : false, "message": "A value of new_folders is not an array."}');
                    } else {
                        if (count($new_keys[$i]) != 2){
                            die('{"success" : false, "message": "The datas sent are invalid."}');
                        } else {
                            if (!is_string($new_keys[$i][0]) or !is_string($new_keys[$i][1])){
                                die('{"success" : false, "message": "The datas sent are invalid."}');
                            }
                        }
                    }
                }

                for ($a = 0; $a < $arg_size; $a++){
                    $metadata = mysqli_real_escape_string($conn, $new_keys[$a][1]);
                    $ident = mysqli_real_escape_string($conn, $new_keys[$a][0]);

                    $sql = "UPDATE `folders` SET `metadata`='".$metadata."'  WHERE `id` = '".$ident."' AND `owner` = '".$_SESSION["username"]."'";

                    if (!$conn->query($sql)){
                        die('{"success" : false, "message": "An error happend with the database for new_folders."}');   
                    }
                }

            } catch (Exception $e) {
                die('{"success" : false, "message": "An error with the new_keys content happend."}');
            }
        }

        if (isset($_POST["new_password"])){
            if (strlen($_POST["new_password"]) < 1000){            
                try {
                    $password = password_hash($_POST["new_password"], PASSWORD_DEFAULT, ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]);
                    
                    $sql = "UPDATE `user` SET `password`='".$password."' WHERE `username` = '".$_SESSION["username"]."'";
                    
                    $conn->query($sql);
                } catch (Exception $e) {
                    die('{"success" : false, "message": "An error while the update."}');
                }
            } else {
                http_response_code(400);
                die('{"success": false, "message": "Your new password is too long."}');
            }
        }

        $conn->close();
        echo '{"success": true, "message": "The operation has been successfully completed"}';
    } else {
        $conn->close();
        http_response_code(403);
        die('{"success": false, "message": "You are not connected"}');
    }

} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}