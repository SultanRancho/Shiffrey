<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
// load the config file
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_POST["password"])){
        if (password_verify($_POST["password"], $config->{"admin"}->{"password"})){
            if (isset($config->{"totp"}) and $config->{"totp"}){
                if (isset($_POST["totp"])){
                    include("../lib/Base32.php");
    
                    $totp = $config->{"totp"};
    
                    if (str_contains($_POST["totp"], "-")){
                        if (!in_array($_POST["totp"], $totp->{"recovery_code"})){
                            http_response_code(403);
                            die('{"success": false, "message": "Bad recovery token. They cannot be used twice.", "code" : "BAD_RECOVERY"}');    
                        } else {
                            array_splice($totp->{"recovery_code"}, array_search($_POST["totp"], $totp->{"recovery_code"}), 1);
                            file_put_contents($config_path, json_encode($config, JSON_PRETTY_PRINT));
                        }
                    } else {
                        $time = floor(time() / $totp->{"delay"});
                        $time = hex2bin(str_pad(dechex($time), 16, "0", STR_PAD_LEFT));
    
                        $secret = base_32_decode($totp->{"secret"});
    
                        $hash = hash_hmac($totp->{"algorithm"}, $time, $secret);
    
                        $intValue = intval(substr($hash, -1), 16);
                        $dyn_trunc = intval(substr($hash, $intValue * 2, 8), 16);
                        if ($dyn_trunc > 2147483647) {
                            $dyn_trunc -= 2147483648;
                        }
    
                        $totp_token = str_pad(strval($dyn_trunc % (10 ** $totp->{"codesize"})), $totp->{"codesize"},"0", STR_PAD_LEFT);
    
                        if ($totp_token != $_POST["totp"]){
                            http_response_code(403);
                            die('{"success": false, "message": "Bad TOTP token", "code" : "BAD_TOTP"}');    
                        }
                    }
                } else {
                    http_response_code(400);
                    die('{"success": false, "message": "Bad request, TOTP needed", "code" : "NEED_TOTP"}');
                }
            }
            
            // Connect the admin
            $admintoken = bin2hex(random_bytes(50));

            $start = time();

            $sql = "INSERT INTO `sessions`(`role`, `token`, `creation`, `username`) VALUES ('admin', '".$admintoken."', '".$start."', '')";
            $result = $conn->query($sql);

            $_SESSION["admintoken"] = $admintoken;
            $_SESSION["role"] = "admin";
            $_SESSION["session_start"] = $start;

            echo '{"success": true, "message": "Login as admin"}';
        } else {
            http_response_code(403);
            die('{"success": false, "message": "Bad password"}');
        }
    
    $conn->close();
    
    } else {
        http_response_code(400);
        die('{"success": false, "message": "Bad Request"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}


?>