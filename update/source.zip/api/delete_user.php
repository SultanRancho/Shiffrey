<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if ($_SESSION["role"] == "admin"){
        if (isset($_POST["username"])){
            $username = mysqli_real_escape_string($conn, $_POST["username"]);

            $sql = "SELECT `id` FROM `content` WHERE `owner` = '".$username."'";
            $result = $conn->query($sql);

            if ($result){
                foreach ($result as $row){
                    $path = "../IMPORTANT/content/".$row["id"];

                    if (file_exists($path)){
                        unlink("../IMPORTANT/content/".$row["id"]);
                    }
                }
            } else {
                http_response_code(500);
                die('{"success": false, "message": "An error has occurred with the database."}');
            }
            
            $sql = "DELETE FROM `content` WHERE `owner` = '".$username."'";
            $result = $conn->query($sql);

            if (!$result){
                http_response_code(500);
                die('{"success": false, "message": "An error has occurred with the database."}');
            }

            $sql = "DELETE FROM `folders` WHERE `owner` = '".$username."'";
            $result = $conn->query($sql);

            if (!$result){
                http_response_code(500);
                die('{"success": false, "message": "An error has occurred with the database."}');
            }

            $sql = "DELETE FROM `link` WHERE `owner` = '".$username."'";
            $result = $conn->query($sql);

            if (!$result){
                http_response_code(500);
                die('{"success": false, "message": "An error has occurred with the database."}');
            }

            $sql = "DELETE FROM `sessions` WHERE `username` = '".$username."'";
            $result = $conn->query($sql);

            if (!$result){
                http_response_code(500);
                die('{"success": false, "message": "An error has occurred with the database."}');
            }

            $sql = "DELETE FROM `user` WHERE `username` = '".$username."'";
            $result = $conn->query($sql);

            if (!$result){
                http_response_code(500);
                die('{"success": false, "message": "An error has occurred with the database."}');
            } else {
                http_response_code(200);
                echo '{"success": true, "message": "User successfully deleted !"}';
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "Bad Request"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You can\'t access this ressource !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>