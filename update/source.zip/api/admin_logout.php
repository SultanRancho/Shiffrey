<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
// load the config file
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    if (isset($_SESSION["admintoken"])){
        // Connect to the db
        include("../secure/sql_connection.php");

        $sql = "DELETE FROM `sessions` WHERE `token` = '".$_SESSION["admintoken"]."' AND `role` = 'admin'";
        $result = $conn->query($sql);

        $_SESSION["role"] = "other";
        unset($_SESSION["admintoken"]);

        $conn->close();

        echo '{"success": true, "message": "Successfully disconnected"}';
    } else {
        echo '{"success": false, "message": "You aren\'t connected as admin"}';
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}

?>