<?php
    if (!($_SERVER['REQUEST_METHOD'] === "POST")){
        http_response_code(405);
        die('{"success": false, "message": "Bad request method."}');
    }

    include("../secure/head.php");

    header("Content-Type: application/json");

    session_start();

    // load the config file
    $config_path = "../IMPORTANT/config.json";
    $config = json_decode(file_get_contents($config_path, "r"));

    try {
        // Connect to the db
        include("../secure/sql_connection.php");
        // Verify if the session is always activ
        include("../secure/check_connection.php");
    
        if (isset($_SESSION["username"]) and isset($_SESSION["token"])){      
            $sql = "UPDATE `user` SET `totp`='' WHERE `username` = '".$_SESSION["username"]."'";
            $result = $conn->query($sql);

            if ($result){
                echo '{"success": true, "message": "TOTP successfully deactivate !"}';
            } else {
                http_response_code(500);
                die('{"success": false, "message": "An error happend with the database"}');
            }
        } else {
            $conn->close();
            http_response_code(403);
            die('{"success": false, "message": "You are not connected"}');
        }
    } catch (Error $e){
        http_response_code(500);
        die(json_encode(array("success" => false, "message" => "An error happend: ".$e)));
    }

?>