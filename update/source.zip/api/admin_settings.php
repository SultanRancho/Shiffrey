<?php
include("../secure/head.php");

header("Content-Type: application/json");

// load the config file
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if (!($_SERVER['REQUEST_METHOD'] === "POST") and !($_SERVER['REQUEST_METHOD'] === "GET")){
    die('{"success": false, "message": "Bad request method."}');
}

session_start();

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["role"]) and $_SESSION["role"] == "admin"){
        if ($_SERVER['REQUEST_METHOD'] === "POST"){
            if (isset($_POST["access"])){
                $access = $_POST["access"];
                if ($access == "true"){
                    $config->{"allow_account_creation"} = TRUE;
                } else if ($access == "false") {
                    $config->{"allow_account_creation"} = FALSE;
                }
            }
    
            if (isset($_POST["password"])){
                $new_password = password_hash($_POST["password"], PASSWORD_ARGON2I, ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]); 
                $config->{"admin"}->{"password"} = $new_password;
    
                $sql = "DELETE FROM `sessions` WHERE `role` = 'admin'";
                $result = $conn->query($sql);
    
                // Connect the admin
                $admintoken = bin2hex(random_bytes(50));

                $sql = "INSERT INTO `sessions`(`role`, `token`, `creation`, `username`) VALUES ('admin', '".$admintoken."', '".$_SESSION["session_start"]."', '')";
                $result = $conn->query($sql);

                $_SESSION["admintoken"] = $admintoken;
            }
    
            if (isset($_POST["email"])){
                $config->{"admin"}->{"email"} = $_POST["email"];
            }

            if (isset($_POST["public_name"])){
                $config->{"public_name"} = $_POST["public_name"];
            }
    
            if (isset($_POST["show_email"])){
                if ($_POST["show_email"] == "true"){
                    $config->{"admin"}->{"show_email"} = TRUE;
                } else {
                    $config->{"admin"}->{"show_email"} = FALSE;
                }
            }
            
            if (isset($_POST["file_size"])){
                if (is_numeric($_POST["file_size"])){
                    $config->{"max_file_size"} = intval($_POST["file_size"]);

                    if ($config->{"max_file_size"} >= 1000000000){
                        $maxsize = strval($config->{"max_file_size"} / 1000000000)."G";
                    } else if ($config->{"max_file_size"} >= 1000000){
                        $maxsize = strval($config->{"max_file_size"} / 1000000)."M";
                    } else if ($config->{"max_file_size"} >= 1000){
                        $maxsize = strval($config->{"max_file_size"} / 1000)."K";
                    } else {
                        $maxsize = strval($config->{"max_file_size"})."o";
                    }

                    file_put_contents("upload/.htaccess", "php_value post_max_size ".$maxsize);
                }
            }
    
            if (isset($_POST["max_user_storage_size"])){
                if (is_numeric($_POST["max_user_storage_size"])){
                    $config->{"max_user_storage_size"} = intval($_POST["max_user_storage_size"]);
                }
            }
            
            echo '{"success": true, "message": "Settings applied"}';
    
            file_put_contents($config_path, json_encode($config, JSON_PRETTY_PRINT));
        } else if ($_SERVER['REQUEST_METHOD'] === "GET"){
            $settings = array(
                "allow_account_creation" => $config->{"allow_account_creation"},
                "max_file_size" => $config->{"max_file_size"},
                "max_user_storage_size" => $config->{"max_user_storage_size"},
                "public_name" => $config->{"public_name"}
            );
            
            $data = array(
                "success" => true,
                "data" => $settings
            );

            echo json_encode($data, JSON_PRETTY_PRINT);
        }

        $conn->close();
    } else {
        $conn->close();
        http_response_code(403);
        die('{"success": false, "message": "You aren\'t admin"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}

?>