<?php
    if (!($_SERVER['REQUEST_METHOD'] === "POST")){
        http_response_code(405);
        die('{"success": false, "message": "Bad request method."}');
    }

    include("../secure/head.php");

    header("Content-Type: application/json");

    session_start();

    // load the config file
    $config_path = "../IMPORTANT/config.json";
    $config = json_decode(file_get_contents($config_path, "r"));

    try {
        $token_path = "../IMPORTANT/change_admin_password.tk";

        if (file_exists($token_path)) {
            $token_text = file_get_contents($token_path);
            $token = json_decode($token_text);

            if ($token->{"creation_time"} + 600 < time()) {
                http_response_code(400);
                die('{"success": false, "message": "Password change request has expired"}');
            }

            $isset_token = isset($_POST["token"]);

            if ($isset_token and $_POST["token"] == $token->{"token"}){
                $new_password = password_hash($_POST["password"], PASSWORD_ARGON2I, ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]); 
                $config->{"admin"}->{"password"} = $new_password;
                file_put_contents($config_path, json_encode($config, JSON_PRETTY_PRINT));
                unlink($token_path);
                echo '{"success": true, "message": "Change applied"}';
            } else {
                if ($isset_token){
                    http_response_code(403);
                    die('{"success": false, "message": "No token specified"}');
                } else {
                    http_response_code(403);
                    die('{"success": false, "message": "Bad token"}');
                } 
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "Please request a password change before submitting a new password"}');
        }
    } catch (Error $e){
        http_response_code(500);
        die(json_encode(array("success" => false, "message" => "An error happend: ".$e)));
    }
?>