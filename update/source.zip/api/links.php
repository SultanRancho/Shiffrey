<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "GET")){
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        $username = $_SESSION["username"];
        $sql = "SELECT * FROM `link` WHERE `owner` = '".$username."'";
        
        if (isset($_GET["start"]) and isset($_GET["length"])){
            $start = mysqli_real_escape_string($conn, $_GET["start"]);
            $length = mysqli_real_escape_string($conn, $_GET["length"]);

            if (is_numeric($start) and is_numeric($length)){
                $sql .= " LIMIT ".$start.",".($start + $length);
            } else {
                die('{"success": false, "message": "\'start\' and \'length\' GET argument must be a number"}');
            }   
        } else {
            if (!isset($_GET["start"]) and isset($_GET["length"])){
                die('{"success": false, "message": "\'start\' GET argument must be defined"}');
            }

            if (!isset($_GET["length"]) and isset($_GET["start"])){
                die('{"success": false, "message": "\'length\' GET argument must be defined"}');
            }
        }

        $result = $conn->query($sql);

        $list = array();

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                if ($row["blocked"] == "false"){
                    $blocked = FALSE;
                } else {
                    $blocked = TRUE;
                }
                array_push($list, array("file" => $row["file"], "id" => $row["id"], "name" => $row["name"], "key" => $row["key"], "blocked" => $row["blocked"]));
            }
        }

        echo json_encode(array("success" => TRUE, "data" => $list), JSON_PRETTY_PRINT);
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>