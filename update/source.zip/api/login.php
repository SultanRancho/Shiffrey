<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();

$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    if (isset($_POST["username"]) and isset($_POST["password"])){
        // Connect to the db
        include("../secure/sql_connection.php");
        
        // Get the login informations
        $username = mysqli_real_escape_string($conn, $_POST["username"]);
        $sql = "SELECT `password`, `blocked`, `totp` FROM `user` WHERE `username` = '".$username."'";

        $password = $_POST["password"];

        $result = $conn->query($sql);

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                if (password_verify($password, $row["password"])){
                    if (isset($row["totp"]) and !empty($row["totp"])){
                        if (isset($_POST["totp"])){
                            include("../lib/Base32.php");

                            $totp = json_decode($row["totp"]);
    
                            if (str_contains($_POST["totp"], "-")){
                                if (!in_array($_POST["totp"], $totp->{"recovery_code"})){
                                    http_response_code(403);
                                    die('{"success": false, "message": "Bad recovery token. They cannot be used twice.", "code" : "BAD_RECOVERY"}');    
                                } else {
                                    array_splice($totp->{"recovery_code"}, array_search($_POST["totp"], $totp->{"recovery_code"}), 1);
                                    $new_totp = json_encode($totp);
                                    $sql = "UPDATE `user` SET `totp`='".mysqli_real_escape_string($conn, $new_totp)."' WHERE `username` = '".$username."'";
                                    $result = $conn->query($sql);
                                }
                            } else {
                                $time = floor(time() / $totp->{"delay"});
                                $time = hex2bin(str_pad(dechex($time), 16, "0", STR_PAD_LEFT));
    
                                $secret = base_32_decode($totp->{"secret"});
        
                                $hash = hash_hmac($totp->{"algorithm"}, $time, $secret);
        
                                $intValue = intval(substr($hash, -1), 16);
                                $dyn_trunc = intval(substr($hash, $intValue * 2, 8), 16);
                                if ($dyn_trunc > 2147483647) {
                                    $dyn_trunc -= 2147483648;
                                }
    
                                $totp_token = str_pad(strval($dyn_trunc % (10 ** $totp->{"codesize"})), $totp->{"codesize"},"0", STR_PAD_LEFT);
        
                                if ($totp_token != $_POST["totp"]){
                                    http_response_code(403);
                                    die('{"success": false, "message": "Bad TOTP token", "code" : "BAD_TOTP"}');    
                                }
                            }
                        } else {
                            http_response_code(400);
                            die('{"success": false, "message": "Bad request, TOTP needed", "code" : "NEED_TOTP"}');
                        }
                    }

                    if ($row["blocked"] == "false"){
                        $blocked = FALSE;
                    } else {
                        $blocked = TRUE;
                    }

                    if (!$blocked){
                        // Connect the user
                        $token = bin2hex(random_bytes(50));

                        $sql = "INSERT INTO `sessions`(`role`, `token`, `creation`, `username`) VALUES ('other', '".$token."', '".time()."', '".$username."')";
                        $result = $conn->query($sql);

                        $_SESSION["username"] = $username;
                        $_SESSION["unsecure_username"] = $_POST["username"];
                        $_SESSION["token"] = $token;

                        $response_text = array("success" => TRUE, "message" => "Successfully connected !");

                        http_response_code(200);
                        echo json_encode($response_text);

                        $storage_size = 0;
                        
                        $sql = "SELECT `size` FROM `content` WHERE `owner` = '".$username."'";
                        $result = $conn->query($sql);

                        if ($result and $result->num_rows > 0){
                            while($row = $result->fetch_assoc()){  
                                $storage_size += $row["size"];
                            }
                        }
                        
                        $sql = "UPDATE `user` SET `storage_size` = ".$storage_size." WHERE `username` = '".$_SESSION["username"]."'";
                        $result = $conn->query($sql);  
                       
                        break;
                    } else {
                        http_response_code(403);
                        die('{"success": false, "message": "You are blocked."}');
                    }
                } else {
                    http_response_code(403);
                    die('{"success": false, "message": "Bad password"}');
                }
            }
        } else {
            http_response_code(400);
            die('{"success": false, "message": "This account does not exist"}');
        }
    } else {
        http_response_code(400);
        die('{"success": false, "message": "Bad request"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>