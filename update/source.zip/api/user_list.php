<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "GET")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

session_start();

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if ($_SESSION["role"] == "admin"){
        $sql = "SELECT `username`, `email`, `blocked`, `storage_size` FROM `user`";
         
        if (isset($_GET["start"]) and isset($_GET["length"])){
            $start = mysqli_real_escape_string($conn, $_GET["start"]);
            $length = mysqli_real_escape_string($conn, $_GET["length"]);

            if (is_numeric($start) and is_numeric($length)){
                $sql .= " LIMIT ".$start.",".($start + $length);
            } else {
                die('{"success": false, "message": "\'start\' and \'length\' GET argument must be a number"}');
            }   
        } else {
            if (!isset($_GET["start"]) and isset($_GET["length"])){
                die('{"success": false, "message": "\'start\' GET argument must be defined"}');
            }

            if (!isset($_GET["length"]) and isset($_GET["start"])){
                die('{"success": false, "message": "\'length\' GET argument must be defined"}');
            }
        }

        $result = $conn->query($sql);

        $user_list = array();

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                if ($row["blocked"] == "false"){
                    $blocked = FALSE;
                } else {
                    $blocked = TRUE;
                }

                array_push($user_list, array("name" => $row["username"], "email" => $row["email"], "storage_size" => $row["storage_size"], "blocked" => $blocked));
            }
        }

        $sql = "SELECT COUNT(*) AS `count` FROM `user`";
        $result = $conn->query($sql);

        if ($result and $result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                echo json_encode(array("success" => TRUE, "data" => array("length" => $result->num_rows, "users" => $user_list), "size" => intval($row["count"])), JSON_PRETTY_PRINT);
            }
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You aren\'t admin"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>