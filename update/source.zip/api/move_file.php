<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    http_response_code(405);
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        if (isset($_POST["id"]) and isset($_POST["new_parent_folder"])){
            $id = mysqli_real_escape_string($conn, $_POST["id"]);

            // Verify if the folder exist
            $new_parent_folder = mysqli_real_escape_string($conn, $_POST["new_parent_folder"]);

            if ($new_parent_folder != -1){
                $sql = "SELECT `id` FROM `folders` WHERE `id` = '".$new_parent_folder."'";
                $result = $conn->query($sql);
                if (!($result and $result->num_rows > 0)){
                    die('{"success" : false, "message": "This folder does not exist"}');
                }
            }
            
            $sql = "SELECT `owner`  FROM `content` WHERE `id` = '".$id."'";

            $result = $conn->query($sql);

            if ($result and $result->num_rows > 0 and 2 > $result->num_rows){
                while($row = $result->fetch_assoc()){
                    $owner = $row["owner"];
                }

                if ($owner == $_SESSION["unsecure_username"]){
                    $sql = "UPDATE `content` SET `folder`='".$new_parent_folder."' WHERE `id` = '".$id."' AND `owner` = '".$owner."'";
                    $conn->query($sql);

                    http_response_code(200);
                    echo '{"success" : true, "message": "File successfully moved"}';
                } else {
                    http_response_code(403);
                    die('{"success": false, "message": "You are not connected !"}');
                }
            } else {
                http_response_code(400);
                die('{"success" : false, "message": "File not found"}');
            }
        } else {
            http_response_code(400);
            die('{"success" : false, "message": "Bad Request"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>