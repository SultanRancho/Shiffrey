<?php
include("secure/head.php");

session_start();
include("secure/load_config.php");


if ($config->{"done"}){
    // Connect to the db
    include("secure/sql_connection.php");
    // Verify if the session is always activ
    include("secure/check_connection.php");

    if (!(isset($_SESSION["username"]) and isset($_SESSION["token"]))){
        http_response_code(403);
        header("Location: error/noconnected.php");
        die();
    }
} else {
    http_response_code(302);
    header("Location: init.php");
    die();
}

?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="stylesheet" href="style/panel.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
            <script src="script/lib/qrcode.min.js"></script>
        </head>
        <body class="normal">
            <div class="central_max">
                <div style="text-align: left; width: 80%; margin: 0 auto;">
                    <a href="panel.php"><button class="setting_button">< <?php translate("BACK") ?></button></a>
                </div>
                <span class="just_text"><?php translate("SETTINGS") ?></span>
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("CHANGE_PASSWORD") ?> :</h4>
                    <input type="password" id="new_password" placeholder="<?php translate("NEW_PASSWORD_PLACEHOLDER") ?>" class="input input_admin">
                    <br>
                    <button class="setting_button" onclick="new_keys()"><?php translate("CHANGE_MY_PASSWORD") ?></button>
                    <div style="height: 50px"></div>
                    <h4 class="medium_title"><?php translate("TOTP") ?> :</h4>
                    <br>
                    <?php
                        $sql = "SELECT `totp` FROM `user` WHERE `username` = '".$_SESSION["username"]."'";
                        $result = $conn->query($sql);

                        $activate = false;

                        if ($result){
                            foreach ($result as $row){
                                if ($row["totp"] != ""){
                                    $activate = true;
                                    break;
                                }
                            }
                            
                            if (!$activate){
                                echo '<div class="settings_box" style="margin-top:5px; margin-bottom:15px; display:flex; align-items:center">';
                                echo '<div style="width: fit-content;">';
                                echo '<span class="medium_text" style="margin:5px">';
                                translate("ALGORITHM");
                                echo ':</span><select id="totp-algo" class="option">
                                    <option selected>SHA-1</option>
                                    <option>SHA-256</option>
                                    <option>SHA-384</option>
                                    <option>SHA-512</option>
                                </select><br>';
                                echo '<span class="medium_text" style="margin:5px">';
                                translate("CODE_SIZE");
                                echo ':</span><select id="totp-digits" class="option">
                                    <option selected>6</option>
                                    <option>8</option>
                                </select><br>';
                                echo '<span class="medium_text" style="margin:5px">';
                                translate("SECRET_SIZE");
                                echo ':</span><input type="number" id="totp-secret-size" class="input input_number" value="20" min="20" max="512"><br>';
                               
                                echo '<span class="medium_text" style="margin:5px">';
                                translate("DELAY");
                                echo ':</span><input type="number" id="totp-delay" class="input input_number" value="30" min="5" max="300">';
                                echo "</div>";
                                echo '<div id="secret" style="text-align: center;line-break: anywhere;"></div>';

                                echo "<div id='qrcode' style='margin:10px;background-color: white;padding: 5px;' hidden></div>";

                                echo "</div>";
                                echo "<div id='panel1'>";
                                echo '<button onclick="change_activate(); set_totp(true)" class="setting_button">';
                                translate("ACTIVATE");
                                echo '</button>';
                                echo "</div>";
                                echo "<div id='panel2' hidden>";
                                echo '<button onclick="set_totp(false)" class="setting_button">';
                                translate("MODIFY");
                                echo '</button>';
                                echo '<button onclick="delete_totp()" class="setting_button" style="margin-left:5px">';
                                translate("DELETE");
                                echo '</button>';
                                echo '<input type="text" id="totp-verify" class="input" style="margin-left:5px">';
                                echo '<button onclick="verify_totp()" class="setting_button" style="margin-left:5px">';
                                translate("VERIFY");
                                echo '</button>';
                                echo "</div>";
                            } else {
                                $totp_data = json_decode($row["totp"]);

                                $algo = ["sha1", "sha256", "sha384", "sha512"];
                                $selection = ["", "", "", ""];
                                $selection[array_search($totp_data->{"algorithm"}, $algo)] = "selected";

                                echo '<div class="settings_box" style="margin-top:5px; margin-bottom:15px; display:flex; align-items:center">';
                                echo '<div style="width: fit-content;">';
                                echo '<span class="medium_text" style="margin:5px">';
                                translate("ALGORITHM");
                                echo ':</span><select id="totp-algo" class="option">
                                    <option '.$selection[0].'>SHA-1</option>
                                    <option '.$selection[1].'>SHA-256</option>
                                    <option '.$selection[2].'>SHA-384</option>
                                    <option '.$selection[3].'>SHA-512</option>
                                </select><br>';

                                $algo = [6, 8];
                                $selection = ["", ""];
                                $selection[array_search($totp_data->{"codesize"}, $algo)] = "selected";
                                echo '<span class="medium_text" style="margin:5px">';
                                translate("CODE_SIZE");
                                echo ':</span><select id="totp-digits" class="option">
                                    <option '.$selection[0].'>6</option>
                                    <option '.$selection[1].'>8</option>
                                </select><br>';

                                echo '<span class="medium_text" style="margin:5px">';
                                translate("SECRET_SIZE");
                                echo ':</span><input type="number" id="totp-secret-size" class="input input_number" value="'.htmlspecialchars($totp_data->{"secret_size"}).'" min="20" max="512"><br>';
                                
                                echo '<span class="medium_text" style="margin:5px">';
                                translate("DELAY");
                                echo ':</span><input type="number" id="totp-delay" class="input input_number" value="'.htmlspecialchars($totp_data->{"delay"}).'" min="5" max="300">';
                                
                                echo "</div>";
                                echo '<div id="secret" style="text-align: center;line-break: anywhere;"></div>';
                                echo "<div id='qrcode' style='margin:10px;background-color: white;padding: 5px;' hidden></div>";
                                echo "</div>";
                                echo "<div id='panel1' hidden>";
                                echo '<button onclick="change_activate(); set_totp(true)" class="setting_button">';
                                translate("ACTIVATE");
                                echo '</button>';
                                echo "</div>";
                                echo "<div id='panel2'>";
                                echo '<button onclick="set_totp(false)" class="setting_button">';
                                translate("MODIFY");
                                echo '</button>';
                                echo '<button onclick="delete_totp()" class="setting_button" style="margin-left:5px">';
                                translate("DELETE");
                                echo '</button>';
                                echo '<input type="text" id="totp-verify" class="input" style="margin-left:5px" maxlength="'.intval($totp_data->{"codesize"}).'">';
                                echo '<button onclick="verify_totp()" class="setting_button" style="margin-left:5px">';
                                translate("VERIFY");
                                echo '</button>';
                                echo "</div>";
                            }
                        }
                      
                    ?>
                    <br>
                    <div style="height: 15px"></div>
                    <h4 class="medium_title"><?php translate("DELETE_ACTIVE_SESSIONS") ?> :</h4>
                    <div style="height: 15px"></div>
                    <button class="setting_button" onclick="delete_other_sessions()"><?php translate("DELETE_ACTIVE_SESSIONS") ?></button>
                    <div style="height: 55px"></div>
                    <h4 class="medium_title"><?php translate("DELETE_ACCOUNT") ?>:</h4>
                    <div style="height: 15px"></div>
                    <button class="setting_button" onclick="delete_account()"><?php translate("DELETE") ?></button>
                </div>
                <div style="height: 30px"></div>
            </div>
        </body>
        <script>
            var wait_translation = "<?php translate("WAIT", "string") ?>";
            var close_translation = "<?php translate("DONT_CLOSE_WINDOW", "string") ?>";
            var change_password_translation = "<?php translate("CHANGE_MY_PASSWORD", "string") ?>";
            var change_totp_translation = "<?php translate("CHANGE_TOTP", "string") ?>";
            var destroy_account_translation = "<?php translate("DESTROY_ACCOUNT", "string") ?>";
            var deactivate_totp_translation = "<?php translate("DEACTIVATE_TOTP", "string") ?>";
            var password_specified_translation = "<?php translate("PASSWORD_SPECIFIED", "string") ?>";
            var account_deleted_translation = "<?php translate("SUCCESS_DELETE_ACCOUNT", "string") ?>";
            var sessions_deleted_translation = "<?php translate("SUCCESS_DELETE_ACTIVE_SESSIONS", "string") ?>";
            var success_password_translation = "<?php translate("SUCCESS_PASSWORD_CHANGE", "string") ?>";
            var success_totp_translation = "<?php translate("SUCCESS_DELETE_TOTP", "string") ?>";
            var actual_username = "<?php echo filter_var($_SESSION["unsecure_username"], FILTER_SANITIZE_ENCODED) ?>";
            var recovery_code_translation = "<?php translate("RECOVERY_CODE", "string") ?>";
        </script>
        <script src="script/crypto-js/crypto-js.js"></script>
        <script src="script/devtools.js"></script>
        <script src="script/crypto-js/sha512.min.js"></script>
        <script src="script/user_settings.js"></script>
        
    </html>