<?php
include("secure/head.php");

session_start();
include("secure/load_config.php");


if ($config->{"done"}){
    // Connect to the db
    include("secure/sql_connection.php");
    // Verify if the session is always activ
    include("secure/check_connection.php");

    if (!(isset($_SESSION["username"]) and isset($_SESSION["token"]))){
        http_response_code(403);
        header("Location: error/noconnected.php");
        die();
    }
} else {
    http_response_code(302);
    header("Location: init.php");
    die();
}

?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/upload.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central">
                <h1 class="title"><?php translate("UPLOAD") ?></h1>
                <div style="height: 10px"></div>
                <div class="div_path" id="path" style="margin-right: 5px;font-size: x-large;color: rgb(85, 241, 252); font-family: monospace; width:85%; margin: 0 auto; padding: 0px;">
            </div>
                <div style="height: 10px"></div>
                <div class="upload" ondragover="allowDrop(event)" ondrop="drag_and_drop(event)" onclick="select_file()" id="dropzone"><span id="filename"><?php translate("SELECT_FILES") ?> ...</span>
                    <input type="file" onchange="change_text()" name="file" id="file" multiple hidden>
                </div>
                <div class="info" id="max_storage"><?php translate("MAXIMUM_FILE_SIZE") ?>:</div>
                <button type="submit" id="upload" class="button" onclick ="send()" style="font-size: large;" hidden>Upload my file</button>
                <br>
                <div id="file_name">
                </div>
                <a href="panel.php" class="back_link">< <?php translate("BACK") ?></a>
            </div>
        </body>
        <!-- Translation -->
        <script>
            var loading_trans = "<?php translate("LOADING") ?>";
            var file_big_trans = "<?php translate("FILE_TOO_BIG") ?>";
            var wait_trans = "<?php translate("WAIT") ?>";
            var upload_file_trans = "<?php translate("UPLOAD_FILE") ?>";
            var upload_files_trans = "<?php translate("UPLOAD_FILES") ?>";
            var storage_space_trans = "<?php translate("NOT_ENOUGH_SPACE", "string") ?>";
            var error_trans = "<?php translate("ERROR") ?>";
            var max_size_trans = "<?php translate("MAXIMUM_FILE_SIZE") ?>";


            if (localStorage.getItem("path") != ""){
                actual_folder = JSON.parse(localStorage.getItem("path"))
            } else {
                actual_folder = [["", "-1"]];
                localStorage.setItem("path", JSON.stringify(actual_folder)) 
            }

            document.getElementById("path").innerHTML = "";

            slash = document.createTextNode("/");
            document.getElementById("path").appendChild(slash)

            for (i = 0; i < actual_folder.length; i++){
                if (i != 0){
                    but = document.createElement("a");
                    but.className = "link";
                    but.appendChild(document.createTextNode(actual_folder[i][0]))
                    document.getElementById("path").appendChild(but)
                    slash = document.createTextNode("/");
                    document.getElementById("path").appendChild(slash)
                }
            }

            document.getElementById("path").scroll(document.getElementById("path").scrollWidth + 30, 0)
        </script>
        <script src="script/crypto-js/crypto-js.js"></script>
        <script src="script/adapt.js"></script>
        <script src="script/devtools.js"></script>
        <script src="script/upload.js"></script>
        <script src="script/decrypt.js"></script>
    </html>