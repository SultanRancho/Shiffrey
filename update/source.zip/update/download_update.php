<?php

if (isset($GLOBALS['from_update']) && $GLOBALS['from_update']){
    try
        {     
            file_put_contents("downloaded_data/source.zip", fopen($conf_update->{"source"}."source.zip", 'r', false, $context));
            file_put_contents("downloaded_data/source.zip.signature", fopen($conf_update->{"source"}."source.zip.signature", 'r', false, $context));
        
            file_put_contents("downloaded_data/apply.php", fopen($conf_update->{"source"}."apply.php", 'r', false, $context));
            file_put_contents("downloaded_data/apply.php.signature", fopen($conf_update->{"source"}."apply.php.signature", 'r', false, $context));
        
            die('{"success": true, "message": "Source successfully downloaded"}');
        } catch (Error $e)
        {
            die(json_encode(array("success" => false, "message" => $e->getMessage())));
        }
}

?>