<?php

if (isset($GLOBALS['from_update']) && $GLOBALS['from_update']){
    try
        {
            $data = file_get_contents("downloaded_data/apply.php");
            $signature = file_get_contents("downloaded_data/apply.php.signature");
            $pubkeyid = file_get_contents("../IMPORTANT/update_key/publickey.pem");

            $ok = openssl_verify($data, $signature, $pubkeyid, OPENSSL_ALGO_SHA256);

            if ($ok == 1) {
                include("downloaded_data/apply.php");
            } else {
                die('{"success": false, "message": "An error in the key verification happend"}');
            }
        } catch (Error $e)
        {
            die(json_encode(array("success" => false, "message" => $e->getMessage())));
        }
}

?>