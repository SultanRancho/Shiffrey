<?php

if (isset($GLOBALS['from_update']) && $GLOBALS['from_update']){
    try
        {     
            // Get the actual version
            $actual_version_txt = @file_get_contents("../version.txt");
            $actual_version = @explode($actual_version_txt, ".");

            // Get the last update version
            @file_put_contents("downloaded_data/version.txt", fopen($conf_update->{"source"}."version.txt", 'r', false, $context));
            $version_txt = @file_get_contents("downloaded_data/version.txt");
            $version = @explode($version_txt, ".");
 
            if (trim($actual_version_txt) != trim($version_txt)){
                die('{"success": true, "message": "An update is available"}');
            } else {
                die('{"success": false, "message": "You are up-to-date"}');
            }
        } catch (Error $e)
        {
            die(json_encode(array("success" => false, "message" => $e->getMessage())));
        }
}

?>