<?php

if (isset($GLOBALS['from_update']) && $GLOBALS['from_update']){
    try
        {
            $data = file_get_contents("downloaded_data/source.zip");
            $signature = file_get_contents("downloaded_data/source.zip.signature");
            $pubkeyid = file_get_contents("../IMPORTANT/update_key/publickey.pem");

            $ok = openssl_verify($data, $signature, $pubkeyid, OPENSSL_ALGO_SHA256);

            if ($ok == 1) {
                $zip = new ZipArchive;
                $res = $zip->open('downloaded_data/source.zip');
    
                if ($res === TRUE) {
                    $zip->extractTo("downloaded_data/source/");
                    $zip->close();

                    die('{"success": true, "message": "Folder successfully unzip"}');
                } else {
                    die('{"success": false, "message": "An error occurred when opening the zip file"}');
                }
            } else {
                die('{"success": false, "message": "An error in the key verification happend"}');
            }
        } catch (Error $e)
        {
            die(json_encode(array("success" => false, "message" => $e->getMessage())));
        }
}

?>