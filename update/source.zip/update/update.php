<?php
include("../secure/head.php");
session_start();
include("../secure/load_config.php");

if ($config->{"done"}){
    if (isset($_SESSION["admintoken"]) and $_SESSION["role"] == "admin"){
        $GLOBALS['from_update'] = true;
        if (($_SERVER['REQUEST_METHOD'] === "POST")){
            $conf_update_text = file_get_contents("../IMPORTANT/conf_update.json", "r");
            $conf_update = json_decode($conf_update_text);

            $context_array = array(
                'http'=>array(
                  'timeout' => 3.0,
                )
                );

            if (isset($conf_update->{"proxy"}) && $conf_update->{"proxy"}){
                $context_array["http"]["proxy"] = $conf_update->{"proxy"};
            }
            
            $context = stream_context_create($context_array);

            if (isset($_POST["cmd"])){
                if ($_POST["cmd"] == "check"){
                    include("verify_update.php");
                } else if ($_POST["cmd"] == "download"){
                    include("download_update.php");
                } else if ($_POST["cmd"] == "extract"){
                    include("extract_zip.php");
                } else if ($_POST["cmd"] == "apply"){
                    include("apply_update.php");
                }
                
                die();
            } else {
                http_response_code(400);
                header("Content-Type: application/json");
                die('{"success": false, "message": "Bad request"}');
            }
        }
    } else {
        http_response_code(403);
        header("Location: ../error/noconnected.php");
        die();
    }
} else {
    http_response_code(500);
    header("Location: init.php");
    die();
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Shiffrey</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../style/main.css">
        <link rel="stylesheet" href="../style/widget.css">
        <link rel="icon" type="images/png" href="../images/favicon.png">
    </head>
    <body onresize="adapt_display()">
        <div class="central">
            <div style="height: 20px"></div>
            <span class="just_text"><?php translate("UPDATE") ?></span>
            <div style="height: 5px"></div>
            </br>
            <button class="button" style="margin: 5px;" onclick="update()"><?php translate("START") ?> ></button>
            <div style="height: 25px"></div>
            <ul type="square" class="ul_update">
                <li class="ligne"><?php translate("SEARCH_UPDATE") ?></li>
                <li class="ligne"><?php translate("DOWNLOAD_UPDATE") ?></li>
                <li class="ligne"><?php translate("UNZIP_UPDATE") ?></li>
                <li class="ligne"><?php translate("APPLY_UPDATE") ?></li>
            </ul>
            <div style="height: 25px"></div>
            <a href="../admin_panel.php" class="back_link">< <?php translate("BACK") ?></a>
        </div>
    </body>
    <script>
        // Translated element
        var trad_up_to_date = "<?php translate("UP_TO_DATE", "string") ?>";
    </script>
    <script src="../script/adapt.js"></script>
    <script src="../script/update.js"></script>
</html>