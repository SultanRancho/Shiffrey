<?php
include("secure/head.php");
session_start();
include("secure/load_config.php");

if (!$config->{"done"})
    {
        http_response_code(302);
        header("Location: init.php");
        die();
    }
?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central" style="padding: 15px">
                <h1 class="title"><?php translate("SET_NEW_PASSWORD") ?>:</h1> 
                    <div class="title_box">
                        <h4 class="medium_title">Token :</h4>
                    </div>
                    <input type="text" name="token" id="token" class="input input_central" value="<?php 
                        if (isset($_GET["token"]) and strlen($_GET["token"]) == 30 and ctype_xdigit($_GET["token"])){
                            echo htmlspecialchars($_GET["token"]);
                        }
                    ?>">
                    <div class="title_box">
                        <h4 class="medium_title"><?php translate("PASSWORD") ?> :</h4>
                    </div>
                    <input type="password" id="password" name="password" class="input input_central" ><br>
                    <button class="button" onclick="send_new_password()"><?php translate("CHANGE_PASSWORD") ?></button>
            </div>
        </body>
        <script>
            async function send_new_password(){
                request_content = new FormData();

                new_password = document.getElementById("password").value;
                token = document.getElementById("token").value;

                if (new_password != "" && token != ""){
                    request_content.append("password", new_password)
                    request_content.append("token", token)

                    req = await fetch("api/set_admin_password.php", {"body": request_content,"method": "POST"});
                    cont_json = await req.json();

                    trad_password_successfully = "<?php translate("SUCCESS_PASSWORD_CHANGE", "string") ?>"

                    if (cont_json["success"]){
                        alert(trad_password_successfully)
                        document.location = "admin.php"
                    } else {
                        alert(cont_json["message"]) 
                    }
                }
            }
        </script>
        <script src="script/adapt.js"></script>
    </html>