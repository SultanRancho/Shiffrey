<?php
session_name('session_id');
session_set_cookie_params(["SameSite" => "Strict"]);
session_set_cookie_params(["HttpOnly" => true]);
?>