importScripts("crypto-js/crypto-js.js");
importScripts("devtools.js");

var keySize = 256;
var ivSize = 128;
var iterations = 100;

function chunk(array, ind){
    iter = Math.ceil(array.length / block_size);
    chunk_list = []

    for (a = 0; a < iter; a++){
        chk = []
        for (b = 0; b < block_size; b++){
            pos =  a * block_size + b;
            if (array.length > pos){
                chk.push(array[pos])
            } else {
                break
            }
        }
        chunk_list.push(chk)

        postMessage(["prog", "1/2 :" + Math.round(a / iter * 100) +"%", ind]);
    }

    return chunk_list;
}

function encrypt_data(hex, key){
    dt = CryptoJS.enc.Hex.parse(hex);
    enc = CryptoJS.AES.encrypt(dt, key);
    return enc.iv.toString() + enc.salt.toString() + enc.ciphertext.toString();
  }

onmessage = (e) => {
    final_array = new Blob();

    block_size = 524286;

    key = e.data[1]
    iter = Math.ceil(e.data[2] / block_size);

    for (u = 0; u < iter; u++){
        data = new Uint8Array(e.data[0].slice(block_size * u, (u + 1) * block_size));
        data = toHexString(data);
        encrypted_data = encrypt_data(data, key);
        block = new Uint8Array(hexToBytes(encrypted_data));

        final_array = new Blob([final_array, block]);

        postMessage(["prog", "2/2:"+Math.round(u / iter * 100) +"%", e.data[3]]);
    }

    postMessage(["prog","100%", e.data[3]]);

    postMessage(["end", final_array, e.data[3]]);
}

