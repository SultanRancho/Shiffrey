importScripts("crypto-js/crypto-js.js");
importScripts("devtools.js");

var keySize = 256;
var ivSize = 128;
var iterations = 100;

function get_data(array, edat2){
  chunk_list = [];

  chunk_size = 524312

  iter = Math.ceil(array.length / chunk_size);

  for (i = 0; i < iter; i++){
    chk = array.splice(0, chunk_size);

    iv = false;
    salt = false;

    iv = toHexString(chk.splice(0, 16));
    salt = toHexString(chk.splice(0, 8));

    chunk_list.push([iv, salt, chk])
    postMessage(["prog", Math.round((i /iter * 100) / 2).toString()+"%", edat2]);
  }

  return chunk_list
}

function decrypt_data(ct, iv, salt){
  data_to_decrypt = CryptoJS.lib.CipherParams.create({
    ciphertext: CryptoJS.enc.Hex.parse(ct), 
    iv: CryptoJS.enc.Hex.parse(iv), 
    salt: CryptoJS.enc.Hex.parse(salt)})
    
  decrypted_data = hexToBytes(CryptoJS.AES.decrypt(data_to_decrypt, pass).toString(CryptoJS.enc.Hex));

  return decrypted_data
}


onmessage = (e) => {
    arr = e.data[0];
    pass =  e.data[1];

    result = []

    extract = get_data(arr, e.data[2]);
    chunk_list = extract

    for (i in chunk_list){
        decrypted_data = decrypt_data(toHexString(chunk_list[i][2]), chunk_list[i][0], chunk_list[i][1]);

        for (a in decrypted_data){
          result.push(decrypted_data[a])
        }

        postMessage(["prog", Math.round(50 + ((i / chunk_list.length * 100) / 2)).toString()+"%", e.data[2]]);
    }

    postMessage(["end", result, e.data[2], e.data[3]]);
}