var undo = 0;

var files_list = {}
var folder_list = {}
var file_length = false;
var fold_loading = false;

var check_list = [];

if (localStorage.getItem("path") && localStorage.getItem("path") != ""){
    var actual_folder = JSON.parse(localStorage.getItem("path"));
} else {
    var actual_folder = [["", "-1"]];
}

var copy_array = [0, []];

async function get_files(){
    check_list = [];

    req = await fetch("api/files.php?parent_folder="+actual_folder[actual_folder.length - 1][1]);
    cont_json = await req.json();

    req_folder = await fetch("api/folders.php?parent_folder="+actual_folder[actual_folder.length - 1][1]);
    cont_folder_json = await req_folder.json();

    if (cont_json["success"] == false && cont_json["code"] == "FOLDER_NOT_FOUND"){
        actual_folder = [["", "-1"]];
        get_files()
        return
    }

    if (cont_folder_json["success"] == false && cont_json["code"] == "FOLDER_NOT_FOUND"){
        actual_folder = [["", "-1"]];
        get_files()
        return
    }

    document.getElementById("path").innerHTML = "";
    document.getElementById("sub_path").style.height = "auto";

    slash = document.createTextNode("/");
    document.getElementById("path").appendChild(slash)

    for (i = 0; i < actual_folder.length; i++){
        if (i != 0){
            but = document.createElement("a");
            but.className = "link";
            but.setAttribute("onclick", "gotodir("+i.toString()+")")
            but.appendChild(document.createTextNode(actual_folder[i][0]))
            document.getElementById("path").appendChild(but)
            slash = document.createTextNode("/");
            document.getElementById("path").appendChild(slash)
        }
    }

    document.getElementById("path").scroll(document.getElementById("path").scrollWidth + 30, 0)
    document.getElementById("sub_path").style.height = (document.getElementById("path").clientHeight + 15).toString() + "px";

    localStorage.setItem("path", JSON.stringify(actual_folder))
    localStorage.setItem("fold_id", actual_folder[actual_folder.length - 1][1])
    
    file_length = cont_json["size"]

    data_contents = document.createElement("div");
    step = true;

    if (cont_json["data"].length > 0){
        for (i = 0; i < cont_json["data"].length; i++){
            try {
                filename = cont_json["data"][i]["name"];

                key_dec = decrypt_text(cont_json["data"][i]["key"], localStorage.getItem("key"));

                filename = decrypt_text(filename, key_dec)
                filename = JSON.parse(filename)["name"]

                files_list[i] = [filename, cont_json["data"][i]["id"], cont_json["data"][i]["key"], cont_json["data"][i]["size"]]

                file_id = cont_json["data"][i]["id"];
                
                // Create the div of the file
                file_div = document.createElement("div");
                if (step){
                    file_div.className = "file type1"
                } else {
                    file_div.className = "file type2"
                }
                file_div.id = 'file_'+i.toString()

                // Check box
                checkbox = document.createElement("div")
                checkbox.className = "blue_folder"
                input_checkbox = document.createElement("input")
                input_checkbox.type = "checkbox"
                input_checkbox.className = "checkbox"
                input_checkbox.id = 'check_'+i.toString()
                input_checkbox.setAttribute("onclick", 'check('+i.toString()+')')
                checkbox.appendChild(input_checkbox)
                file_div.appendChild(checkbox)
     
                // Filename
                filename_box = document.createElement("div")
                filename_box.className = "blue_folder"
                filename_box.innerText = filename
                file_div.appendChild(filename_box)

                // Size
                size_box = document.createElement("div")
                size_box.className = "blue"
                size_box.innerText = convertUnit(cont_json["data"][i]["size"])
                file_div.appendChild(size_box)

                // Rename
                rename_box = document.createElement("a")
                rename_box.className = "blue"
                rename_box.innerText = rename_translation;
                rename_box.style = "text-decoration: underline";
                rename_box.id = 'rename_'+i.toString();
                rename_box.setAttribute("onclick", 'rename_file('+i.toString()+')')
                file_div.appendChild(rename_box)

                // Download
                open_box = document.createElement("a")
                open_box.className = "blue"
                open_box.innerText = open_translation;
                open_box.style = "text-decoration: underline";
                open_box.id = 'download_'+i.toString();
                open_box.setAttribute("onclick", 'download_file('+i.toString()+')')
                file_div.appendChild(open_box)

                // Delete
                delete_box = document.createElement("a")
                delete_box.className = "blue"
                delete_box.innerText = delete_translation;
                delete_box.style = "text-decoration: underline; color:red";
                delete_box.id = 'delete_'+i.toString();
                delete_box.setAttribute("onclick", 'delete_file('+i.toString()+')')
                file_div.appendChild(delete_box)
                
                // Share
                delete_box = document.createElement("a")
                delete_box.className = "blue"
                delete_box.innerText = share_translation;
                delete_box.style = "text-decoration: underline";
                delete_box.id = 'share_'+i.toString();
                delete_box.setAttribute("onclick", 'share('+i.toString()+')')
                file_div.appendChild(delete_box)

                data_contents.appendChild(file_div)
            } catch (err) {
                console.log(err);
            }
        }
    }  
    
    if (cont_folder_json["data"].length > 0){
        for (i = 0; i < cont_folder_json["data"].length; i++){
            try {
                foldname = cont_folder_json["data"][i]["metadata"];

                foldname = decrypt_text(foldname, localStorage.getItem("key"))
                foldname = JSON.parse(foldname)["name"]

                foldid = cont_folder_json["data"][i]["id"];

                folder_list[i] = [foldname, foldid]

                // Create the div of the file
                file_div = document.createElement("div");
                if (step){
                    file_div.className = "file type1"
                } else {
                    file_div.className = "file type2"
                }
                file_div.id = 'folder_'+i.toString()

                // Check box
                checkbox = document.createElement("div")
                checkbox.className = "blue_folder"
                input_checkbox = document.createElement("input")
                input_checkbox.type = "checkbox"
                input_checkbox.className = "checkbox"
                input_checkbox.id = 'check_folder_'+i.toString()
                input_checkbox.setAttribute("onclick", 'check_folder('+i.toString()+')')
                checkbox.appendChild(input_checkbox)
                file_div.appendChild(checkbox)
     
                // Filename
                filename_box = document.createElement("div")
                filename_box.className = "blue_folder"
                filename_box.innerText = foldname
                file_div.appendChild(filename_box)

                // Rename
                rename_box = document.createElement("a")
                rename_box.className = "blue"
                rename_box.innerText = rename_translation;
                rename_box.style = "text-decoration: underline";
                rename_box.setAttribute("onclick", 'rename_fold('+i.toString()+')')
                file_div.appendChild(rename_box)

                // Download
                open_box = document.createElement("a")
                open_box.className = "blue"
                open_box.innerText = open_translation;
                open_box.style = "text-decoration: underline";
                open_box.setAttribute("onclick", 'open_fold('+i.toString()+')')
                file_div.appendChild(open_box)

                // Delete
                delete_box = document.createElement("a")
                delete_box.className = "blue"
                delete_box.innerText = delete_translation;
                delete_box.style = "text-decoration: underline; color:red;";
                delete_box.setAttribute("onclick", 'delete_folder('+i.toString()+')')
                file_div.appendChild(delete_box)

                data_contents.prepend(file_div)
            } catch (err) {
                console.log(err);
            }
        }
    }
    
    if (cont_json["data"].length == 0 && cont_folder_json["data"].length == 0) {
        document.getElementsByClassName("data")[0].innerHTML = "<span style='color: rgb(85, 241, 252); font-family: monospace; font-size: large;'>"+empty_translation+"</span>";
    } else {
        document.getElementsByClassName("data")[0].innerHTML = data_contents.innerHTML;
    }
    
    fold_loading = false;
}

function open_fold(id){
    if (!fold_loading){
        fold_loading = true;
        actual_folder.push(folder_list[id]);
        get_files()
    }
}

function back_fold(){
    if (actual_folder.length != 1){
        actual_folder.pop();
        get_files()
    }
}

async function download_file(id){
    document.getElementById("download_"+id).setAttribute("onclick", "")
    fname = files_list[id][0];
    fid = files_list[id][1];
    fkey = decrypt_text(files_list[id][2], localStorage.getItem("key"));
    file_element = document.getElementById("download_"+id);
    file_element.innerText = wait_translation+"... (1/2)"
    arr = []

    chunk = 3000000;
    
    for (i = 0; i <= Math.floor(files_list[id][3] / chunk); i++){
        while (true){
            try{
                if (i == Math.floor(files_list[id][3] / chunk)){
                    req = await fetch("api/get_file.php?id="+fid+"&start="+(i*chunk).toString()+"&length="+(files_list[id][3] - i*chunk))
                } else {
                    req = await fetch("api/get_file.php?id="+fid+"&start="+(i*chunk).toString()+"&length="+chunk.toString())
                }

                cont = await req.blob();
                cont = await cont.arrayBuffer();
                temp_arr = Array.from(new Uint8Array(cont));
                arr = arr.concat(temp_arr)
                file_element.innerText = wait_translation+"... " + Math.round(i*chunk / files_list[id][3] * 100).toString() + "%(1/2)"
                break;
            } catch(e){
                console.log(e)
            }
        }
        
    }

    wo = new Worker("script/uncypher-worker.js")
    wo.postMessage([arr, fkey, id, fname]);

    wo.onmessage = (e) => {
        state = e.data[0];
        data = e.data[1];
        if (state == "prog"){
            fl_elem = document.getElementById("download_"+e.data[2]);
            fl_elem.innerText = wait_translation+"... "+data+" (2/2)"
        } else {
            fl_elem = document.getElementById("download_"+e.data[2]);
            fl_elem.innerText = wait_translation+"... (2/2)"
            conte = new Blob([new Uint8Array(data)], { type: 'application/octet-stream'});
            const blobUrl = URL.createObjectURL(conte);
            fl_elem.href = blobUrl;
            fl_elem.download = e.data[3];
            fl_elem.innerText = download_translation;
        }  
      }
    
}

async function delete_file(id){
    var form_data = new FormData();
    fid = files_list[id][1];
    form_data.append("id", fid)

    fname = files_list[id][0];
    if (confirm(ask_delete_file_translation+' "'+fname+'" ?')){
        req = await fetch("api/delete_file.php", 
        {method: "POST", 
        body: form_data}
        );
        cont = await req.json();
        
        if (cont["success"]){
            location.reload();
        } else {
            alert(cont["message"])
        }
    }
}

async function delete_folder(id){
    var form_data = new FormData();
    fid = folder_list[id][1];
    form_data.append("id", fid)

    fname = folder_list[id][0];
    if (confirm(ask_delete_folder_translation+' "'+fname+'" ?')){
        req = await fetch("api/delete_folder.php", 
        {method: "POST", 
        body: form_data}
        );
        cont = await req.json();
        
        if (cont["success"]){
            location.reload();
        } else {
            alert(cont["message"])
        }
    }
}

async function rename_file(id){
    request = new FormData();

    filename = prompt(filename_translation+":");
    if (filename){
        filename = JSON.stringify({"name": filename})
        filename = encrypt_text(filename, decrypt_text(files_list[id][2], localStorage.getItem("key")));
        
        request.append("id", files_list[id][1]) 
        request.append("metadata", filename)

        req = await fetch("api/rename_file.php", 
            {method: "POST", 
            body: request}
            );
        cont = await req.json();
        
        if (cont["success"]){
            document.getElementsByClassName("data")[0].innerHTML = '<div style="font-family: monospace; color: rgb(85, 241, 252); font-size: large; margin-top: 10px; margin-bottom: 10px;">Wait, loading ...</div>';
            get_files()
        } else {
            alert(cont["message"])
        }
    }
}

async function rename_fold(id){
    request = new FormData();

    filename = prompt(filename_translation+":");
    if (filename){
        filename = JSON.stringify({"name": filename})
        filename = encrypt_text(filename, localStorage.getItem("key"));
        
        request.append("id", folder_list[id][1]) 
        request.append("metadata", filename)

        req = await fetch("api/rename_folder.php", 
            {method: "POST", 
            body: request}
            );
        cont = await req.json();
        
        if (cont["success"]){
            document.getElementsByClassName("data")[0].innerHTML = '<div style="font-family: monospace; color: rgb(85, 241, 252); font-size: large; margin-top: 10px; margin-bottom: 10px;">Wait, loading ...</div>';
            get_files()
        } else {
            alert(cont["message"])
        }
    }
}

function share(pos){
    document.location = "share.php?file_id="+files_list[pos][1];
}

get_files();

function check(id){
    if (document.getElementById("check_"+id).checked){
        check_list.push([0, id])
        document.getElementById("delete_"+id.toString()).style.visibility = "hidden";
    } else {
        check_list.splice(check_list.findIndex(ele => ele[0] == 0 && ele[1] == id), 1)
        document.getElementById("delete_"+id.toString()).style.visibility = "visible";
    }

    if (check_list.length > 0){
        document.getElementById("dtf").style.visibility = "visible"
        document.getElementById("ctf").style.visibility = "visible"
        document.getElementById("cutf").style.visibility = "visible"
    } else {
        document.getElementById("dtf").style.visibility = "hidden"
        document.getElementById("ctf").style.visibility = "hidden"
        document.getElementById("cutf").style.visibility = "hidden"
    }
}

function check_folder(id){
    if (document.getElementById("check_folder_"+id).checked){
        check_list.push([1, id])
    } else {
        check_list.splice(check_list.findIndex(ele => ele[0] == 1 && ele[1] == id), 1)
    }

    if (check_list.length > 0){
        document.getElementById("dtf").style.visibility = "visible"
        document.getElementById("ctf").style.visibility = "visible"
        document.getElementById("cutf").style.visibility = "visible"
    } else {
        document.getElementById("dtf").style.visibility = "hidden"
        document.getElementById("ctf").style.visibility = "hidden"
        document.getElementById("cutf").style.visibility = "hidden"
    }
}

async function delete_the_files(){
    if (check_list.length == 1){
        if (check_list[0][0] == 1){
            ask = ask_delete_folder_translation + ' "' + folder_list[check_list[0][1]][0] + '"'
        } else {
            ask = ask_delete_file_translation + ' "' + files_list[check_list[0][1]][0] + '"'
        }
    } else {
        ask = ask_delete_files_translation
    }

    if (confirm(ask+"?")){
        for (i = 0; i < check_list.length; i++){
            if (check_list[i][0] == 0){
                var form_data = new FormData();
                fid = files_list[check_list[i][1]][1];
                form_data.append("id", fid)

                loop :{
                    try{
                        req = await fetch("api/delete_file.php", 
                        {method: "POST", 
                        body: form_data,
                      }
                        );
                        cont = await req.json();
                        
                        if (!cont["success"]){
                            alert(cont["message"])
                        } else {
                            document.getElementById("file_"+check_list[i][1].toString()).remove()
                            break loop;
                        }
                    } catch (error) {
                        alert(error)
                    }
                }
            } else {
                var form_data_fold = new FormData();
                fid = check_list[i][1];
                form_data_fold.append("id", folder_list[fid][1])            

                loop :{
                    try{
                        req = await fetch("api/delete_folder.php", 
                        {method: "POST", 
                        body: form_data_fold}
                        );
                        cont = await req.json();
                        
                        if (!cont["success"]){
                            alert(cont["message"])
                        } else {
                            document.getElementById("folder_"+fid.toString()).remove()
                            break loop;
                        }
                    } catch (error) {
                        alert(error)
                    }
                }
            }
                
            }
        
        location.reload();
    }    
}

async function create_folder(){
    var folder_name = prompt(folder_name_translation)

    if (folder_name){
        request = new FormData();
        encrypt_folder_name = JSON.stringify({"name": folder_name});
        encrypt_folder_name = encrypt_text(encrypt_folder_name, localStorage.getItem("key"))
        request.append("metadata", encrypt_folder_name)
        request.append("parent_folder", actual_folder[actual_folder.length - 1][1])
        req = await fetch("api/create_folder.php", {"method": "POST", "body": request})
        cont = await req.json();

        if (cont["success"]){
            document.location.reload()
        } else {
            alert(cont["message"])
        }
    }
}

function gotodir(id){
    if (actual_folder.length != 1){
        actual_folder = actual_folder.slice(0,id+1);
        get_files()
    }
}

function copy_the_files(){
    copy_array = [0, []];
    document.getElementById("paste").style.visibility = "visible";
    copy_array[0] = 1;
    for (i = 0; i < check_list.length; i++){
        if (check_list[i][0] == 0){
            copy_array[1].push([check_list[i][0], files_list[check_list[i][1]][1]])
        } else {
            copy_array[1].push([check_list[i][0], folder_list[check_list[i][1]][1]])
        }
    }
}

function cut_the_files(){
    copy_array = [0, []];
    document.getElementById("paste").style.visibility = "visible";
    copy_array[0] = 2;
    for (i = 0; i < check_list.length; i++){
        if (check_list[i][0] == 0){
            copy_array[1].push([check_list[i][0], files_list[check_list[i][1]][1]])
        } else {
            copy_array[1].push([check_list[i][0], folder_list[check_list[i][1]][1]])
        }
    }
}

async function paste(){
    if (copy_array[1].length != 0){
        if (copy_array[0] == 2){
            for (i = 0; i < copy_array[1].length; i++){
                request = new FormData();
                request.append("id", copy_array[1][i][1])
                request.append("new_parent_folder", actual_folder[actual_folder.length - 1][1])
    
                
                if (copy_array[1][i][0] == 0){
                    req = await fetch("api/move_file.php", {"method": "POST", "body": request})
                } else {
                    req = await fetch("api/move_folder.php", {"method": "POST", "body": request})
                }
    
                cont = await req.json();
    
                if (cont["success"]){
                    document.location.reload()
                } else {
                    alert(cont["message"])
                }
            }
        } else if (copy_array[0] == 1){
            for (i = 0; i < copy_array[1].length; i++){
                request = new FormData();
                request.append("id", copy_array[1][i][1])
                request.append("parent_folder", actual_folder[actual_folder.length - 1][1])
    
                
                if (copy_array[1][i][0] == 0){
                    req = await fetch("api/copy_file.php", {"method": "POST", "body": request})
                } else {
                    req = await fetch("api/copy_folder.php", {"method": "POST", "body": request})
                }
    
                cont = await req.json();
    
                if (cont["success"]){
                    document.location.reload()
                } else {
                    alert(cont["message"])
                }
            }
        }
    }
    copy_array = [0, []];
    document.getElementById("paste").style.visibility = "hidden";
}

this.addEventListener('keydown', event => {
        if (event.ctrlKey){
            if (event.key == "c"){
                copy_the_files()
            }

            if (event.key == "x"){
                cut_the_files()
            }

            if (event.key == "v"){
                paste()
            }
        }
})

function adapt_on_resize(){
    document.getElementById("path").scroll(document.getElementById("path").scrollWidth + 30, 0);
    
    if (window.innerWidth < 800){
        document.getElementById("back_fold").innerText = "↰"
    } else {
        document.getElementById("back_fold").innerText = back_translation
    }
}