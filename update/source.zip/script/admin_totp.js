algo_list = ["sha1", "sha256", "sha384", "sha512"];
code_size_list = [6, 8]

async function set_totp(first_time){
    if (first_time || confirm(change_totp_translation)){
        document.getElementById("qrcode").innerHTML = "";
        algo = algo_list[document.getElementById("totp-algo").selectedIndex];
        code_size = code_size_list[document.getElementById("totp-digits").selectedIndex];
        secret_size = document.getElementById("totp-secret-size").value;
        delay = document.getElementById("totp-delay").value;
    
        var form_data = new FormData();
        form_data.append("algorithm", algo)
        form_data.append("code_size", code_size)
        form_data.append("secret_size", secret_size)
        form_data.append("delay", delay)
    
        req = await fetch("api/set_admin_totp.php", 
            {method: "POST", 
            body: form_data}
            );
        cont = await req.json();
    
        adresse = "otpauth://totp/"+actual_username+"?issuer=Shiffrey&secret="+cont["secret"]+"&algorithm="+cont["algorithm"]+"&digits="+cont["codesize"]+"&period="+cont["delay"];
    
        new QRCode(document.getElementById("qrcode"), adresse);
        document.getElementById("qrcode").hidden = false;

        recovery_code = "data:text/txt,Recovery code for Shiffrey:%0A";

        for (element of cont["recovery_code"]){
            recovery_code += element+"%0A";
        };

        document.getElementById("secret").innerHTML = '<span class="medium_text">'+cont["secret"]+'</span><br><a href="'+recovery_code+'" download="shiffrey_recovery_code.txt">'+recovery_code_translation+'</a>';
    }
}

async function delete_totp(){
    if (confirm(deactivate_totp_translation+" ?")){
        req = await fetch("api/delete_admin_totp.php", {"method": "POST"})
        cont = await req.json()
        
        if (cont["success"]){
            alert(success_totp_translation)
            location.reload();
        } else {
            alert(cont["message"])
        }
    }
}

async function verify_totp(){
    totp_code = document.getElementById("totp-verify").value

    var form_data = new FormData();
    form_data.append("totp", totp_code)

    req = await fetch("api/verify_admin_totp.php", 
        {method: "POST", 
        body: form_data}
        );
    cont = await req.json();

    alert(cont["message"])

    document.getElementById("totp-verify").value = "";
}

function change_activate(){
    document.getElementById("panel1").hidden = true;
    setTimeout(function () {document.getElementById("panel2").hidden = false;}, 1000);
}