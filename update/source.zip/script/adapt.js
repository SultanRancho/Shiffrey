function adapt_display(){
    if (document.getElementsByClassName("central")[0]){
        if (document.getElementsByClassName("central")[0].clientHeight > window.innerHeight)
        {
            document.body.style.position = "inherit";
            document.body.style.paddingTop = "20px";
            document.body.style.paddingBottom = "20px";
        } else {
            document.body.style.position = "fixed";
            document.body.style.paddingTop = "";
            document.body.style.paddingBottom = "";
        }
    }

    if (document.getElementsByClassName("central_login")[0]){
        if (document.getElementsByClassName("central_login")[0].clientHeight > window.innerHeight)
        {
            document.body.style.position = "inherit";
            document.body.style.paddingTop = "20px";
            document.body.style.paddingBottom = "20px";
        } else {
            document.body.style.position = "fixed";
            document.body.style.paddingTop = "";
            document.body.style.paddingBottom = "";
        }
    }
    
}

adapt_display();