algo_list = ["sha1", "sha256", "sha384", "sha512"];
code_size_list = [6, 8]

async function new_keys(){
    document.getElementsByClassName("setting_button")[1].innerText = wait_translation+"... ("+close_translation+")";

    req = await fetch("api/files.php");
    cont = await req.json();

    req = await fetch("api/folders.php");
    cont_folders = await req.json();

    req_link = await fetch("api/links.php");
    cont_link = await req_link.json();

    new_password = document.getElementById("new_password").value;

    if (new_password){

        new_cypher_key = sha384(new_password);
        new_password = sha512(sha512(new_password));

        // Generate data to send
        data = cont["data"]
            
        for (i = 0; i < Math.ceil(data.length / 10); i++){
            while (true){
                request = new FormData();
                sent_data = []
                for (j = 0; j < 10; j++){
                    if (i * 10 + j >= data.length){
                        break;
                    }

                    old_key = decrypt_text(data[i * 10 + j]["key"], localStorage.getItem("key"));
                    new_key = encrypt_text(old_key, new_cypher_key);
    
                    sent_data.push([data[i * 10 + j]["id"], new_key]);
                }
               
                request_cont = JSON.stringify(sent_data);
    
                if (sent_data.length != 0){
                    request.append("new_keys", request_cont);
                }
    
                req = await fetch("api/access_management.php", {method: "POST", "body": request});
    
                cont = await req.json()
    
                if (cont["success"]){
                    break;
                }
            }
        }

        

        // Generate data to send
        data = cont_link["data"]

        for (i = 0; i < Math.ceil(data.length / 10); i++){
            while (true){
                request = new FormData();
                sent_data = []
                for (j = 0; j < 10; j++){
                    if (i * 10 + j >= data.length){
                        break;
                    }
                    
                    old_name = decrypt_text(data[i * 10 + j]["name"], localStorage.getItem("key"));
                    new_name = encrypt_text(old_name, new_cypher_key)
                    sent_data.push([data[i * 10 + j]["id"], new_name]);
                }
               
                request_cont = JSON.stringify(sent_data);
    
                if (sent_data.length != 0){
                    request.append("new_link_keys", request_cont);
                }
    
                req = await fetch("api/access_management.php", {method: "POST", "body": request});
    
                cont = await req.json()
    
                if (cont["success"]){
                    break;
                }
            }
        }


        // Generate data to send
        data = cont_folders["data"]

        for (i = 0; i < Math.ceil(data.length / 10); i++){
            while (true){
                request = new FormData();
                sent_data = []
                for (j = 0; j < 10; j++){
                    if (i * 10 + j >= data.length){
                        break;
                    }
                    
                    old_name = decrypt_text(data[i * 10 + j]["metadata"], localStorage.getItem("key"));
                    new_name = encrypt_text(old_name, new_cypher_key)
                    sent_data.push([data[i * 10 + j]["id"], new_name]);
                }
                
                request_cont = JSON.stringify(sent_data);
    
                if (sent_data.length != 0){
                    request.append("new_folders", request_cont);
                }
    
                req = await fetch("api/access_management.php", {method: "POST", "body": request});
    
                cont = await req.json()
    
                if (cont["success"]){
                    break;
                }
            }
        }

        request = new FormData();

        request.append("new_password", new_password);
       
        req = await fetch("api/access_management.php", 
        {method: "POST",
        "body": request}
        );

        cont = await req.json()

        if (cont["success"]){
            localStorage.setItem("key", new_cypher_key)
            alert(success_password_translation)
        } else {
            alert(cont["message"])
            return
        }
    } else {
        alert(password_specified_translation)
    }

    new_password = document.getElementById("new_password").value = "";
    document.getElementsByClassName("setting_button")[1].innerText = change_password_translation;
}

async function delete_other_sessions(){
    req = await fetch("api/delete_user_sessions.php", {"method": "POST"})
    cont = await req.json()

    if (cont["success"]){
        alert(sessions_deleted_translation)
    } else {
        alert(cont["message"])
    }
}

async function delete_account(){
    if (confirm(destroy_account_translation+" ?")){
        req = await fetch("api/delete_account.php", {"method": "POST"})
        cont = await req.json()
        
        if (cont["success"]){
            alert(account_deleted_translation)
            location.reload();
        } else {
            alert(cont["message"])
        }
    }
}

async function set_totp(first_time){
    if (first_time || confirm(change_totp_translation)){
        document.getElementById("qrcode").innerHTML = "";
        algo = algo_list[document.getElementById("totp-algo").selectedIndex];
        code_size = code_size_list[document.getElementById("totp-digits").selectedIndex];
        secret_size = document.getElementById("totp-secret-size").value;
        delay = document.getElementById("totp-delay").value;
    
        var form_data = new FormData();
        form_data.append("algorithm", algo)
        form_data.append("code_size", code_size)
        form_data.append("secret_size", secret_size)
        form_data.append("delay", delay)
    
        req = await fetch("api/set_totp.php", 
            {method: "POST", 
            body: form_data}
            );
        cont = await req.json();
    
        adresse = "otpauth://totp/"+actual_username+"?issuer=Shiffrey&secret="+cont["secret"]+"&algorithm="+cont["algorithm"]+"&digits="+cont["codesize"]+"&period="+cont["delay"];
    
        new QRCode(document.getElementById("qrcode"), adresse);
        document.getElementById("qrcode").hidden = false;

        recovery_code = "data:text/txt,Recovery code for Shiffrey:%0A";

        for (element of cont["recovery_code"]){
            recovery_code += element+"%0A";
        };

        document.getElementById("secret").innerHTML = '<span class="medium_text">'+cont["secret"]+'</span><br><a href="'+recovery_code+'" download="shiffrey_recovery_code.txt">'+recovery_code_translation+'</a>';
    }
}

async function delete_totp(){
    if (confirm(deactivate_totp_translation+" ?")){
        req = await fetch("api/delete_totp.php", {"method": "POST"})
        cont = await req.json()
        
        if (cont["success"]){
            alert(success_totp_translation)
            location.reload();
        } else {
            alert(cont["message"])
        }
    }
}

async function verify_totp(){
    totp_code = document.getElementById("totp-verify").value

    var form_data = new FormData();
    form_data.append("totp", totp_code)

    req = await fetch("api/verify_totp.php", 
        {method: "POST", 
        body: form_data}
        );
    cont = await req.json();

    alert(cont["message"])

    document.getElementById("totp-verify").value = "";
}

function change_activate(){
    document.getElementById("panel1").hidden = true;
    setTimeout(function () {document.getElementById("panel2").hidden = false;}, 1000);
}
