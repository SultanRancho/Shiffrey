function add_param(name, value){
    if (request){
        request += "&"+encodeURIComponent(name)+"="+encodeURIComponent(value);
    } else {
        request += encodeURIComponent(name)+"="+encodeURIComponent(value);
    }
}

function convertUnit(oct_numb, floor = false){
    if (oct_numb > 1000000000)
    {
        oct_numb = (oct_numb / 1000000000).toFixed(2)
        oct_numb = oct_numb.toString() + "Go"
    } else if (oct_numb > 1000000)
    {
        oct_numb = (oct_numb / 1000000).toFixed(2)
        oct_numb = oct_numb.toString() + "Mo"
    } else if (oct_numb > 1000)
    {
        oct_numb = (oct_numb / 1000).toFixed(2)
        oct_numb = oct_numb.toString() + "Ko"
    } else {
        oct_numb = oct_numb.toString() + "o"
    }

    return oct_numb;
}

function hexToBytes(hex) {
    let bytes = [];
    for (let c = 0; c < hex.length; c += 2)
        bytes.push(parseInt(hex.substr(c, 2), 16));
    return bytes;
}

function toHexString(byteArray) {
    return Array.from(byteArray, function(byte) {
      return ('0' + (byte & 0xFF).toString(16)).slice(-2);
    }).join('')
  }

  function arr2str(arr) {
    // or [].slice.apply(arr)
    var utf8 = Array.from(arr).map(function (item) {
      return String.fromCharCode(item);
    }).join('');
    
    return utf8;
  }

function generateRandomHexString(numBytes) {
    const bytes = crypto.getRandomValues(new Uint8Array(numBytes));
    const array = Array.from(bytes);
    const hexPairs = array.map(b => b.toString(16).padStart(2, '0'));
    return hexPairs.join('')
}

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

async function get_settings(){
    req = await fetch("api/settings.php");
    cont = await req.json();

    if (cont["success"]){
        document.cookie = "MAX_FILE_SIZE="+cont["data"]["max_file_size"]+";SameSite=Strict"
        document.cookie = "MAX_USER_STORAGE_SIZE="+cont["data"]["max_user_storage_size"]+";SameSite=Strict"
        document.cookie = "ACTUAL_USER_STORAGE="+cont["data"]["actual_storage_size"]+";SameSite=Strict"
    }
}

function encrypt_text(text, key){
  enc = CryptoJS.AES.encrypt(text, key);
  return enc.key.toString() + enc.iv.toString() + enc.salt.toString() + enc.ciphertext.toString();
}

function decrypt_text(hex, password){
  loc_key = hex.substring(0, 64);
  iv = hex.substring(64, 96);
  salt = hex.substring(96, 112);
  ct = hex.substring(112);
  
  data_to_decrypt = CryptoJS.lib.CipherParams.create({
      ciphertext: CryptoJS.enc.Hex.parse(ct), 
      iv: CryptoJS.enc.Hex.parse(iv), 
      salt: CryptoJS.enc.Hex.parse(salt), 
      key: CryptoJS.enc.Hex.parse(loc_key)})
    
  decrypted_data = CryptoJS.AES.decrypt(data_to_decrypt, password).toString(CryptoJS.enc.Utf8);

  return decrypted_data
}

async function logout(){
  req = await fetch("api/logout.php", {"method": "POST"});
  cont = await req.json();

  if (cont["success"]){
    alert(disconnected_translation);
    localStorage.setItem("key", "")
    localStorage.setItem("fold_id", "")
    localStorage.setItem("path", "")
    window.location = "result/disconnected.php"
  } else {
    alert(cont["message"])
  }
}

/* nothing here. */
function copy(variable){
  return JSON.parse(JSON.stringify(variable))
}
