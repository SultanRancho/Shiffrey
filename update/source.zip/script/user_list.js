var users = null;
var page_ind = 0;
var undo = 0;
var file_length = false;

async function get_user_list(start = null, length = null){
    request = "";
    if (start != null && length != null){
        add_param("start", start.toString())
        add_param("length", length.toString())

        request = "?"+request;
    }
    req = await fetch("api/user_list.php"+request, {"method": "GET"})
    cont = await req.json();

    return cont;
}

async function set_user_list(){
    page_ind = parseInt(document.getElementById("page_index").value) - 1;

    // Get the user list
    content = await get_user_list(page_ind * 50, 50);
    users = cont["data"]["users"]
    file_length = cont["size"]

    container = document.getElementsByClassName("data")[0];

    container.innerHTML = "";

    //  Add column title
    head_span = document.createElement("span");
    head_span.className = "list_element";

    span = document.createElement("span");
    span.style = "flex:1;text-decoration: underline;";
    text = document.createTextNode(username_trans);
    span.appendChild(text);
    head_span.appendChild(span);

    span = document.createElement("span");
    span.style = "flex:1; text-decoration: underline;";
    text = document.createTextNode(email_trans);
    span.appendChild(text);
    head_span.appendChild(span);

    span = document.createElement("span");
    span.style = "flex:1; text-decoration: underline;";
    text = document.createTextNode(used_storage_trans);
    span.appendChild(text);
    head_span.appendChild(span);

    span = document.createElement("span");
    span.style = "flex: 1;"
    head_span.appendChild(span);

    span = document.createElement("span");
    span.style = "flex: 1;"
    head_span.appendChild(span);

    container.appendChild(head_span)

    if (users.length != 0){
        for (a = 0; a < users.length; a++){
            head_span = document.createElement("span");
            head_span.className = "list_element";
    
            span = document.createElement("span");
            span.style = "flex:1; line-break: anywhere;";
            text = document.createTextNode(users[a]["name"]);
            span.appendChild(text);
            head_span.appendChild(span);
    
            span = document.createElement("span");
            span.style = "flex:1; line-break: anywhere;";
            text = document.createTextNode(users[a]["email"]);
            span.appendChild(text);
            head_span.appendChild(span);

            span = document.createElement("span");
            span.style = "flex:1; line-break: anywhere;";
            text = document.createTextNode(convertUnit(users[a]["storage_size"]));
            span.appendChild(text);
            head_span.appendChild(span);
    
            span = document.createElement("span");
            span.style = "flex:1;";
            button = document.createElement("button");
            button.className = "button delete_button";
            button.setAttribute("onclick" , "delete_user("+a.toString()+")");
            if (window.innerWidth < 800){
                text = document.createTextNode("X");
            } else {
                text = document.createTextNode(delete_trans);
            }
            button.appendChild(text);
            span.appendChild(button);
            head_span.appendChild(span);

            span = document.createElement("span");
            span.style = "flex:1;";
            button = document.createElement("button");
            button.className = "button block_button";

            if (users[a]["blocked"]){
                button.setAttribute("onclick" , "unblock_user("+a.toString()+")");
                button.setAttribute("block" , "true");
                if (window.innerWidth < 800){
                    text = document.createTextNode("🚪");
                } else {
                    text = document.createTextNode(unblock_trans);
                }
            } else {
                button.setAttribute("onclick" , "block_user("+a.toString()+")");
                button.setAttribute("block" , "false");
                if (window.innerWidth < 800){
                    text = document.createTextNode("🛑");
                } else {
                    text = document.createTextNode(block_trans);
                }
            }
            
            button.appendChild(text);
            span.appendChild(button);
            head_span.appendChild(span);
    
            container.appendChild(head_span)
        }
    } else {
        if (page_ind == 0){
            head_span = document.createElement("span");
            head_span.className = "list_element";
    
            span = document.createElement("span");
            span.style = "flex:1; line-break: anywhere;";
            text = document.createTextNode(no_username_trans);
            span.appendChild(text);
            head_span.appendChild(span);
    
            span = document.createElement("span");
            span.style = "flex:1; line-break: anywhere;";
            text = document.createTextNode(no_email_trans);
            span.appendChild(text);
            head_span.appendChild(span);

            span = document.createElement("span");
            span.style = "flex:1; line-break: anywhere;";
            text = document.createTextNode(no_used_storage_trans);
            span.appendChild(text);
            head_span.appendChild(span);
    
            span = document.createElement("span");
            span.style = "flex:1";
            head_span.appendChild(span);
    
            container.appendChild(head_span)
        } else {
            document.getElementById("page_index").value = undo;
            set_user_list();
        }
        
    }
}

async function delete_user(index){
    if (confirm(ask_user_delete)){
        request = new FormData();

        request.append("username", users[index]["name"])
    
        req = await fetch("api/delete_user.php", {
            "method": "POST", 
            "body": request})
    
        cont = await req.json();
    
        if (cont["success"]){
            document.location.reload();
            alert(user_deleted_storage_trans)
        } else {
            alert(cont["message"]);
        }  
    }
}

async function block_user(index){
    request = new FormData();

    request.append("username", users[index]["name"])

    req = await fetch("api/block_user.php", {
        "method": "POST", 
        "body": request})

    cont = await req.json();

    if (cont["success"]){
        document.location.reload();
        alert(user_blocked_storage_trans)
    } else {
        alert(cont["message"]);
    }
}

async function unblock_user(index){
    request = new FormData();

    request.append("username", users[index]["name"])

    req = await fetch("api/unblock_user.php", {
        "method": "POST", 
        "body": request})

    cont = await req.json();


    if (cont["success"]){
        document.location.reload();
        alert(user_unblocked_storage_trans)
    } else {
        alert(cont["message"]);
    }
}

set_user_list();

function next_page(){
    act_page = parseInt(document.getElementById('page_index').value);
    undo = JSON.parse(JSON.stringify(page_ind + 1))

    if ((act_page) * 50 < file_length){
        document.getElementById('page_index').value = parseInt(document.getElementById('page_index').value) + 1
        set_user_list();    
    } else {
        document.getElementById('page_index').value = undo;
    }
}

function prec_page(){
    act_page = parseInt(document.getElementById('page_index').value);
    undo = JSON.parse(JSON.stringify(page_ind + 1))

    if (act_page > 1){
        document.getElementById('page_index').value = act_page - 1
    } else {
        document.getElementById('page_index').value = 1;

        if (undo != 1){
            set_user_list();
        }
    }

}

function enterpress(e){
    if(e.keyCode === 13){
        act_page = parseInt(document.getElementById('page_index').value);
        undo = JSON.parse(JSON.stringify(page_ind + 1))
        if ((act_page - 1) * 50 < file_length){
            if (act_page < 1){
                document.getElementById('page_index').value = 1;
            }    

            set_user_list();
        } else {
            document.getElementById('page_index').value = undo;
        }
       
    }
}

function adapt_user_list(){
    for (a = 0; a < document.getElementsByClassName("delete_button").length; a++){
        if (window.innerWidth > 800) {
            document.getElementsByClassName("delete_button")[a].innerText = delete_trans
        } else {
            document.getElementsByClassName("delete_button")[a].innerText = "X"
        }
    }

    for (a = 0; a < document.getElementsByClassName("block_button").length; a++){
        if (window.innerWidth > 800) {
            if (document.getElementsByClassName("block_button")[a].getAttribute("block") == "true") {
                document.getElementsByClassName("block_button")[a].innerText = unblock_trans
            } else {
                document.getElementsByClassName("block_button")[a].innerText = block_trans
            }
        } else {
            if (document.getElementsByClassName("block_button")[a].getAttribute("block") == "true") {
                document.getElementsByClassName("block_button")[a].innerText = "🚪"
            } else {
                document.getElementsByClassName("block_button")[a].innerText = "🛑"
            }
        }
    }
}