var arr
var key
var file_name

async function init(){
    req = await fetch("api/use_link.php?link_id="+link)
    cont = await req.json();

    if (!cont["success"] || window.location.hash.substring(1) == ""){
        if (!cont["success"]){
            alert(cont["message"])
        }
        document.location = "index.php";
    } else {
        key = cont["data"]["key"]
        key = decrypt_text(key, window.location.hash.substring(1));

        file_name = decrypt_text(cont["data"]["metadata"], key.valueOf())
        file_name = JSON.parse(file_name)

        document.getElementById("flname").innerText = file_name["name"];
        arr = []

        chunk = 3000000;
    
        for (i = 0; i <= Math.floor(cont["data"]["file_size"] / chunk); i++){
            while (true){
                try{
                    if (i == Math.floor(cont["data"]["file_size"] / chunk)){
                        req = await fetch("api/get_file.php?link_id="+cont["data"]["id"]+"&id="+cont["data"]["file"]+"&start="+(i*chunk).toString()+"&length="+(cont["data"]["file_size"] - i*chunk).toString())
                    } else {
                        req = await fetch("api/get_file.php?link_id="+cont["data"]["id"]+"&id="+cont["data"]["file"]+"&start="+(i*chunk).toString()+"&length="+chunk.toString())
                    }
                    download_cont = await req.blob();
                    download_cont = await download_cont.arrayBuffer();
                    temp_arr = Array.from(new Uint8Array(download_cont));
                    arr = arr.concat(temp_arr)
                    document.getElementsByClassName("button")[0].innerText = wait_translation+"... " + Math.round(i*chunk / cont["data"]["file_size"] * 100).toString() + "%("+downloading_trans+")"
                    break;
                } catch(e){
                    console.log(e)
                }
            }
        }

        document.getElementsByClassName("button")[0].innerText = uncypher_the_file;
    }
}

var img_extension = [".png", ".jpg", ".webp", ".avif"]
var pdf_extension = [".pdf"]
var audio_extension = [".mp3", ".wav"]

async function uncypher(){
    document.getElementsByClassName("button")[0].innerText = wait_translation+"... 0% (2/2)"
    wo = new Worker("script/uncypher-worker.js")
    wo.postMessage([arr, key, link, file_name["name"]]);

    wo.onmessage = (e) => {
        state = e.data[0];
        data = e.data[1];

        if (state == "prog"){
            fl_elem = document.getElementsByClassName("button")[0]
            fl_elem.innerText = wait_translation+"... "+data+" (2/2)"
        } else {
            fl_elem = document.getElementsByClassName("button")[0]
            fl_elem.innerText = wait_translation+"... (2/2)"

            fl_elem = document.getElementById("download")

            if (document.getElementById("preview_check").checked){
                file_type = "application/octet-stream";

                for (pdf in pdf_extension){
                    if (e.data[3].endsWith(pdf_extension[pdf])){
                        file_type = "pdf"
                        break;
                    }
                }

                for (ext in img_extension){
                    if (e.data[3].endsWith(img_extension[ext])){
                        file_type = "img"
                        break;
                    }
                }

                for (ext in audio_extension){
                    if (e.data[3].endsWith(audio_extension[ext])){
                        file_type = "audio"
                        break;
                    }
                }

                if (file_type == "pdf"){
                    conte = new Blob([new Uint8Array(data)], { type: 'application/pdf'});
                    var blobUrl = URL.createObjectURL(conte);

                    prev_pdf = document.createElement("iframe");
                    prev_pdf.type = "application/pdf"
                    prev_pdf.src = blobUrl;
                    prev_pdf.style = "width: 80%; border-radius: 3px; margin: 10px;"
                    prev_pdf.style.height = Math.round(window.screen.availHeight / 2).toString() + "px"
                        
                    document.getElementById("preview").appendChild(prev_pdf)
                }  else if (file_type == "img"){
                    conte = new Blob([new Uint8Array(data)], { type: 'application/octet-stream'});
                    var blobUrl = URL.createObjectURL(conte);

                    prev_image = document.createElement("img");
                    prev_image.src = blobUrl;
                    prev_image.style = "max-width: 80%; border-radius: 3px; margin: 10px;"
                    prev_image.style.maxHeight = Math.round(window.screen.availHeight / 2).toString() + "px"
                        
                    document.getElementById("preview").appendChild(prev_image)
                } else if (file_type == "audio"){
                    conte = new Blob([new Uint8Array(data)], { type: 'application/octet-stream'});
                    var blobUrl = URL.createObjectURL(conte);

                    prev_image = document.createElement("audio");
                    prev_image.src = blobUrl;
                    prev_image.controls = true;
                    prev_image.style = "margin: 20px; margin-bottom: 5px; border-radius:5px;"
                        
                    document.getElementById("preview").appendChild(prev_image)
                }
            }
	    
            fl_elem.href = blobUrl;
            fl_elem.download = e.data[3];
            fl_elem.innerText = download_trans;
            fl_elem.className = "just_text";
            setTimeout(adapt_display, 3)
        }  
      }
}

init();
