var running = false;

async function update(){
    if (!running){
        running = true;
        var check_update = await check_for_update();
        if (check_update[0]){
            document.getElementsByClassName("ligne")[0].style.color = "lightgreen"
        } else {
            if (check_update[1] == "You are up-to-date"){
                alert(trad_up_to_date);
            } else {
                document.getElementsByClassName("ligne")[0].style.color = "red"
                alert(check_update[1]);
            }
            return
        }  
        
        if (await download_update()){
            document.getElementsByClassName("ligne")[1].style.color = "lightgreen"
        } else {
            document.getElementsByClassName("ligne")[1].style.color = "red"
            return
        }
    
        if (await unzip_update()){
            document.getElementsByClassName("ligne")[2].style.color = "lightgreen"
        } else {
            document.getElementsByClassName("ligne")[2].style.color = "red"
            return
        }
    
        if (await apply_update()){
            document.getElementsByClassName("ligne")[3].style.color = "lightgreen"
        } else {
            document.getElementsByClassName("ligne")[3].style.color = "red"
            return
        }
    }
}

async function unzip_update(){
    var formData = new FormData();
    formData.append("cmd", "extract")
    req = await fetch("update.php", {
        body: formData,
        method: "POST",
    });

    cont = await req.json();

    if (cont["success"]){
        return true;
    } else {
        alert(cont["message"])
        return false;
    }
}

async function apply_update(){
    var formData = new FormData();
    formData.append("cmd", "apply")
    req = await fetch("update.php", {
        body: formData,
        method: "POST",
    });

    cont = await req.json();

    if (cont["success"]){
        return true;
    } else {
        alert(cont["message"])
        return false;
    }
}

async function check_for_update(){
    var formData = new FormData();
    formData.append("cmd", "check")
    req = await fetch("update.php", {
        body: formData,
        method: "POST",
    });

    cont = await req.json();

    if (cont["success"]){
        return [true];
    } else {
        return [false, cont["message"]];
    }
}

async function download_update(){
    var formData = new FormData();
    formData.append("cmd", "download")
    req = await fetch("update.php", {
        body: formData,
        method: "POST",
    });

    cont = await req.json();

    if (cont["success"]){
        return true;
    } else {
        alert(cont["message"])
        return false;
    }
}