var keySize = 256;
var ivSize = 128;
var iterations = 100;

function get_data(array){
  chunk_list = [];

  iter = Math.ceil(array.length / 1048);

  for (i = 0; i < iter; i++){
    chk = array.splice(0, 1048);

    key = false;
    iv = false;
    salt = false;

    iv = toHexString(chk.splice(0, 16));
    salt = toHexString(chk.splice(0, 8));

    chunk_list.push([iv, salt, chk])
  }

  return chunk_list
}

function decrypt_data(ct, iv, salt){
  data_to_decrypt = CryptoJS.lib.CipherParams.create({
    ciphertext: CryptoJS.enc.Hex.parse(ct), 
    iv: CryptoJS.enc.Hex.parse(iv), 
    salt: CryptoJS.enc.Hex.parse(salt)})
    
  decrypted_data = hexToBytes(CryptoJS.AES.decrypt(data_to_decrypt, pass).toString(CryptoJS.enc.Hex));

  return decrypted_data
}
