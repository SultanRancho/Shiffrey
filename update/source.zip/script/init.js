async function init(){
    request = new FormData();

    dbhost = document.getElementsByName("dbhost")[0].value;
    dbuser = document.getElementsByName("dbuser")[0].value;
    dbpassword = document.getElementsByName("dbpassword")[0].value;
    adminpassword = document.getElementsByName("adminpassword")[0].value;
    publicname = document.getElementsByName("public_name")[0].value;

    dbname = document.getElementsByName("dbname")[0].value;
    email = document.getElementsByName("email")[0].value;

    show_email = document.getElementsByName("show_email")[0].checked;

    request.append("dbhost", dbhost)
    request.append("dbuser", dbuser)
    request.append("dbpassword", dbpassword)
    request.append("adminpassword", adminpassword)
    request.append("public_name", publicname)

    if (dbname){
        request.append("dbname", dbname)
    }

    if (email){
        request.append("email", email)
    }

    if (show_email){
        request.append("show_email", "true")
    } else {
        request.append("show_email", "false")
    }

    req = await fetch("api/init.php", {
        "body": request,
        "method": "POST",
    });

    cont = await req.json();

    if (cont["success"]){
        window.location = "result/initdone.php";
    } else {
        alert(cont["message"]);
    }
}