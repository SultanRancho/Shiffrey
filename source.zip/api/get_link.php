<?php
include("../secure/head.php");

header("Content-Type: application/json");

if (!($_SERVER['REQUEST_METHOD'] === "GET")){
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
    // Connect to the db
    include("../secure/sql_connection.php");
    // Verify if the session is always activ
    include("../secure/check_connection.php");

    if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        $username = $_SESSION["username"];
        if (isset($_GET["file_id"])){
            $fileid = mysqli_real_escape_string($conn, $_GET["file_id"]);

            $sql = "SELECT `owner` FROM `content` WHERE `id` = '".$fileid."'";
            $result = $conn->query($sql);

            if ($result and $result->num_rows > 0){
                $sql = "SELECT `id`, `key`, `blocked`, `file`, `name` FROM `link` WHERE `owner` = '".$username."' AND `file` = '".$fileid."'";
                $result = $conn->query($sql);
        
                if ($result and $result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                        if ($row["blocked"] == 'false'){
                            $blocked = FALSE;
                        } else {
                            $blocked = TRUE;
                        }
        
                        echo json_encode(array("success" => TRUE, "data" =>  array("id" => $row["id"], "key" => $row["key"], "name" => $row["name"], "blocked" => $blocked)), JSON_PRETTY_PRINT);
                    }
                } else {
                    echo '{"success": false, "message": "No link for this file"}';
                }
            } else {
                echo '{"success": false, "message": "This file do not exist"}';
            }
        } else {
            http_response_code(500);
            die('{"success": false, "message": "file_id is not specified !"}');
        }
    } else {
        http_response_code(403);
        die('{"success": false, "message": "You are not connected !"}');
    }
} else {
    http_response_code(400);
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>