<?php
include("../../secure/head.php");

if (!($_SERVER['REQUEST_METHOD'] === "POST")){
    die('{"success": false, "message": "Bad request method."}');
}

session_start();
$config_path = "../../IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

if ($config->{"done"}){
     // Connect to the db
     include("../../secure/sql_connection.php");
     // Verify if the session is always activ
     include("../../secure/check_connection.php");

    
     if (isset($_SESSION["username"]) and isset($_SESSION["token"])){
        if (!isset($_POST["append_to_file"])){
            $filename = mysqli_real_escape_string($conn, $_FILES["file"]["name"]);
            $filesize = mysqli_real_escape_string($conn, $_FILES["file"]["size"]);
            $fileid = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));
            $fileowner = $_SESSION["username"];

            // get the actual storage space used by the user
            $actual_storage_used = NULL;
            $sql = "SELECT `storage_size` FROM `user` WHERE `username` = '".$fileowner."'";
            $result = $conn->query($sql);

            foreach ($result as $row){
                $actual_storage_used = intval($row["storage_size"]);
                if ($actual_storage_used == NULL){
                    $actual_storage_used = 0;
                }
            }

            if ($_FILES["file"]["size"] > 0 and $filesize <= $config->{"max_file_size"} and ($actual_storage_used + $filesize <= $config->{"max_user_storage_size"})){
                if (strlen($filename) <= 1000){
                    if (isset($_POST["key"])){
                        $key = mysqli_real_escape_string($conn, $_POST["key"]);
                    } else {
                        $key = "";
                    }
        
                    while (TRUE){
                        if (!file_exists($fileid)){
                            move_uploaded_file($_FILES["file"]["tmp_name"], "../../IMPORTANT/content/".$fileid);
                            $sql = 'UPDATE `user` SET `storage_size`= `storage_size` + '.$filesize.' WHERE `username` = "'.$fileowner.'"';
                            $result = $conn->query($sql);

                            if (!$result){
                                http_response_code(500);
                                header("Content-Type: application/json");
                                die('{"success": false, "message": "Something wrong is happened."}');
                            }

                            $folder = -1;

                            if (isset($_POST["parent_folder"])){
                                $folder = mysqli_real_escape_string($conn, $_POST["parent_folder"]);

                                $sql = "SELECT `id` FROM `folders` WHERE `id` = '".$folder."'";
                                $result = $conn->query($sql);

                                if (!($result and $result->num_rows > 0)){
                                    $folder = -1;
                                }
                            }

                            $sql = 'INSERT INTO `content`(`metadata`, `size`, `id`, `owner`, `associated_key`, `folder`, `creation_time`) VALUES ("'.$filename.'","'.$filesize.'","'.$fileid.'","'.$fileowner.'", "'.$key.'", "'.$folder.'", '.time().')';
                            $result = $conn->query($sql);
                            
                            if ($result){
                                http_response_code(200);
                                header("Content-Type: application/json");
                                echo '{"success": true, "message": "Your file have been sucessfully uploaded.", "id": "'.$fileid.'"}';
                            } else {
                                http_response_code(500);
                                header("Content-Type: application/json");
                                die('{"success": false, "message": "Something wrong is happened."}');
                            }
                            break;
                        } else {
                            $fileid = mysqli_real_escape_string($conn, bin2hex(random_bytes(30)));
                        }
                    } 
                } else {
                    http_response_code(400);
                    header("Content-Type: application/json");
                    die('{"success": false, "message": "The file name is too long"}');
                }
            } else {
                http_response_code(400);
                header("Content-Type: application/json");
                die('{"success": false, "message": "The file is too big, or this content is empty."}'); 
            }
        } else {
            $fileid = mysqli_real_escape_string($conn, $_POST["append_to_file"]);
            $filesize = mysqli_real_escape_string($conn, $_FILES["file"]["size"]);

            $sql = "SELECT `id` FROM `content` WHERE `id` = '".$fileid."'";
            $result = $conn->query($sql);

            if ($result){
                $chunk = fopen($_FILES["file"]["tmp_name"], "r");

                while (!feof($chunk)){
                    $cont = fread($chunk, 1024);
                    file_put_contents("../../IMPORTANT/content/".$fileid, $cont, FILE_APPEND);
                }

                fclose($chunk);

                $sql = "UPDATE `content` SET `size` = `size` + ".$filesize." WHERE `id` = '".$fileid."' AND `owner` = '".$_SESSION["username"]."'";
                $result = $conn->query($sql);

                $sql = "UPDATE `user` SET `storage_size` = `storage_size` + ".$filesize." WHERE `username` = '".$_SESSION["username"]."'";
                $result = $conn->query($sql);  
                
                http_response_code(200);
                header("Content-Type: application/json");
                echo '{"success": true, "message": "Content successfully append."}';
            } else {
                http_response_code(404);
                header("Content-Type: application/json");
                die('{"success": false, "message": "The file is\'nt yet created"}');
            }
        }
   } else {
        http_response_code(403);
        header("Content-Type: application/json");
        die('{"success": false, "message": "You aren\'t connected"}');
     }
} else {
    http_response_code(400);
    header("Content-Type: application/json");
    die('{"success": false, "message": "Init isn\'t done"}');
}
?>