<?php
include("secure/head.php");
session_start();
include("secure/load_config.php");

if (!$config->{"done"})
    {
        http_response_code(302);
        header("Location: init.php");
        die();
    }
?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central" style="padding: 15px">
                <h1 class="title"><?php translate("SET_NEW_PASSWORD") ?>:</h1>
                <?php 
                if (isset($config->{"admin"}->{"email"}) and $config->{"admin"}->{"email"})
                    {
                        echo '<a href="new_password.php"><button class="button" onclick="copy_inst()">';
                        echo translate("SEND_RECOVERY_EMAIL");
                        echo '</button><b></a><span class="paragraphe" style="margin-top: 30px; margin-bottom: 30px">';
                        echo translate("OR");
                        echo '</span></b>';
                    } 
                ?>
                
                <input class="input input_central" type="password" id="new_password" oninput="hash_password()" placeholder="<?php translate("NEW_PASSWORD_PLACEHOLDER") ?>"></input>
                <br>
                <div style="width:80%; margin: 0 auto; text-align: left;">
                    <b><span class="paragraphe"><?php translate("PASSWORD_INSTRUCTION_ADMIN") ?></span></b>
                </div>
                <code class="paragraphe" id="instructions" style="line-break: anywhere; border: solid rgb(85, 241, 252) 1px; text-align: left; border-radius: 5px; width:80%; margin: 0 auto; padding: 5px">
                    <?php translate("No password has been entered yet") ?>
                </code>
                <div style="height:20px;"></div>
                <button class="button" onclick="copy_inst()"><?php translate("COPY_INSTRUCTIONS") ?></button>
            </div>
            <script src="script/crypto-js/bcrypt.min.js"></script>
            <script>
                function hash_password(){
                    if (document.getElementById("new_password").value != ""){
                        var salt = dcodeIO.bcrypt.genSaltSync(10);
                        var hash = dcodeIO.bcrypt.hashSync(document.getElementById("new_password").innerHTML, salt);
                        document.getElementById("instructions").innerHTML = '<?php translate("PASSWORD_INSTRUCTION") ?> : "' + hash + '"';
                    } else {
                        document.getElementById("instructions").innerHTML = "<?php translate("NO_NEW_PASSWORD_ENTERED") ?>"
                    }
                }

                function copy_inst(){
                    navigator.clipboard.writeText(document.getElementById("instructions").innerText);
                }
                hash_password()
            </script>
        </body>
        <script src="script/adapt.js"></script>
    </html>