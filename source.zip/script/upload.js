async function get_set(){
    await get_settings();
    document.getElementById("max_storage").innerText = max_size_trans+":"+convertUnit(getCookie("MAX_FILE_SIZE"));
}

get_set();

var max_file_size = 0;

function select_file(){
    document.getElementById("file").click();
}

function allowDrop(event) {
    event.preventDefault();
  }

function drag_and_drop(evt){
    evt.stopPropagation()
    evt.preventDefault();
    fl = evt.dataTransfer.files;
    document.getElementById("file").files = fl;
    change_text()
}

document.addEventListener("dragenter", function(event) {
    if (event.target.className == "upload" || event.target.id == "filename") {
        document.getElementById("dropzone").style.borderStyle = "dashed";
        document.getElementById("dropzone").style.borderWidth = "2px";
    }
})

document.addEventListener("dragleave", function(event) {
    if ((event.relatedTarget == null) || (event.target.id == "dropzone" && event.relatedTarget.id != "filename")) {
        document.getElementById("dropzone").style.borderStyle = "solid";
        document.getElementById("dropzone").style.borderWidth = "1px";
    }
})

var encrypted = [];
var cle_array = [];
var loaded = 0;
var w = null;

async function change_text(){
    loaded = 0;

    total_size = 0;

    files_list = document.getElementById("file").files

    if (files_list.length != 0){
        max_file_size = Number(getCookie("MAX_FILE_SIZE"))
        max_user_storage = Number(getCookie("MAX_USER_STORAGE_SIZE"))
        actual_user_storage = Number(getCookie("ACTUAL_USER_STORAGE"))

        for (a = 0; a < files_list.length; a++){
                total_size += files_list[a].size;
            }

        if (actual_user_storage + total_size <= max_user_storage){        
            encrypted = []
            cle_array = []
            div = document.getElementById("file_name");
            div.innerText = ""
            
            if (w != null){
                w.terminate()
            }
            
            w = new Worker("script/cypher-worker.js")

            for (i = 0; i < document.getElementById("file").files.length; i++){
                loaded += 1

                file_name = document.getElementById("file").files[i].name;

                inp = document.createElement("input");
                inp.className = "file";
                inp.id = "file"+i;
                inp.setAttribute("max_length", 500);
                inp.value = file_name;
                div.appendChild(inp);

                spn = document.createElement("span");
                spn.className = "file-size";
                spn.id = "file-size"+i;
                spn.innerText = loading_trans+" ..."
                div.appendChild(spn);

                adapt_display();

                let reader = new FileReader();

                size_fl = document.getElementById("file").files[i].size;
                
                cle_array[i] = generateRandomHexString(256)
                reader.fileName = copy(file_name)
                reader.ind = copy(i)
                reader.readAsArrayBuffer(document.getElementById("file").files[i]);

                reader.onload = function(readerEvent) {                
                    filesize = this.result.byteLength;
                    local_ind = readerEvent.target.ind;

                    if (filesize < max_file_size && filesize + actual_user_storage < max_user_storage){
                        sddt = Array.from(new Uint8Array(this.result));

                        w.postMessage([sddt, cle_array[local_ind], sddt.length, local_ind]);
                    } else {
                        alert(file_big_trans)
                        document.getElementById("file-size"+local_ind).remove();
                        document.getElementById("file"+local_ind).remove();
                    }
                }
            }

            w.onmessage = (e) => { 
                if (e.data[0] == "end"){
                    document.getElementById("file-size"+e.data[2]).innerText = wait_trans+"...";
                    edata = new Blob([new Uint8Array(e.data[1])]);
                    if (loaded == document.getElementById("file").files.length && encrypted != []){
                        if (encrypted.length > 1){
                            document.getElementById("upload").innerText = upload_files_trans
                        } else {
                            document.getElementById("upload").innerText = upload_file_trans
                        }

                        document.getElementById("upload").style.visibility = "visible"
                    }

                    if (edata.size >= max_file_size && edata.size + actual_user_storage <= max_user_storage){
                        alert(file_big_trans)
                        document.getElementById("file-size"+e.data[2])[e.data[2]].remove();
                        document.getElementById("file"+e.data[2]).remove();
                    } else {
                        encrypted[e.data[2]] = edata;
                        document.getElementById("file-size"+e.data[2]).innerText = convertUnit(encrypted[e.data[2]].size);
                    }
                } else if (e.data[0] == "prog"){
                    document.getElementById("file-size"+e.data[2]).innerText = e.data[1];
                }
            }
        } else {
            alert(storage_space_trans)
        }
    }
}

async function send() {
    if (encrypted == []){
        return
    }

    max_file_size = Number(getCookie("MAX_FILE_SIZE"))
    max_user_storage = Number(getCookie("MAX_USER_STORAGE_SIZE"))
    actual_user_storage = Number(getCookie("ACTUAL_USER_STORAGE"))

    total_encrypted_size = 0;

    var chunk_size = 3000000

    for (a = 0; a < encrypted.length; a++){
        if (encrypted[a]){
            total_encrypted_size += encrypted[a].size
        }
    }
    if (total_encrypted_size <= max_file_size && total_encrypted_size + actual_user_storage <= max_user_storage){
        document.getElementById("upload").style.visibility = "hidden"
        for (j = 0; j < encrypted.length; j++){
        if (encrypted[j]){
            filename = document.getElementById("file"+j).value;
            filename = JSON.stringify({"name": filename});
            filename = encrypt_text(filename, cle_array[j]);

            if (encrypted[j].size < chunk_size){
                first_chunk = encrypted[j];
            } else {
                first_chunk = encrypted[j].slice(0, chunk_size)
            }
            
            loop: {
                while (true){
                    try {
                        var formData = new FormData();
                    
                        formData.append("file", first_chunk, filename);
                        formData.append("key", encrypt_text(cle_array[j], localStorage.getItem("key")));
                        formData.append("parent_folder", localStorage.getItem("fold_id"));
    
                        req = await fetch("api/upload/upload.php", {
                            body: formData,
                            method: "POST",
                        });
    
                        cont = await req.text();
                        cont_json = JSON.parse(cont);
    
                        if (cont_json["success"]){
                            break loop;
                        } else {
                            alert(cont_json["message"])
                        }
                    } catch (error) {
                        alert(error)
                    }
                }
            }
           

            fi_id = cont_json["id"];

            if (encrypted[j].size > 500000){
                math_ceil = Math.ceil(encrypted[j].size / chunk_size)
                for (i = 0; i <= math_ceil - 1; i++){
                    var formData = new FormData();

                    formData.append("file", encrypted[j].slice((i + 1)*chunk_size, (i + 2)*chunk_size), filename);
                    formData.append("append_to_file", fi_id);
                    formData.append("parent_folder", localStorage.getItem("fold_id"));

                    loop: {
                        while (true){
                            try {
                                req = await fetch("api/upload/upload.php", {
                                    body: formData,
                                    method: "POST",
                                });
                                cont = await req.text();

                                cont_json = JSON.parse(cont);
                
                                if (cont_json["success"]){
                                    break loop;
                                } else {
                                    alert(cont_json["message"])
                                }
                            } catch (error) {
                                alert(error)
                            }
                        }
                    }
                    document.getElementById("file-size"+j).innerText = Math.round(i / math_ceil * 100).toString() + "%";
                }

                document.getElementById("file-size"+j).innerText = "✔"
                if (j == encrypted.length - 1){
                    document.location = "panel.php";
                }
            } else {
                if (cont_json){
                    if (cont_json["success"]){
                        document.getElementById("file-size"+j).innerText = "✔"

                        if (j == encrypted.length - 1){
                            document.location = "panel.php";
                        }
                    } else {
                        alert(cont_json["message"]); 
                    }
                } else {
                    alert(error_trans);
                }
            }
        }
        } 
    } else {
        alert(storage_space_trans)
    }
}