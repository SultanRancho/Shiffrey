async function get_link_info(){
    req = await fetch("api/get_link.php?file_id="+id)
    cont = await req.json();

    if (cont["success"]){
        document.getElementById("link").innerText = link_start + "/link.php?id="+cont["data"]["id"]+"#"+decrypt_text(cont["data"]["name"], localStorage.getItem("key"))
        central_div = document.getElementsByClassName("central")[0];

        content = "";

        content += "<button class='button' style='margin: 5px' onclick='copy_link()'>"+copy_link_trans+"</button>";

        if (cont["data"]["blocked"]){
            content += "<button onclick='unblock_link()' id='block_but' style='margin: 5px' class='button'>"+unblock_link_trans+"</button>";
        } else {
            content += "<button onclick='block_link()' id='block_but' style='margin: 5px' class='button'>"+block_link_trans+"</button>";
        }
        content += "<button class='button' style='margin: 5px' onclick='delete_link()'>"+delete_link_trans+"</button><br><a href='panel.php' class='back_link'>< "+back_trans+"</a>";

        central_div.innerHTML = central_div.innerHTML + content;
    } else {
        if (cont["message"] != "No link for this file"){
            alert(cont["message"])
            document.location = "panel.php";
        } else {
            document.getElementById("link").innerText = no_link_created_trans;

            central_div = document.getElementsByClassName("central")[0];
            central_div.innerHTML = central_div.innerHTML + "<button class='button' onclick='create_link()'>"+create_link_trans+"</button><br><a href='panel.php' class='back_link'>< "+back_trans+"</a>"
        }
    }
}

async function create_link(){
    request = new FormData();

    file_cle = decrypt_text(file_key, localStorage.getItem("key"))

    cle = generateRandomHexString(10);
    nme = encrypt_text(cle, localStorage.getItem("key"))
    key = encrypt_text(file_cle, cle)

    request.append("file_id", id)
    request.append("key", key)
    request.append("name", nme)

    req = await fetch("api/create_link.php" ,  {"method": "POST", 
        "body": request})

    cont = await req.json();

    if (cont["success"]){
        document.location.reload();
    }
}

async function block_link(){
    request = new FormData();

    request.append("file_id", id);

    req = await fetch("api/block_link.php",
        {
            method: "POST", 
            body: request
        })

    cont = await req.json();

    if (cont["success"]){
        document.getElementById("block_but").innerText = unblock_link_trans;
        document.getElementById("block_but").setAttribute("onclick", "unblock_link()");
        alert(link_blocked_trans)
    } else {
        alert(cont["message"])
    }
}

async function unblock_link(){
    request = new FormData();

    request.append("file_id", id);

    req = await fetch("api/unblock_link.php",
        {
            method: "POST",
            body: request,
        })

    cont = await req.json();

    if (cont["success"]){
        document.getElementById("block_but").innerText = block_link_trans;
        document.getElementById("block_but").setAttribute("onclick", "block_link()");
        alert(link_unblocked_trans)
    } else {
        alert(cont["message"])
    }
}

async function delete_link(){
    request = new FormData();

    request.append("file_id", id);

    req = await fetch("api/delete_link.php",
        {
            method: "POST",
            body: request,
        })

    cont = await req.json();

    if (cont["success"]){
        document.location.reload();
        alert(link_deleted_trans)
    } else {
        alert(cont["message"])
    }
}

function copy_link(){
    navigator.clipboard.writeText(document.getElementById("link").innerText);
}