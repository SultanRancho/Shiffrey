async function login(){
    request = new FormData();
    
    password = document.getElementsByName("password")[0].value;
    username = document.getElementsByName("username")[0].value;

    if (username != "" && password != ""){
        try{
            var password_hashed = sha512(sha512(password));
            var key = sha384(password);
        } catch (e){
            alert("Shiffrey does not work with your browser or with your connection. Try switching to another browser or activate https.");
        }
        
    
        request.append("username", username)
        request.append("password", password_hashed)
    
        req = await fetch("api/login.php", {
            "body": request,
            "method": "POST",
        });
    
        cont = await req.text();
        cont_json = JSON.parse(cont);
    
        if (cont_json){
            if (cont_json["success"]){
                localStorage.setItem("key", key);
    
                document.location = "panel.php";
            } else {
                alert(cont_json["message"]); 
            }
        } else {
            alert("Error");
        }
    }

}