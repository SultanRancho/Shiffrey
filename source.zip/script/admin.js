async function login(){
    password = document.getElementById("password").value;

    request = new FormData();
    request.append("password", password)

    req = await fetch("api/admin_login.php", {
        "body": request,
        "method": "POST",
    });

    cont = await req.text();
    cont_json = JSON.parse(cont);

    if (cont_json){
        if (cont_json["success"]){
            document.location = "admin_panel.php";
        } else {
            alert(cont_json["message"]); 
        }
    } else {
        alert("Error");
    }
}

async function save_settings(){
    password = document.getElementById("password").value;
    mail = document.getElementById("email").value;
    publicname = document.getElementById("public_name").value;
    creation = document.getElementById("creation-select").value;
    file_unit = document.getElementById("file-unit").value;
    user_unit = document.getElementById("user-unit").value;
    file_size = document.getElementById("file-size").value;
    user_size = document.getElementById("user-size").value;

    request = new FormData();

    // get the password
    if (password){
        request.append("password", password)
    }

    // get the email
    request.append("email", mail)
    // get the public name
    request.append("public_name", publicname)

    // get account creation mode
    if (creation == "true"){
        request.append("access", "true")
    } else if (creation == "false"){
        request.append("access", "false")
    }

    // get file size
    if (file_unit == "ko")
        {
            file_size = file_size * 1000
    } else if (file_unit == "mo")
    {
        file_size = file_size * 1000000
    } else if (file_unit == "go")
    {
        file_size = file_size * 1000000000
    }

    // get user max size
    if (user_unit == "ko")
        {
            user_size = user_size * 1000
    } else if (user_unit == "mo")
        {
            user_size = user_size * 1000000
    } else if (user_unit == "go")
        {
            user_size = user_size * 1000000000
        }

    request.append("file_size", file_size.toString());
    request.append("max_user_storage_size", user_size.toString());

    if (document.getElementById("show_email").checked){
        request.append("show_email", "true")
    } else {
        request.append("show_email", "false")
    }

    req = await fetch("api/admin_settings.php", {
        "body": request,
        "method": "POST",
    });

    cont = await req.text();
    cont_json = JSON.parse(cont);

    if (cont_json){
        alert(settings_saved); 
    } else {
        alert("Error");
    }

    document.getElementById("password").value = "";
    window.location.reload();
}

async function logout(){
    req = await fetch("api/admin_logout.php", {"method": "POST"});
    cont = await req.text();

    cont_json = JSON.parse(cont);

    if (cont_json["success"]){
        window.location = "result/disconnected.php";
    } else {
        alert(cont_json["message"])
    }
}

async function delete_all_sessions(){
    req = await fetch("api/delete_admin_sessions.php", {"method": "POST"})
    cont = await req.json()
    
    if (cont["success"]){
        alert(sessions_deleted)
    } else {
        alert(cont["message"])
    }
}