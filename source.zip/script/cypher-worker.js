importScripts("crypto-js/crypto-js.js");
importScripts("devtools.js");

var keySize = 256;
var ivSize = 128;
var iterations = 100;

function chunk(array, ind){
    iter = Math.ceil(array.length / block_size);
    chunk_list = []

    for (a = 0; a < iter; a++){
        chk = []
        for (b = 0; b < block_size; b++){
            pos =  a * block_size + b;
            if (array.length > pos){
                chk.push(array[pos])
            } else {
                break
            }
        }
        chunk_list.push(chk)

        postMessage(["prog", "1/2 :" + Math.round(a / iter * 100) +"%", ind]);
    }

    return chunk_list;
}

function encrypt_data(hex, key){
    dt = CryptoJS.enc.Hex.parse(hex);
    enc = CryptoJS.AES.encrypt(dt, key);
    return enc.key.toString() + enc.iv.toString() + enc.salt.toString() + enc.ciphertext.toString();
  }

onmessage = (e) => {
    final_array = [];

    block_size = 1023;

    key = e.data[1]
    chunk_list = chunk(e.data[0], e.data[3]);

    for (u in chunk_list){
        data = toHexString(chunk_list[u]);
        encrypted_data = encrypt_data(data, key);
        block = hexToBytes(encrypted_data);

        for (i in block){
            final_array.push(block[i])
        }

        postMessage(["prog", "2/2:"+Math.round(u / chunk_list.length * 100) +"%", e.data[3]]);
    }

    postMessage(["prog","100%", e.data[3]]);
    
    postMessage(["end", final_array, e.data[3]]);
}

