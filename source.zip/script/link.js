var arr
var key
var file_name

async function init(){
    req = await fetch("api/use_link.php?link_id="+link)
    cont = await req.json();

    if (!cont["success"] || window.location.hash.substring(1) == ""){
        if (!cont["success"]){
            alert(cont["message"])
        }
        document.location = "index.php";
    } else {
        key = cont["data"]["key"]
        key = decrypt_text(key, window.location.hash.substring(1));

        file_name = decrypt_text(cont["data"]["metadata"], key.valueOf())
        file_name = JSON.parse(file_name)

        document.getElementById("flname").innerText = file_name["name"];
        arr = []

        chunk = 35648;
    
        for (i = 0; i <= Math.floor(cont["data"]["file_size"] / chunk); i++){
            while (true){
                try{
                    if (i == Math.floor(cont["data"]["file_size"] / chunk)){
                        req = await fetch("api/get_file.php?link_id="+cont["data"]["id"]+"&id="+cont["data"]["file"]+"&start="+(i*chunk).toString()+"&length="+(cont["data"]["file_size"] - i*chunk).toString())
                    } else {
                        req = await fetch("api/get_file.php?link_id="+cont["data"]["id"]+"&id="+cont["data"]["file"]+"&start="+(i*chunk).toString()+"&length="+chunk.toString())
                    }
                    download_cont = await req.blob();
                    download_cont = await download_cont.arrayBuffer();
                    temp_arr = Array.from(new Uint8Array(download_cont));
                    arr.push.apply(arr, temp_arr)
                    document.getElementsByClassName("button")[0].innerText = wait_translation+"... " + Math.round(i*chunk / cont["data"]["file_size"] * 100).toString() + "%("+downloading_trans+")"
                    break;
                } catch(e){
                    console.log(e)
                }
            }
        }

        document.getElementsByClassName("button")[0].innerText = uncypher_the_file;
    }
}

async function uncypher(){
    document.getElementsByClassName("button")[0].innerText = wait_translation+"... 0% (2/2)"
    wo = new Worker("script/uncypher-worker.js")
    wo.postMessage([arr, key, link, file_name["name"]]);

    wo.onmessage = (e) => {
        state = e.data[0];
        data = e.data[1];

        if (state == "prog"){
            fl_elem = document.getElementsByClassName("button")[0]
            fl_elem.innerText = wait_translation+"... "+data+" (2/2)"
        } else {
            fl_elem = document.getElementsByClassName("button")[0]
            fl_elem.innerText = wait_translation+"... (2/2)"

            fl_elem = document.getElementById("download")
            conte = new Blob([new Uint8Array(data)], { type: 'application/octet-stream'});
            const blobUrl = URL.createObjectURL(conte);
            fl_elem.href = blobUrl;
            fl_elem.download = e.data[3];
            fl_elem.innerText = download_trans;
            fl_elem.className = "just_text";
        }  
      }
}

init();