<?php
include("secure/head.php");

session_start();
include("secure/load_config.php");


if ($config->{"done"}){
    // Connect to the db
    include("secure/sql_connection.php");
    // Verify if the session is always activ
    include("secure/check_connection.php");
    
    if (!(isset($_SESSION["username"]) and isset($_SESSION["token"]))){
        header("Location: error/noconnected.php");
        die();
    }

    if (!isset($_GET["file_id"])){
        http_response_code(400);
        header("Location: panel.php");
        die();
    }
} else {
    header("Location: init.php");
    die();
}
?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/upload.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central">
                <h1 class="title"><?php translate("SHARE_LINK") ?>:</h1>
                <span class="just_text" id="link" style="font-size: large; line-break: anywhere; width: 80%;display: block; margin: 0 auto;"><?php translate("WAIT") ?> ...</span>
                <br>
                <div style="height:20px"></div>
            </div>
        </body>
        <script src="script/crypto-js/crypto-js.js"></script>
        <script src="script/devtools.js"></script>
        <script src="script/adapt.js"></script>
        <script src="script/share.js"></script>
        <script>
            // translation
            var unblock_link_trans = "<?php translate("UNBLOCK_LINK") ?>";
            var block_link_trans = "<?php translate("BLOCK_LINK") ?>";
            var back_trans = "<?php translate("BACK") ?>";
            var no_link_created_trans = "<?php translate("NO_LINK_CREATED", "string") ?>";
            var create_link_trans = "<?php translate("CREATE_LINK") ?>";
            var copy_link_trans = "<?php translate("COPY_LINK") ?>";
            var delete_link_trans = "<?php translate("DELETE_LINK") ?>";
            var link_blocked_trans = "<?php translate("LINK_BLOCKED", "string") ?>";
            var link_unblocked_trans = "<?php translate("LINK_UNBLOCKED", "string") ?>";
            var link_deleted_trans = "<?php translate("LINK_DELETED", "string") ?>";

            var id = "<?php if (strlen($_GET["file_id"]) == 60){$fileid = $_GET["file_id"]; echo htmlspecialchars($_GET["file_id"]);} ?>";
            var file_key = "<?php 
            $sql = "SELECT `associated_key` FROM `content` WHERE `id`= '".mysqli_real_escape_string($conn, $fileid)."'"; 
            $result = $conn->query($sql);
            
            foreach ($result as $row){
                echo htmlspecialchars($row["associated_key"]);
            } 
            ?>";
            var link_start = "<?php echo htmlspecialchars($config->{"public_name"}) ?>"
            if (file_key != ""){
                get_link_info();
            } else {
                document.location = "panel.php";
            }

        </script>
    </html>