
<?php
include("secure/head.php");
session_start();
// load the config file
include("secure/load_config.php");


if (!$config->{"done"})
    {
        http_response_code(302);
        header("Location: init.php");
        die();
    } else {
        if (isset($_SESSION["username"])){
            header("Location: panel.php");
            http_response_code(302);
            die();
        } else {
            $signup = "";

            if ($config->{"allow_account_creation"}){
                $signup = '<button class="button" onclick="window.location = \'signup.php\'">Sign up</button>';
            }
        }
    }
?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central_login" style="padding: 15px">
                <h1 class="title"><?php translate("LOGIN") ?></h1>
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("USERNAME") ?> :</h4>
                </div>
                <input type="text" name="username" class="input input_central">
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("PASSWORD") ?> :</h4>
                </div>
                <input type="password" name="password" onkeypress="if (event.keyCode == 13){login()}" class="input input_central"><br>
                <div style="width: 80%; margin: 0 auto; display:flex">
                    <div style="text-align: left; flex: 2;">
                    <button class="button" onclick="window.location = 'admin.php'"><?php translate("LOGIN_ADMIN") ?></button>
                        <?php echo $signup; ?>
                    </div>
                    <div style="text-align: right; flex: 1;">
                        <button class="button" onclick="login()"><?php translate("LOGIN") ?></button>
                    </div>
                </div> 
                    <?php
                        if ($config->{"admin"}->{"show_email"}){
                            echo '<a href="mailto:'.htmlspecialchars($config->{"admin"}->{"email"}).'" class="back_link">';
                            echo translate("CONTACT_ADMINISTRATOR");
                            echo '</a>';
                        }
                    ?>
                
            </div>
        </body>
        <script src="script/crypto-js/sha512.min.js"></script>
        <script src="script/login.js"></script>
        <script src="script/adapt.js"></script>
    </html>
