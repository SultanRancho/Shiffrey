<?php
include("secure/head.php");
session_start();
include("secure/load_config.php");

if (!$config->{"done"})
    {
        http_response_code(302);
        header("Location: init.php");
        die();
    } else {
        $token = json_decode(file_get_contents("IMPORTANT/password_recovery_token.tk"));

        if (!(isset($_GET["token"]) and $token->{"token"} == $_GET["token"] and $token->{"creation_time"} + 86400 > time() and file_exists("secure/password_recovery_token.tk"))){
            if ($token->{"creation_time"} + 300 > time()){
                unlink("IMPORTANT/password_recovery_token.tk");
            }
            
            http_response_code(302);
            header("Location: admin.php");
            die();
        }
    }
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Shiffrey</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style/main.css">
        <link rel="stylesheet" href="style/widget.css">
        <link rel="icon" type="images/png" href="images/favicon.png">
    </head>
    <body onresize="adapt_display()">
        <div class="central">
            <h1 class="title"><?php translate("NEW_PASSWORD_PLACEHOLDER") ?> :</h1>
            <input class="input input_central" type="password" id="new_password" oninput="hash_password()" placeholder="Write your new password"></input>
            <br>
            <button class="button" onclick="change_pwd()" style="margin: 5px;"><?php translate("CHANGE_PASSWORD") ?></button>
        </div>
    </body>
    <script src="script/adapt.js"></script>
    <script>
        token = "<?php echo htmlspecialchars($_GET["token"]) ?>"

        async function change_pwd(){
            formdata = new FormData();
            formdata.append("token", token);
            formdata.append("new_password", document.getElementById("new_password").value);

            req = await fetch("api/change_password.php", {"method": "POST", "body": formdata})
            cont = await req.json()

            if (cont["success"]){
                alert("<?php translate("SUCCESS_PASSWORD_CHANGE", "string") ?>");
                document.location = "admin.php";
            } else {
                alert(cont["message"]);
            }
        }

        send_email();
    </script>
</html>