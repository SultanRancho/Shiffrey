<?php
include("../secure/load_config.php");
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Shiffrey</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../style/main.css">
        <link rel="stylesheet" href="../style/widget.css">
        <link rel="icon" type="images/png" href="../images/favicon.png">
    </head>
    <body onresize="adapt_display()">
        <div class="central">
            <span class="just_text"><?php translate("DISCONNECTED") ?></span>
            </br>
            <a href="../index.php"><button class="button" style="margin: 5px;"><?php translate("BACK_HOME") ?> ></button></a>
        </div>
    </body>
    <script src="../script/adapt.js"></script>
</html>


    