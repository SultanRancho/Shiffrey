<?php
include("secure/head.php");

// load the config file
include("secure/load_config.php");

if ($config->{"done"})
    {
        http_response_code(302);
        header("Location: result/initdone.php");
        die();
    }
?>

<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
                <div class="central">
                    <h1 class="title"><?php translate("INIT") ?></h1>
                    <div class="title_box">
                        <h4 class="medium_title"><?php translate("SQL_SERVER_ADRESSE") ?> :</h4>
                    </div>
                    <input type="text" name="dbhost" class="input input_central">
                    <div class="title_box">
                        <h4 class="medium_title"><?php translate("SQL_USERNAME") ?> :</h4>
                    </div>
                    <input type="text" name="dbuser" class="input input_central">
                    <div class="title_box">
                        <h4 class="medium_title"><?php translate("SQL_PASSWORD") ?> :</h4>
                    </div>
                    <input type="password" name="dbpassword" class="input input_central" placeholder="<?php translate("CAN_EMPTY") ?>">
                    <div class="title_box">
                        <h4 class="medium_title"><?php translate("DATABASE_NAME") ?> :</h4>
                    </div>
                    <input type="text" name="dbname" class="input input_central" placeholder="<?php translate("CAN_EMPTY") ?>">
                    <div class="title_box">
                        <h4 class="medium_title"><?php translate("PUBLIC_URL") ?> :</h4>
                    </div>
                    <input type="text" name="public_name" class="input input_central" placeholder="<?php translate("PUBLIC_URL_PLACEHOLDER") ?>">
                    <div class="title_box" style="margin-top: 15px">
                        <h4 class="medium_title"><?php translate("ADMIN_PASSWORD_CONFIGURE") ?> :</h4>
                    </div>
                    <input type="password" name="adminpassword" class="input input_central">
                    </br>
                    <div class="title_box" style="margin-top: 15px">
                        <h4 class="medium_title"><?php translate("EMAIL_OPTIONAL") ?> :</h4>
                    </div>
                    <div>
                        <input type="checkbox" id="show_email" name="show_email">
                        <label for="show_email" class="medium_title"><?php translate("SHOW_EMAIL") ?></label>
                    </div>
                    <input type="text" name="email" class="input input_central">
                    </br>
                    <button class="button" onclick="init()"><?php translate("SUBMIT") ?></button>
                </div>
                <script src="script/devtools.js"></script>
                <script src="script/init.js"></script>
                <script src="script/adapt.js"></script>
        </body>
    </html>
