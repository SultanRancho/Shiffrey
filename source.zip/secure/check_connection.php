<?php
// Require sql_connection.php and session_start()

if (isset($_SESSION["admintoken"])){
    $admintoken = $_SESSION["admintoken"];

    $sql = "DELETE FROM `sessions` WHERE `creation` < ".(time() - 86400);
    $result = $conn->query($sql);
    
    $sql = "SELECT `creation` FROM `sessions` WHERE `token` = '".mysqli_real_escape_string($conn, $admintoken)."'";
    $result = $conn->query($sql);
    
    if (!$result){
        $_SESSION["role"] = "other";
        $_SESSION["admintoken"] = "";
    } else {
        if ($result->num_rows <= 0){
            $_SESSION["role"] = "other";
            $_SESSION["admintoken"] = "";
        }
    }
}

if (isset($_SESSION["token"])){
    $token = $_SESSION["token"];

    $sql = "DELETE FROM `sessions` WHERE `creation` < ".(time() - 86400);
    $result = $conn->query($sql);

    $sql = "SELECT `creation` FROM `sessions` WHERE `token` = '".mysqli_real_escape_string($conn, $token)."'";
    $result = $conn->query($sql);
    
    if (!$result){
        unset($_SESSION["username"]);
        unset($_SESSION["unsecure_username"]);
        $_SESSION["token"] = "";
    } else {
        if ($result->num_rows <= 0){
            unset($_SESSION["username"]);
            unset($_SESSION["unsecure_username"]);
            $_SESSION["token"] = "";
        }
    }
}

?>