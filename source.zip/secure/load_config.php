<?php
$pre_path = dirname(__FILE__)."/../";

// require session_start()
$local_lang = explode(";", $_SERVER['HTTP_ACCEPT_LANGUAGE']);
$local_lang = $local_lang[0];
$local_lang = explode(",", $local_lang)[0];
$local_lang_less = explode("-", $local_lang)[0];

if (file_exists( $pre_path."IMPORTANT/lang/".basename($local_lang).".json")){
    $_SESSION["lang"] = $local_lang;
} else {
    if (file_exists( $pre_path."IMPORTANT/lang/".basename($local_lang_less).".json")){
        $_SESSION["lang"] = $local_lang_less;
    } else {
        $_SESSION["lang"] = "en";
    }
}

// load the config file
$config_path =  $pre_path."IMPORTANT/config.json";
$config = json_decode(file_get_contents($config_path, "r"));

// load the language file
if (isset($_SESSION["lang"])){
    $lang_path =  $pre_path."IMPORTANT/lang/".basename($_SESSION["lang"]).".json";
    $lang = json_decode(file_get_contents($lang_path, "r"));
}

function translate($token, $flag = "secure", $backspace_allowed = FALSE, $lower = FALSE){
    global $lang;
    
    if (isset($lang->{$token})){
        if ((!$backspace_allowed && !str_contains($lang->{$token}, "\n")) || ($backspace_allowed)){
            if ($lower){
                if ($flag == "secure"){
                    echo strtolower(htmlspecialchars($lang->{$token}));
                } else if ($flag == "string"){
                    echo strtolower(addslashes($lang->{$token}));
                }
            } else {
                if ($flag == "secure"){
                    echo htmlspecialchars($lang->{$token});
                } else if ($flag == "string"){
                    echo addslashes($lang->{$token});
                }
            }
            
        } else {
            echo "!TRANSLATION ERROR! ANTISLASH-N IS NOT ALLOWED";  
        }
    } else {
        echo "!TRANSLATION ERROR!";
    }
}
?>