<?php
include("secure/head.php");
session_start();
include("secure/load_config.php");

if (!$config->{"done"})
    {
        http_response_code(302);
        header("Location: init.php");
        die();
    } else {
        if (isset($_SESSION["role"]) and $_SESSION["role"] == "admin"){
            http_response_code(302);
            header("Location: admin_panel.php");
            die();
        }
    }

?>
<!DOCTYPE HTML>
    <html>
        <head>
            <title>Shiffrey</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="style/main.css">
            <link rel="stylesheet" href="style/widget.css">
            <link rel="stylesheet" href="style/sample.css">
            <link rel="icon" type="images/png" href="images/favicon.png">
        </head>
        <body onresize="adapt_display()">
            <div class="central" style="padding: 15px">
                <h1 class="title"><?php translate("LOGIN_ADMIN") ?>:</h1>
                <div class="title_box">
                    <h4 class="medium_title"><?php translate("PASSWORD") ?> :</h4>
                </div>
                <input onkeypress="function enterpress(e, textarea){
                    var code = (e.keyCode ? e.keyCode : e.which);
                        if(code == 13) {
                            login();
                        }
                    }; enterpress(event, this);" type="password" name="password" id="password" class="input input_central">
                <br>
                <a href="index.php"><button class="button">< <?php translate("BACK") ?></button></a>
                <button class="button" onclick="login()"><?php translate("LOGIN") ?></button>
                <a href="forgot_password.php" class="back_link"><?php translate("FORGOT_PASSWORD") ?></a>
            </div>
            <script src="script/devtools.js"></script>
            <script src="script/admin.js"></script>
        </body>
        <script src="script/adapt.js"></script>
    </html>